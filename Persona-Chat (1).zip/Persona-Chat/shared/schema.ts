import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const personalities = pgTable("personalities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  instructions: text("instructions").notNull(),
  subject: text("subject"), // التخصص - Math, Physics, Chemistry, etc.
  avatarUrl: text("avatar_url"),
  voice: text("voice").default("nova"), // TTS voice: alloy, echo, fable, onyx, nova, shimmer
  isPublic: boolean("is_public").default(true),
  displayOrder: integer("display_order").default(999),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  personalityId: integer("personality_id").notNull(),
  deviceId: text("device_id").notNull().default("default"),
  title: text("title").notNull().default("محادثة جديدة"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  personalityId: integer("personality_id").notNull(),
  deviceId: text("device_id").notNull().default("default"),
  sessionId: integer("session_id"),
  role: text("role").notNull(),
  content: text("content").notNull(),
  isPinned: boolean("is_pinned").default(false),
  editedAt: timestamp("edited_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === نظام النقاط والإنجازات (Gamification) ===
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull().unique(),
  userId: text("user_id"),
  displayName: text("display_name").default("طالب"),
  profileImageUrl: text("profile_image_url"),
  totalPoints: integer("total_points").default(0),
  level: integer("level").default(1),
  questionsAsked: integer("questions_asked").default(0),
  quizzesCompleted: integer("quizzes_completed").default(0),
  streakDays: integer("streak_days").default(0),
  lastActiveDate: timestamp("last_active_date").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const subjectProgress = pgTable("subject_progress", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  subject: text("subject").notNull(),
  points: integer("points").default(0),
  questionsAsked: integer("questions_asked").default(0),
  quizzesCompleted: integer("quizzes_completed").default(0),
  correctAnswers: integer("correct_answers").default(0),
  masteryLevel: integer("mastery_level").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  achievementType: text("achievement_type").notNull(),
  achievementName: text("achievement_name").notNull(),
  description: text("description"),
  iconUrl: text("icon_url"),
  earnedAt: timestamp("earned_at").defaultNow(),
});

// === نظام الاختبارات (Quiz System) ===
export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  personalityId: integer("personality_id").notNull(),
  subject: text("subject").notNull(),
  title: text("title").notNull(),
  questions: jsonb("questions").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  correctAnswers: integer("correct_answers").default(0),
  score: integer("score").default(0),
  status: text("status").default("in_progress"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === المفضلة والملاحظات ===
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  messageId: integer("message_id").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === الملخصات ===
export const summaries = pgTable("summaries", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  sessionId: integer("session_id").notNull(),
  personalityId: integer("personality_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// === الشهادات (Certificates) ===
export const certificates = pgTable("certificates", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  subject: text("subject").notNull(),
  studentName: text("student_name").notNull(),
  certificateType: text("certificate_type").notNull(), // completion, excellence, participation
  score: integer("score"),
  questionsCompleted: integer("questions_completed").default(0),
  quizzesCompleted: integer("quizzes_completed").default(0),
  certificateCode: text("certificate_code").notNull().unique(),
  issuedAt: timestamp("issued_at").defaultNow(),
});

// === مسائل التدريب (Practice Problems) ===
export const practiceProblems = pgTable("practice_problems", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  subject: text("subject").notNull(),
  difficulty: text("difficulty").notNull(), // easy, medium, hard
  question: text("question").notNull(),
  solution: text("solution").notNull(),
  hints: jsonb("hints"),
  isCompleted: boolean("is_completed").default(false),
  userAnswer: text("user_answer"),
  isCorrect: boolean("is_correct"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === حسابات الوالدين (Parent Accounts) ===
export const parentAccounts = pgTable("parent_accounts", {
  id: serial("id").primaryKey(),
  parentCode: text("parent_code").notNull().unique(),
  parentName: text("parent_name").notNull(),
  email: text("email"),
  linkedStudents: jsonb("linked_students").default([]),
  notificationsEnabled: boolean("notifications_enabled").default(true),
  weeklyReportEnabled: boolean("weekly_report_enabled").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// === نظام الأصدقاء (Friends System) ===
export const friendships = pgTable("friendships", {
  id: serial("id").primaryKey(),
  requesterId: text("requester_id").notNull(),
  requesterName: text("requester_name").notNull(),
  requesterImage: text("requester_image"),
  addresseeId: text("addressee_id").notNull(),
  addresseeName: text("addressee_name").notNull(),
  addresseeImage: text("addressee_image"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === المحتوى المحفوظ للعمل بدون إنترنت ===
export const savedContent = pgTable("saved_content", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  contentType: text("content_type").notNull(), // message, summary, lesson
  contentId: integer("content_id"),
  content: text("content").notNull(),
  subject: text("subject"),
  savedAt: timestamp("saved_at").defaultNow(),
});

// === BASE SCHEMAS ===
export const insertPersonalitySchema = createInsertSchema(personalities).omit({ id: true, createdAt: true });
export const insertSessionSchema = createInsertSchema(sessions).omit({ id: true, createdAt: true, updatedAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });
export const insertUserProgressSchema = createInsertSchema(userProgress).omit({ id: true, createdAt: true });
export const insertSubjectProgressSchema = createInsertSchema(subjectProgress).omit({ id: true, createdAt: true });
export const insertAchievementSchema = createInsertSchema(achievements).omit({ id: true, earnedAt: true });
export const insertQuizSchema = createInsertSchema(quizzes).omit({ id: true, createdAt: true });
export const insertFavoriteSchema = createInsertSchema(favorites).omit({ id: true, createdAt: true });
export const insertSummarySchema = createInsertSchema(summaries).omit({ id: true, createdAt: true });
export const insertCertificateSchema = createInsertSchema(certificates).omit({ id: true, issuedAt: true });
export const insertPracticeProblemSchema = createInsertSchema(practiceProblems).omit({ id: true, createdAt: true });
export const insertParentAccountSchema = createInsertSchema(parentAccounts).omit({ id: true, createdAt: true });
export const insertFriendshipSchema = createInsertSchema(friendships).omit({ id: true, createdAt: true });
export const insertSavedContentSchema = createInsertSchema(savedContent).omit({ id: true, savedAt: true });

// === EXPLICIT API CONTRACT TYPES ===
export type Personality = typeof personalities.$inferSelect;
export type InsertPersonality = z.infer<typeof insertPersonalitySchema>;

export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

export type SubjectProgress = typeof subjectProgress.$inferSelect;
export type InsertSubjectProgress = z.infer<typeof insertSubjectProgressSchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = z.infer<typeof insertQuizSchema>;

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;

export type Summary = typeof summaries.$inferSelect;
export type InsertSummary = z.infer<typeof insertSummarySchema>;

export type Certificate = typeof certificates.$inferSelect;
export type InsertCertificate = z.infer<typeof insertCertificateSchema>;

export type PracticeProblem = typeof practiceProblems.$inferSelect;
export type InsertPracticeProblem = z.infer<typeof insertPracticeProblemSchema>;

export type ParentAccount = typeof parentAccounts.$inferSelect;
export type InsertParentAccount = z.infer<typeof insertParentAccountSchema>;

export type Friendship = typeof friendships.$inferSelect;
export type InsertFriendship = z.infer<typeof insertFriendshipSchema>;

export type SavedContent = typeof savedContent.$inferSelect;
export type InsertSavedContent = z.infer<typeof insertSavedContentSchema>;

// Achievement types
export const ACHIEVEMENT_TYPES = {
  FIRST_QUESTION: { id: "first_question", name: "السؤال الأول", nameEn: "First Question", icon: "🎯" },
  TEN_QUESTIONS: { id: "ten_questions", name: "عشرة أسئلة", nameEn: "Ten Questions", icon: "📚" },
  FIFTY_QUESTIONS: { id: "fifty_questions", name: "خمسون سؤالاً", nameEn: "Fifty Questions", icon: "🏆" },
  HUNDRED_QUESTIONS: { id: "hundred_questions", name: "مئة سؤال", nameEn: "Hundred Questions", icon: "👑" },
  FIRST_QUIZ: { id: "first_quiz", name: "أول اختبار", nameEn: "First Quiz", icon: "✅" },
  PERFECT_QUIZ: { id: "perfect_quiz", name: "اختبار كامل", nameEn: "Perfect Quiz", icon: "💯" },
  STREAK_3: { id: "streak_3", name: "٣ أيام متتالية", nameEn: "3 Day Streak", icon: "🔥" },
  STREAK_7: { id: "streak_7", name: "أسبوع متواصل", nameEn: "Week Streak", icon: "⭐" },
  STREAK_30: { id: "streak_30", name: "شهر متواصل", nameEn: "Month Streak", icon: "🌟" },
  MULTI_SUBJECT: { id: "multi_subject", name: "متعدد المواد", nameEn: "Multi-Subject", icon: "🎓" },
} as const;

// Request types
export type CreatePersonalityRequest = InsertPersonality;
export type UpdatePersonalityRequest = Partial<InsertPersonality>;
export type CreateMessageRequest = {
  content: string;
  deviceId: string;
};

// Response types
export type PersonalityResponse = Personality;
export type MessageResponse = Message;
export type ChatHistoryResponse = Message[];

// AI types
export interface ChatCompletionRequest {
  personalityId: number;
  message: string;
}

// Subject types - التخصصات التعليمية العالمية
export const SUBJECTS = [
  // العلوم الأساسية - Basic Sciences
  { id: "math", name: "الرياضيات", nameEn: "Mathematics" },
  { id: "physics", name: "الفيزياء", nameEn: "Physics" },
  { id: "chemistry", name: "الكيمياء", nameEn: "Chemistry" },
  { id: "biology", name: "الأحياء", nameEn: "Biology" },
  { id: "science", name: "العلوم العامة", nameEn: "General Science" },
  { id: "geology", name: "الجيولوجيا", nameEn: "Geology" },
  { id: "astronomy", name: "الفلك", nameEn: "Astronomy" },
  { id: "environmental", name: "العلوم البيئية", nameEn: "Environmental Science" },
  // اللغات - Languages
  { id: "arabic", name: "اللغة العربية", nameEn: "Arabic Language" },
  { id: "english", name: "اللغة الإنجليزية", nameEn: "English Language" },
  { id: "french", name: "اللغة الفرنسية", nameEn: "French Language" },
  { id: "german", name: "اللغة الألمانية", nameEn: "German Language" },
  { id: "spanish", name: "اللغة الإسبانية", nameEn: "Spanish Language" },
  { id: "chinese", name: "اللغة الصينية", nameEn: "Chinese Language" },
  // الدراسات الاجتماعية - Social Studies
  { id: "history", name: "التاريخ", nameEn: "History" },
  { id: "geography", name: "الجغرافيا", nameEn: "Geography" },
  { id: "civics", name: "التربية الوطنية", nameEn: "Civics" },
  { id: "sociology", name: "علم الاجتماع", nameEn: "Sociology" },
  { id: "psychology", name: "علم النفس", nameEn: "Psychology" },
  { id: "politics", name: "العلوم السياسية", nameEn: "Political Science" },
  // التربية الإسلامية - Islamic Studies
  { id: "islamic", name: "التربية الإسلامية", nameEn: "Islamic Studies" },
  { id: "quran", name: "القرآن الكريم", nameEn: "Quran" },
  { id: "hadith", name: "الحديث الشريف", nameEn: "Hadith" },
  { id: "fiqh", name: "الفقه الإسلامي", nameEn: "Islamic Jurisprudence" },
  // التكنولوجيا والحاسوب - Technology & Computer
  { id: "programming", name: "البرمجة", nameEn: "Programming" },
  { id: "computerscience", name: "علوم الحاسوب", nameEn: "Computer Science" },
  { id: "ai", name: "الذكاء الاصطناعي", nameEn: "Artificial Intelligence" },
  { id: "webdev", name: "تطوير الويب", nameEn: "Web Development" },
  { id: "cybersecurity", name: "الأمن السيبراني", nameEn: "Cybersecurity" },
  { id: "dataanalysis", name: "تحليل البيانات", nameEn: "Data Analysis" },
  // الأعمال والاقتصاد - Business & Economics
  { id: "economics", name: "الاقتصاد", nameEn: "Economics" },
  { id: "accounting", name: "المحاسبة", nameEn: "Accounting" },
  { id: "business", name: "إدارة الأعمال", nameEn: "Business Administration" },
  { id: "marketing", name: "التسويق", nameEn: "Marketing" },
  { id: "finance", name: "التمويل والمالية", nameEn: "Finance" },
  // الفلسفة والمنطق - Philosophy & Logic
  { id: "philosophy", name: "الفلسفة", nameEn: "Philosophy" },
  { id: "logic", name: "المنطق", nameEn: "Logic" },
  { id: "ethics", name: "الأخلاق", nameEn: "Ethics" },
  // الفنون والإبداع - Arts & Creativity
  { id: "art", name: "الفنون التشكيلية", nameEn: "Fine Arts" },
  { id: "music", name: "الموسيقى", nameEn: "Music" },
  { id: "design", name: "التصميم الجرافيكي", nameEn: "Graphic Design" },
  { id: "literature", name: "الأدب", nameEn: "Literature" },
  { id: "theater", name: "المسرح والدراما", nameEn: "Theater & Drama" },
  // الصحة والطب - Health & Medicine
  { id: "medicine", name: "الطب العام", nameEn: "General Medicine" },
  { id: "anatomy", name: "التشريح", nameEn: "Anatomy" },
  { id: "nutrition", name: "التغذية", nameEn: "Nutrition" },
  { id: "pharmacy", name: "الصيدلة", nameEn: "Pharmacy" },
  { id: "nursing", name: "التمريض", nameEn: "Nursing" },
  // الهندسة - Engineering
  { id: "engineering", name: "الهندسة العامة", nameEn: "General Engineering" },
  { id: "mechanical", name: "الهندسة الميكانيكية", nameEn: "Mechanical Engineering" },
  { id: "electrical", name: "الهندسة الكهربائية", nameEn: "Electrical Engineering" },
  { id: "civil", name: "الهندسة المدنية", nameEn: "Civil Engineering" },
  { id: "architecture", name: "العمارة", nameEn: "Architecture" },
  // القانون - Law
  { id: "law", name: "القانون", nameEn: "Law" },
  { id: "internationallaw", name: "القانون الدولي", nameEn: "International Law" },
  // الإرشاد والتطوير - Guidance & Development
  { id: "university", name: "الإرشاد الجامعي", nameEn: "University Guidance" },
  { id: "career", name: "الإرشاد المهني", nameEn: "Career Guidance" },
  { id: "studyskills", name: "مهارات الدراسة", nameEn: "Study Skills" },
  // رياضة وصحة - Sports & Health
  { id: "sports", name: "التربية الرياضية", nameEn: "Physical Education" },
  { id: "fitness", name: "اللياقة البدنية", nameEn: "Fitness" },
  // عام
  { id: "general", name: "عام", nameEn: "General" },
] as const;

export type SubjectId = typeof SUBJECTS[number]["id"];

// Export auth models
export * from "./models/auth";
