import { z } from 'zod';
import { insertPersonalitySchema, insertMessageSchema, personalities, messages } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  personalities: {
    list: {
      method: 'GET' as const,
      path: '/api/personalities',
      responses: {
        200: z.array(z.custom<typeof personalities.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/personalities/:id',
      responses: {
        200: z.custom<typeof personalities.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/personalities',
      input: insertPersonalitySchema,
      responses: {
        201: z.custom<typeof personalities.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/personalities/:id',
      input: insertPersonalitySchema.partial(),
      responses: {
        200: z.custom<typeof personalities.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/personalities/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  chat: {
    listMessages: {
      method: 'GET' as const,
      path: '/api/personalities/:id/messages',
      responses: {
        200: z.array(z.custom<typeof messages.$inferSelect>()),
        404: errorSchemas.notFound,
      },
    },
    sendMessage: {
      method: 'POST' as const,
      path: '/api/personalities/:id/messages',
      input: z.object({ content: z.string(), deviceId: z.string() }),
      responses: {
        201: z.custom<typeof messages.$inferSelect>(),
        404: errorSchemas.notFound,
        500: errorSchemas.internal,
      },
    }
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// ============================================
// TYPE HELPERS
// ============================================
export type PersonalityInput = z.infer<typeof api.personalities.create.input>;
export type ChatMessageInput = z.infer<typeof api.chat.sendMessage.input>;
