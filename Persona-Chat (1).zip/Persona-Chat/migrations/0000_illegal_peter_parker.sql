CREATE TABLE "messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"personality_id" integer NOT NULL,
	"role" text NOT NULL,
	"content" text NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "personalities" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"instructions" text NOT NULL,
	"subject" text,
	"avatar_url" text,
	"is_public" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
