import { db } from "./db";
import {
  personalities, messages, sessions,
  userProgress, subjectProgress, achievements, quizzes, favorites, summaries,
  certificates, practiceProblems, parentAccounts, savedContent, friendships,
  type Personality, type InsertPersonality,
  type Message, type InsertMessage,
  type Session, type InsertSession,
  type UserProgress, type InsertUserProgress,
  type SubjectProgress, type InsertSubjectProgress,
  type Achievement, type InsertAchievement,
  type Quiz, type InsertQuiz,
  type Favorite, type InsertFavorite,
  type Summary, type InsertSummary,
  type Certificate, type InsertCertificate,
  type PracticeProblem, type InsertPracticeProblem,
  type ParentAccount, type InsertParentAccount,
  type SavedContent, type InsertSavedContent,
  type Friendship, type InsertFriendship
} from "@shared/schema";
import { eq, desc, and, asc, like, or, sql } from "drizzle-orm";

export interface IStorage {
  // Personalities
  getAllPersonalities(): Promise<Personality[]>;
  getPersonality(id: number): Promise<Personality | undefined>;
  createPersonality(personality: InsertPersonality): Promise<Personality>;
  updatePersonality(id: number, updates: Partial<InsertPersonality>): Promise<Personality>;
  deletePersonality(id: number): Promise<void>;

  // Sessions
  getSessions(personalityId: number, deviceId: string): Promise<Session[]>;
  getSession(id: number): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSessionTitle(id: number, title: string): Promise<Session>;
  deleteSession(id: number): Promise<void>;

  // Messages
  getMessages(personalityId: number, deviceId: string, sessionId?: number): Promise<Message[]>;
  getMessageById(id: number): Promise<Message | undefined>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessage(id: number, updates: Partial<{ content: string; isPinned: boolean; editedAt: Date }>): Promise<Message | undefined>;
  deleteMessage(id: number): Promise<void>;
  clearMessages(personalityId: number, deviceId: string, sessionId?: number): Promise<void>;
  getLastAssistantMessage(personalityId: number, deviceId: string, sessionId?: number): Promise<Message | undefined>;
  searchMessages(personalityId: number, deviceId: string, query: string): Promise<Message[]>;
  getPinnedMessages(personalityId: number, deviceId: string): Promise<Message[]>;

  // Account linking & leaderboard
  linkAccountToDevice(deviceId: string, userId: string, displayName: string, profileImageUrl?: string): Promise<UserProgress>;
  getLinkedLeaderboard(limit?: number): Promise<UserProgress[]>;

  // Friends
  sendFriendRequest(data: InsertFriendship): Promise<Friendship>;
  getFriendRequests(userId: string): Promise<Friendship[]>;
  getSentRequests(userId: string): Promise<Friendship[]>;
  getFriends(userId: string): Promise<Friendship[]>;
  updateFriendshipStatus(id: number, status: string): Promise<Friendship | undefined>;
  getFriendship(requesterId: string, addresseeId: string): Promise<Friendship | undefined>;
  getFriendshipById(id: number): Promise<Friendship | undefined>;
  deleteFriendship(id: number): Promise<void>;
  searchUsersByName(query: string, excludeUserId: string): Promise<UserProgress[]>;
  getUserProgressByUserId(userId: string): Promise<UserProgress | undefined>;
  getFriendQuizzes(userId: string): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  async getAllPersonalities(): Promise<Personality[]> {
    return await db.select().from(personalities).orderBy(asc(personalities.displayOrder));
  }

  async getPersonality(id: number): Promise<Personality | undefined> {
    const [personality] = await db.select().from(personalities).where(eq(personalities.id, id));
    return personality;
  }

  async createPersonality(insertPersonality: InsertPersonality): Promise<Personality> {
    const [personality] = await db.insert(personalities).values(insertPersonality).returning();
    return personality;
  }

  async updatePersonality(id: number, updates: Partial<InsertPersonality>): Promise<Personality> {
    const [personality] = await db.update(personalities)
      .set(updates)
      .where(eq(personalities.id, id))
      .returning();
    return personality;
  }

  async deletePersonality(id: number): Promise<void> {
    await db.delete(messages).where(eq(messages.personalityId, id));
    await db.delete(sessions).where(eq(sessions.personalityId, id));
    await db.delete(personalities).where(eq(personalities.id, id));
  }

  // Sessions
  async getSessions(personalityId: number, deviceId: string): Promise<Session[]> {
    return await db.select()
      .from(sessions)
      .where(and(
        eq(sessions.personalityId, personalityId),
        eq(sessions.deviceId, deviceId)
      ))
      .orderBy(desc(sessions.updatedAt));
  }

  async getSession(id: number): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session;
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const [session] = await db.insert(sessions).values(insertSession).returning();
    return session;
  }

  async updateSessionTitle(id: number, title: string): Promise<Session> {
    const [session] = await db.update(sessions)
      .set({ title, updatedAt: new Date() })
      .where(eq(sessions.id, id))
      .returning();
    return session;
  }

  async deleteSession(id: number): Promise<void> {
    await db.delete(messages).where(eq(messages.sessionId, id));
    await db.delete(sessions).where(eq(sessions.id, id));
  }

  // Messages
  async getMessages(personalityId: number, deviceId: string, sessionId?: number): Promise<Message[]> {
    if (sessionId) {
      return await db.select()
        .from(messages)
        .where(and(
          eq(messages.personalityId, personalityId),
          eq(messages.deviceId, deviceId),
          eq(messages.sessionId, sessionId)
        ))
        .orderBy(messages.createdAt);
    }
    return await db.select()
      .from(messages)
      .where(and(
        eq(messages.personalityId, personalityId),
        eq(messages.deviceId, deviceId)
      ))
      .orderBy(messages.createdAt);
  }

  async getMessageById(id: number): Promise<Message | undefined> {
    const [message] = await db.select().from(messages).where(eq(messages.id, id));
    return message;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(insertMessage).returning();
    if (insertMessage.sessionId) {
      await db.update(sessions)
        .set({ updatedAt: new Date() })
        .where(eq(sessions.id, insertMessage.sessionId));
    }
    return message;
  }

  async deleteMessage(id: number): Promise<void> {
    await db.delete(messages).where(eq(messages.id, id));
  }

  async clearMessages(personalityId: number, deviceId: string, sessionId?: number): Promise<void> {
    if (sessionId) {
      await db.delete(messages).where(and(
        eq(messages.personalityId, personalityId),
        eq(messages.deviceId, deviceId),
        eq(messages.sessionId, sessionId)
      ));
    } else {
      await db.delete(messages).where(and(
        eq(messages.personalityId, personalityId),
        eq(messages.deviceId, deviceId)
      ));
    }
  }

  async getLastAssistantMessage(personalityId: number, deviceId: string, sessionId?: number): Promise<Message | undefined> {
    if (sessionId) {
      const [message] = await db.select()
        .from(messages)
        .where(and(
          eq(messages.personalityId, personalityId),
          eq(messages.deviceId, deviceId),
          eq(messages.sessionId, sessionId),
          eq(messages.role, "assistant")
        ))
        .orderBy(desc(messages.createdAt))
        .limit(1);
      return message;
    }
    const [message] = await db.select()
      .from(messages)
      .where(and(
        eq(messages.personalityId, personalityId),
        eq(messages.deviceId, deviceId),
        eq(messages.role, "assistant")
      ))
      .orderBy(desc(messages.createdAt))
      .limit(1);
    return message;
  }

  async updateMessage(id: number, updates: Partial<{ content: string; isPinned: boolean; editedAt: Date }>): Promise<Message | undefined> {
    const [message] = await db.update(messages)
      .set(updates)
      .where(eq(messages.id, id))
      .returning();
    return message;
  }

  async searchMessages(personalityId: number, deviceId: string, query: string): Promise<Message[]> {
    const searchPattern = `%${query}%`;
    return await db.select()
      .from(messages)
      .where(and(
        eq(messages.personalityId, personalityId),
        eq(messages.deviceId, deviceId),
        like(messages.content, searchPattern)
      ))
      .orderBy(desc(messages.createdAt))
      .limit(50);
  }

  async getPinnedMessages(personalityId: number, deviceId: string): Promise<Message[]> {
    return await db.select()
      .from(messages)
      .where(and(
        eq(messages.personalityId, personalityId),
        eq(messages.deviceId, deviceId),
        eq(messages.isPinned, true)
      ))
      .orderBy(desc(messages.createdAt));
  }

  // === User Progress (Gamification) ===
  async getUserProgress(deviceId: string): Promise<UserProgress | undefined> {
    const [progress] = await db.select().from(userProgress).where(eq(userProgress.deviceId, deviceId));
    return progress;
  }

  async createOrUpdateUserProgress(deviceId: string, updates: Partial<InsertUserProgress>): Promise<UserProgress> {
    const existing = await this.getUserProgress(deviceId);
    if (existing) {
      const [updated] = await db.update(userProgress)
        .set({ ...updates, lastActiveDate: new Date() })
        .where(eq(userProgress.deviceId, deviceId))
        .returning();
      return updated;
    }
    const [created] = await db.insert(userProgress).values({ deviceId, ...updates }).returning();
    return created;
  }

  async addPoints(deviceId: string, points: number): Promise<UserProgress> {
    const existing = await this.getUserProgress(deviceId);
    const currentPoints = existing?.totalPoints || 0;
    const newPoints = currentPoints + points;
    const newLevel = Math.floor(newPoints / 100) + 1;
    return this.createOrUpdateUserProgress(deviceId, { totalPoints: newPoints, level: newLevel });
  }

  async incrementQuestions(deviceId: string): Promise<UserProgress> {
    const existing = await this.getUserProgress(deviceId);
    const current = existing?.questionsAsked || 0;
    return this.createOrUpdateUserProgress(deviceId, { questionsAsked: current + 1 });
  }

  async getLeaderboard(limit: number = 10): Promise<UserProgress[]> {
    return await db.select().from(userProgress).orderBy(desc(userProgress.totalPoints)).limit(limit);
  }

  async linkAccountToDevice(deviceId: string, userId: string, displayName: string, profileImageUrl?: string): Promise<UserProgress> {
    const existing = await this.getUserProgress(deviceId);
    if (existing) {
      const [updated] = await db.update(userProgress)
        .set({ userId, displayName, profileImageUrl: profileImageUrl || existing.profileImageUrl })
        .where(eq(userProgress.deviceId, deviceId))
        .returning();
      return updated;
    }
    const [created] = await db.insert(userProgress)
      .values({ deviceId, userId, displayName, profileImageUrl, totalPoints: 0, level: 1 })
      .returning();
    return created;
  }

  async getLinkedLeaderboard(limit: number = 50): Promise<UserProgress[]> {
    return await db.select().from(userProgress)
      .where(sql`${userProgress.userId} IS NOT NULL`)
      .orderBy(desc(userProgress.totalPoints))
      .limit(limit);
  }

  // === Subject Progress ===
  async getSubjectProgress(deviceId: string, subject: string): Promise<SubjectProgress | undefined> {
    const [progress] = await db.select().from(subjectProgress)
      .where(and(eq(subjectProgress.deviceId, deviceId), eq(subjectProgress.subject, subject)));
    return progress;
  }

  async getAllSubjectProgress(deviceId: string): Promise<SubjectProgress[]> {
    return await db.select().from(subjectProgress).where(eq(subjectProgress.deviceId, deviceId));
  }

  async updateSubjectProgress(deviceId: string, subject: string, updates: Partial<InsertSubjectProgress>): Promise<SubjectProgress> {
    const existing = await this.getSubjectProgress(deviceId, subject);
    if (existing) {
      const [updated] = await db.update(subjectProgress)
        .set(updates)
        .where(and(eq(subjectProgress.deviceId, deviceId), eq(subjectProgress.subject, subject)))
        .returning();
      return updated;
    }
    const [created] = await db.insert(subjectProgress).values({ deviceId, subject, ...updates }).returning();
    return created;
  }

  // === Achievements ===
  async getAchievements(deviceId: string): Promise<Achievement[]> {
    return await db.select().from(achievements).where(eq(achievements.deviceId, deviceId)).orderBy(desc(achievements.earnedAt));
  }

  async hasAchievement(deviceId: string, achievementType: string): Promise<boolean> {
    const [achievement] = await db.select().from(achievements)
      .where(and(eq(achievements.deviceId, deviceId), eq(achievements.achievementType, achievementType)));
    return !!achievement;
  }

  async grantAchievement(deviceId: string, achievement: InsertAchievement): Promise<Achievement> {
    const [created] = await db.insert(achievements).values({ ...achievement, deviceId }).returning();
    return created;
  }

  // === Quizzes ===
  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const [created] = await db.insert(quizzes).values(quiz).returning();
    return created;
  }

  async getQuiz(id: number): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id));
    return quiz;
  }

  async getUserQuizzes(deviceId: string): Promise<Quiz[]> {
    return await db.select().from(quizzes).where(eq(quizzes.deviceId, deviceId)).orderBy(desc(quizzes.createdAt));
  }

  async updateQuiz(id: number, updates: Partial<InsertQuiz>): Promise<Quiz | undefined> {
    const [updated] = await db.update(quizzes).set(updates).where(eq(quizzes.id, id)).returning();
    return updated;
  }

  // === Favorites ===
  async getFavorites(deviceId: string): Promise<Favorite[]> {
    return await db.select().from(favorites).where(eq(favorites.deviceId, deviceId)).orderBy(desc(favorites.createdAt));
  }

  async addFavorite(favorite: InsertFavorite): Promise<Favorite> {
    const [created] = await db.insert(favorites).values(favorite).returning();
    return created;
  }

  async removeFavorite(id: number): Promise<void> {
    await db.delete(favorites).where(eq(favorites.id, id));
  }

  // === Summaries ===
  async createSummary(summary: InsertSummary): Promise<Summary> {
    const [created] = await db.insert(summaries).values(summary).returning();
    return created;
  }

  async getSummaries(deviceId: string): Promise<Summary[]> {
    return await db.select().from(summaries).where(eq(summaries.deviceId, deviceId)).orderBy(desc(summaries.createdAt));
  }

  async getSessionSummary(sessionId: number): Promise<Summary | undefined> {
    const [summary] = await db.select().from(summaries).where(eq(summaries.sessionId, sessionId));
    return summary;
  }

  // === Certificates ===
  async createCertificate(cert: InsertCertificate): Promise<Certificate> {
    const [created] = await db.insert(certificates).values(cert).returning();
    return created;
  }

  async getCertificates(deviceId: string): Promise<Certificate[]> {
    return await db.select().from(certificates).where(eq(certificates.deviceId, deviceId)).orderBy(desc(certificates.issuedAt));
  }

  async verifyCertificate(code: string): Promise<Certificate | undefined> {
    const [cert] = await db.select().from(certificates).where(eq(certificates.certificateCode, code));
    return cert;
  }

  // === Practice Problems ===
  async createPracticeProblem(problem: InsertPracticeProblem): Promise<PracticeProblem> {
    const [created] = await db.insert(practiceProblems).values(problem).returning();
    return created;
  }

  async getPracticeProblems(deviceId: string, subject?: string): Promise<PracticeProblem[]> {
    if (subject) {
      return await db.select().from(practiceProblems)
        .where(and(eq(practiceProblems.deviceId, deviceId), eq(practiceProblems.subject, subject)))
        .orderBy(desc(practiceProblems.createdAt));
    }
    return await db.select().from(practiceProblems)
      .where(eq(practiceProblems.deviceId, deviceId))
      .orderBy(desc(practiceProblems.createdAt));
  }

  async getPracticeProblem(id: number): Promise<PracticeProblem | undefined> {
    const [problem] = await db.select().from(practiceProblems).where(eq(practiceProblems.id, id));
    return problem;
  }

  async updatePracticeProblem(id: number, updates: Partial<InsertPracticeProblem>): Promise<PracticeProblem> {
    const [updated] = await db.update(practiceProblems).set(updates).where(eq(practiceProblems.id, id)).returning();
    return updated;
  }

  // === Parent Accounts ===
  async createParentAccount(parent: InsertParentAccount): Promise<ParentAccount> {
    const [created] = await db.insert(parentAccounts).values(parent).returning();
    return created;
  }

  async getParentAccount(parentCode: string): Promise<ParentAccount | undefined> {
    const [parent] = await db.select().from(parentAccounts).where(eq(parentAccounts.parentCode, parentCode));
    return parent;
  }

  async updateParentAccount(parentCode: string, updates: Partial<InsertParentAccount>): Promise<ParentAccount> {
    const [updated] = await db.update(parentAccounts).set(updates).where(eq(parentAccounts.parentCode, parentCode)).returning();
    return updated;
  }

  // === Saved Content ===
  async saveContent(content: InsertSavedContent): Promise<SavedContent> {
    const [created] = await db.insert(savedContent).values(content).returning();
    return created;
  }

  async getSavedContent(deviceId: string): Promise<SavedContent[]> {
    return await db.select().from(savedContent).where(eq(savedContent.deviceId, deviceId)).orderBy(desc(savedContent.savedAt));
  }

  async deleteSavedContent(id: number): Promise<void> {
    await db.delete(savedContent).where(eq(savedContent.id, id));
  }

  // === Friends ===
  async sendFriendRequest(data: InsertFriendship): Promise<Friendship> {
    const [created] = await db.insert(friendships).values(data).returning();
    return created;
  }

  async getFriendRequests(userId: string): Promise<Friendship[]> {
    return await db.select().from(friendships)
      .where(and(eq(friendships.addresseeId, userId), eq(friendships.status, "pending")))
      .orderBy(desc(friendships.createdAt));
  }

  async getSentRequests(userId: string): Promise<Friendship[]> {
    return await db.select().from(friendships)
      .where(and(eq(friendships.requesterId, userId), eq(friendships.status, "pending")))
      .orderBy(desc(friendships.createdAt));
  }

  async getFriends(userId: string): Promise<Friendship[]> {
    return await db.select().from(friendships)
      .where(and(
        or(eq(friendships.requesterId, userId), eq(friendships.addresseeId, userId)),
        eq(friendships.status, "accepted")
      ))
      .orderBy(desc(friendships.createdAt));
  }

  async updateFriendshipStatus(id: number, status: string): Promise<Friendship | undefined> {
    const [updated] = await db.update(friendships).set({ status }).where(eq(friendships.id, id)).returning();
    return updated;
  }

  async getFriendship(requesterId: string, addresseeId: string): Promise<Friendship | undefined> {
    const [existing] = await db.select().from(friendships)
      .where(or(
        and(eq(friendships.requesterId, requesterId), eq(friendships.addresseeId, addresseeId)),
        and(eq(friendships.requesterId, addresseeId), eq(friendships.addresseeId, requesterId))
      ));
    return existing;
  }

  async getFriendshipById(id: number): Promise<Friendship | undefined> {
    const [f] = await db.select().from(friendships).where(eq(friendships.id, id));
    return f;
  }

  async deleteFriendship(id: number): Promise<void> {
    await db.delete(friendships).where(eq(friendships.id, id));
  }

  async searchUsersByName(query: string, excludeUserId: string): Promise<UserProgress[]> {
    const searchPattern = `%${query}%`;
    return await db.select().from(userProgress)
      .where(and(
        sql`${userProgress.userId} IS NOT NULL`,
        sql`${userProgress.userId} != ${excludeUserId}`,
        like(userProgress.displayName, searchPattern)
      ))
      .limit(20);
  }

  async getUserProgressByUserId(userId: string): Promise<UserProgress | undefined> {
    const [progress] = await db.select().from(userProgress)
      .where(eq(userProgress.userId, userId));
    return progress;
  }

  async getFriendQuizzes(userId: string): Promise<any[]> {
    const progress = await this.getUserProgressByUserId(userId);
    if (!progress) return [];
    return await db.select().from(quizzes)
      .where(and(eq(quizzes.deviceId, progress.deviceId), eq(quizzes.status, "completed")))
      .orderBy(desc(quizzes.createdAt))
      .limit(20);
  }
}

export const storage = new DatabaseStorage();
