import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { Personality, CreatePersonalityRequest, UpdatePersonalityRequest } from "@shared/schema";

// GET /api/personalities
export function usePersonalities() {
  return useQuery({
    queryKey: [api.personalities.list.path],
    queryFn: async () => {
      const res = await fetch(api.personalities.list.path);
      if (!res.ok) throw new Error("Failed to fetch personalities");
      return api.personalities.list.responses[200].parse(await res.json());
    },
  });
}

// GET /api/personalities/:id
export function usePersonality(id: number | null) {
  return useQuery({
    queryKey: [api.personalities.get.path, id],
    enabled: !!id,
    queryFn: async () => {
      if (!id) throw new Error("ID required");
      const url = buildUrl(api.personalities.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch personality");
      return api.personalities.get.responses[200].parse(await res.json());
    },
  });
}

// POST /api/personalities
export function useCreatePersonality() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreatePersonalityRequest) => {
      const res = await fetch(api.personalities.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Validation failed");
        }
        throw new Error("Failed to create personality");
      }
      
      return api.personalities.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.personalities.list.path] });
    },
  });
}

// DELETE /api/personalities/:id
export function useDeletePersonality() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.personalities.delete.path, { id });
      const res = await fetch(url, { method: "DELETE" });
      if (!res.ok && res.status !== 404) throw new Error("Failed to delete personality");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.personalities.list.path] });
    },
  });
}
