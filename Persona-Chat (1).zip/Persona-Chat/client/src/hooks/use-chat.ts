import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { Message } from "@shared/schema";
import { getDeviceId } from "./use-device-id";

// GET /api/personalities/:id/messages
export function useMessages(personalityId: number | null, sessionId?: number | null) {
  const deviceId = getDeviceId();
  
  return useQuery({
    queryKey: [api.chat.listMessages.path, personalityId, deviceId, sessionId],
    enabled: !!personalityId,
    refetchInterval: 5000,
    queryFn: async () => {
      if (!personalityId) throw new Error("ID required");
      const url = buildUrl(api.chat.listMessages.path, { id: personalityId });
      let queryUrl = `${url}?deviceId=${encodeURIComponent(deviceId)}`;
      if (sessionId) {
        queryUrl += `&sessionId=${sessionId}`;
      }
      const res = await fetch(queryUrl);
      if (!res.ok) throw new Error("Failed to fetch messages");
      return api.chat.listMessages.responses[200].parse(await res.json());
    },
  });
}

// POST /api/personalities/:id/messages
export function useSendMessage() {
  const queryClient = useQueryClient();
  const deviceId = getDeviceId();
  
  return useMutation({
    mutationFn: async ({ personalityId, content, sessionId }: { personalityId: number; content: string; sessionId?: number | null }) => {
      const url = buildUrl(api.chat.sendMessage.path, { id: personalityId });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, deviceId, sessionId }),
      });

      if (!res.ok) throw new Error("Failed to send message");
      return api.chat.sendMessage.responses[201].parse(await res.json());
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: [api.chat.listMessages.path, variables.personalityId, deviceId, variables.sessionId] 
      });
    },
  });
}

// POST /api/personalities/:id/regenerate
export function useRegenerateMessage() {
  const queryClient = useQueryClient();
  const deviceId = getDeviceId();
  
  return useMutation({
    mutationFn: async ({ personalityId, sessionId }: { personalityId: number; sessionId?: number | null }) => {
      const res = await fetch(`/api/personalities/${personalityId}/regenerate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deviceId, sessionId }),
      });

      if (!res.ok) throw new Error("Failed to regenerate message");
      return res.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: [api.chat.listMessages.path, variables.personalityId, deviceId, variables.sessionId] 
      });
    },
  });
}

// DELETE /api/personalities/:id/messages
export function useClearChat() {
  const queryClient = useQueryClient();
  const deviceId = getDeviceId();
  
  return useMutation({
    mutationFn: async ({ personalityId, sessionId }: { personalityId: number; sessionId?: number | null }) => {
      let queryUrl = `/api/personalities/${personalityId}/messages?deviceId=${encodeURIComponent(deviceId)}`;
      if (sessionId) {
        queryUrl += `&sessionId=${sessionId}`;
      }
      const res = await fetch(queryUrl, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Failed to clear chat");
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: [api.chat.listMessages.path, variables.personalityId, deviceId, variables.sessionId] 
      });
    },
  });
}

// POST /api/personalities/:id/messages/with-image
export function useSendMessageWithImage() {
  const queryClient = useQueryClient();
  const deviceId = getDeviceId();
  
  return useMutation({
    mutationFn: async ({ 
      personalityId, 
      content, 
      imageBase64, 
      imageMimeType,
      sessionId
    }: { 
      personalityId: number; 
      content: string; 
      imageBase64?: string;
      imageMimeType?: string;
      sessionId?: number | null;
    }) => {
      const res = await fetch(`/api/personalities/${personalityId}/messages/with-image`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, deviceId, imageBase64, imageMimeType, sessionId }),
      });

      if (!res.ok) throw new Error("Failed to send message with image");
      return res.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: [api.chat.listMessages.path, variables.personalityId, deviceId, variables.sessionId] 
      });
    },
  });
}

// POST /api/transcribe
export async function transcribeAudio(audioBlob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = (reader.result as string).split(",")[1];
        const res = await fetch("/api/transcribe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ audio: base64 }),
        });
        
        if (!res.ok) throw new Error("Transcription failed");
        const data = await res.json();
        resolve(data.text || "");
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error("Failed to read audio"));
    reader.readAsDataURL(audioBlob);
  });
}
