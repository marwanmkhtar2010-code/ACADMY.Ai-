import { useState, useEffect } from "react";

const DEVICE_ID_KEY = "acadmy_device_id";

function generateDeviceId(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let id = "";
  for (let i = 0; i < 16; i++) {
    id += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `device_${id}_${Date.now()}`;
}

export function useDeviceId(): string {
  const [deviceId, setDeviceId] = useState<string>(() => {
    if (typeof window === "undefined") return "default";
    
    const stored = localStorage.getItem(DEVICE_ID_KEY);
    if (stored) return stored;
    
    const newId = generateDeviceId();
    localStorage.setItem(DEVICE_ID_KEY, newId);
    return newId;
  });

  useEffect(() => {
    const stored = localStorage.getItem(DEVICE_ID_KEY);
    if (!stored) {
      const newId = generateDeviceId();
      localStorage.setItem(DEVICE_ID_KEY, newId);
      setDeviceId(newId);
    }
  }, []);

  return deviceId;
}

export function getDeviceId(): string {
  if (typeof window === "undefined") return "default";
  
  const stored = localStorage.getItem(DEVICE_ID_KEY);
  if (stored) return stored;
  
  const newId = generateDeviceId();
  localStorage.setItem(DEVICE_ID_KEY, newId);
  return newId;
}
