import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getDeviceId } from "@/hooks/use-device-id";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Download, Trash2, FileText, MessageSquare, 
  ClipboardList, BookOpen, Wifi, WifiOff, Loader2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

interface SavedContentManagerProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  language: string;
}

interface SavedItem {
  id: number;
  deviceId: string;
  contentType: string;
  contentId: string;
  content: string;
  subject: string | null;
  savedAt: string;
}

const translations: Record<string, { title: string; noContent: string; noContentDesc: string; delete: string; message: string; summary: string; quiz: string; practice: string; savedOn: string; offline: string; online: string; clearAll: string; confirmDelete: string; deleted: string; contentDeleted: string }> = {
  ar: { title: "المحتوى المحفوظ", noContent: "لا يوجد محتوى محفوظ", noContentDesc: "احفظ المحادثات والملخصات للوصول إليها بدون إنترنت", delete: "حذف", message: "رسالة", summary: "ملخص", quiz: "اختبار", practice: "تدريب", savedOn: "تم الحفظ في", offline: "وضع عدم الاتصال", online: "متصل", clearAll: "حذف الكل", confirmDelete: "هل تريد حذف هذا المحتوى؟", deleted: "تم الحذف", contentDeleted: "تم حذف المحتوى" },
  en: { title: "Saved Content", noContent: "No saved content", noContentDesc: "Save conversations and summaries for offline access", delete: "Delete", message: "Message", summary: "Summary", quiz: "Quiz", practice: "Practice", savedOn: "Saved on", offline: "Offline mode", online: "Online", clearAll: "Clear all", confirmDelete: "Delete this content?", deleted: "Deleted", contentDeleted: "Content deleted" },
  zh: { title: "已保存内容", noContent: "没有已保存的内容", noContentDesc: "保存对话和摘要以便离线访问", delete: "删除", message: "消息", summary: "摘要", quiz: "测验", practice: "练习", savedOn: "保存于", offline: "离线模式", online: "在线", clearAll: "全部清除", confirmDelete: "删除此内容？", deleted: "已删除", contentDeleted: "内容已删除" },
  hi: { title: "सहेजी गई सामग्री", noContent: "कोई सहेजी गई सामग्री नहीं", noContentDesc: "ऑफ़लाइन एक्सेस के लिए बातचीत और सारांश सहेजें", delete: "हटाएं", message: "संदेश", summary: "सारांश", quiz: "क्विज़", practice: "अभ्यास", savedOn: "सहेजा गया", offline: "ऑफ़लाइन मोड", online: "ऑनलाइन", clearAll: "सब हटाएं", confirmDelete: "यह सामग्री हटाएं?", deleted: "हटा दिया गया", contentDeleted: "सामग्री हटा दी गई" },
  es: { title: "Contenido guardado", noContent: "Sin contenido guardado", noContentDesc: "Guarda conversaciones y resúmenes para acceso sin conexión", delete: "Eliminar", message: "Mensaje", summary: "Resumen", quiz: "Prueba", practice: "Práctica", savedOn: "Guardado el", offline: "Modo sin conexión", online: "En línea", clearAll: "Borrar todo", confirmDelete: "¿Eliminar este contenido?", deleted: "Eliminado", contentDeleted: "Contenido eliminado" },
  fr: { title: "Contenu sauvegardé", noContent: "Aucun contenu sauvegardé", noContentDesc: "Sauvegardez les conversations et résumés pour un accès hors ligne", delete: "Supprimer", message: "Message", summary: "Résumé", quiz: "Quiz", practice: "Pratique", savedOn: "Sauvegardé le", offline: "Mode hors ligne", online: "En ligne", clearAll: "Tout effacer", confirmDelete: "Supprimer ce contenu ?", deleted: "Supprimé", contentDeleted: "Contenu supprimé" },
  bn: { title: "সংরক্ষিত বিষয়বস্তু", noContent: "কোনো সংরক্ষিত বিষয়বস্তু নেই", noContentDesc: "অফলাইন অ্যাক্সেসের জন্য কথোপকথন এবং সারসংক্ষেপ সংরক্ষণ করুন", delete: "মুছুন", message: "বার্তা", summary: "সারসংক্ষেপ", quiz: "কুইজ", practice: "অনুশীলন", savedOn: "সংরক্ষিত", offline: "অফলাইন মোড", online: "অনলাইন", clearAll: "সব মুছুন", confirmDelete: "এই বিষয়বস্তু মুছবেন?", deleted: "মুছে ফেলা হয়েছে", contentDeleted: "বিষয়বস্তু মুছে ফেলা হয়েছে" },
  pt: { title: "Conteúdo salvo", noContent: "Nenhum conteúdo salvo", noContentDesc: "Salve conversas e resumos para acesso offline", delete: "Excluir", message: "Mensagem", summary: "Resumo", quiz: "Quiz", practice: "Prática", savedOn: "Salvo em", offline: "Modo offline", online: "Online", clearAll: "Limpar tudo", confirmDelete: "Excluir este conteúdo?", deleted: "Excluído", contentDeleted: "Conteúdo excluído" },
  ru: { title: "Сохранённый контент", noContent: "Нет сохранённого контента", noContentDesc: "Сохраняйте беседы и резюме для офлайн-доступа", delete: "Удалить", message: "Сообщение", summary: "Резюме", quiz: "Тест", practice: "Практика", savedOn: "Сохранено", offline: "Офлайн-режим", online: "Онлайн", clearAll: "Очистить всё", confirmDelete: "Удалить этот контент?", deleted: "Удалено", contentDeleted: "Контент удалён" },
  ja: { title: "保存済みコンテンツ", noContent: "保存済みコンテンツなし", noContentDesc: "オフラインアクセスのために会話と要約を保存", delete: "削除", message: "メッセージ", summary: "要約", quiz: "クイズ", practice: "練習", savedOn: "保存日", offline: "オフラインモード", online: "オンライン", clearAll: "すべてクリア", confirmDelete: "このコンテンツを削除しますか？", deleted: "削除しました", contentDeleted: "コンテンツを削除しました" },
};

const savedContentLocaleMap: Record<string, string> = {
  ar: "ar-SA", en: "en-US", zh: "zh-CN", hi: "hi-IN",
  es: "es-ES", fr: "fr-FR", bn: "bn-BD", pt: "pt-BR",
  ru: "ru-RU", ja: "ja-JP",
};

const contentTypeIcons: Record<string, typeof FileText> = {
  message: MessageSquare,
  summary: FileText,
  quiz: ClipboardList,
  practice: BookOpen
};

export function SavedContentManager({ isOpen, onOpenChange, language }: SavedContentManagerProps) {
  const { toast } = useToast();
  const t = translations[language] || translations.en;
  const deviceId = getDeviceId();
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Listen for online/offline status with proper cleanup
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const { data: savedContent = [], isLoading } = useQuery<SavedItem[]>({
    queryKey: ["/api/saved-content", deviceId],
    queryFn: async () => {
      const res = await fetch(`/api/saved-content/${deviceId}`);
      if (!res.ok) throw new Error("Failed to fetch saved content");
      return res.json();
    },
    enabled: isOpen
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/saved-content/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/saved-content", deviceId] });
      toast({
        title: t.deleted,
        description: t.contentDeleted
      });
    }
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(savedContentLocaleMap[language] || "en-US", {
      year: "numeric",
      month: "short",
      day: "numeric"
    });
  };

  const getContentTypeName = (type: string) => {
    const key = type as keyof typeof t;
    return t[key] || type;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className={`max-w-lg ${language === "ar" ? "rtl" : "ltr"}`} dir={language === "ar" ? "rtl" : "ltr"}>
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Download className="w-5 h-5" />
              {t.title}
            </span>
            <Badge variant={isOnline ? "default" : "secondary"} className="flex items-center gap-1">
              {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
              {isOnline ? t.online : t.offline}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[400px]">
          {isLoading ? (
            <div className="space-y-3 p-2">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : savedContent.length === 0 ? (
            <div className="text-center py-12 px-4">
              <Download className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <p className="font-medium text-muted-foreground">{t.noContent}</p>
              <p className="text-sm text-muted-foreground mt-1">{t.noContentDesc}</p>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              <div className="space-y-3 p-2">
                {savedContent.map((item) => {
                  const IconComponent = contentTypeIcons[item.contentType] || FileText;
                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      layout
                    >
                      <Card className="hover-elevate">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-start gap-3 flex-1 min-w-0">
                              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <IconComponent className="w-5 h-5 text-primary" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <Badge variant="outline" className="text-xs">
                                    {getContentTypeName(item.contentType)}
                                  </Badge>
                                  {item.subject && (
                                    <Badge variant="secondary" className="text-xs">
                                      {item.subject}
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-sm text-muted-foreground line-clamp-2">
                                  {typeof item.content === 'string' 
                                    ? item.content.substring(0, 100) + (item.content.length > 100 ? '...' : '')
                                    : ''}
                                </p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  {t.savedOn} {formatDate(item.savedAt)}
                                </p>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteMutation.mutate(item.id)}
                              disabled={deleteMutation.isPending}
                              data-testid={`button-delete-saved-${item.id}`}
                            >
                              {deleteMutation.isPending ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <Trash2 className="w-4 h-4 text-destructive" />
                              )}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            </AnimatePresence>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
