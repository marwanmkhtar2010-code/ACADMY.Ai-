import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Award, Medal, Trophy, CheckCircle, Copy, Share, Loader2, ScrollText, XCircle } from "lucide-react";
import { getTranslation, Language } from "@/lib/translations";
import { useToast } from "@/hooks/use-toast";
import { SUBJECTS, Certificate } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";

interface Props {
  deviceId: string;
  language: Language;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  studentName: string;
}

const certLabels: Record<string, { failedToGenerate: string; generating: string; verifying: string; score: (s: number) => string }> = {
  ar: { failedToGenerate: "فشل في إنشاء الشهادة", generating: "جاري الإنشاء...", verifying: "جاري التحقق...", score: (s) => `النتيجة: ${s}%` },
  en: { failedToGenerate: "Failed to generate certificate", generating: "Generating...", verifying: "Verifying...", score: (s) => `Score: ${s}%` },
  zh: { failedToGenerate: "生成证书失败", generating: "正在生成...", verifying: "正在验证...", score: (s) => `成绩: ${s}%` },
  hi: { failedToGenerate: "प्रमाणपत्र बनाने में विफल", generating: "बना रहा है...", verifying: "सत्यापित कर रहा है...", score: (s) => `स्कोर: ${s}%` },
  es: { failedToGenerate: "Error al generar certificado", generating: "Generando...", verifying: "Verificando...", score: (s) => `Puntuación: ${s}%` },
  fr: { failedToGenerate: "Échec de la génération du certificat", generating: "Génération...", verifying: "Vérification...", score: (s) => `Score: ${s}%` },
  bn: { failedToGenerate: "সার্টিফিকেট তৈরি ব্যর্থ", generating: "তৈরি হচ্ছে...", verifying: "যাচাই করা হচ্ছে...", score: (s) => `স্কোর: ${s}%` },
  pt: { failedToGenerate: "Falha ao gerar certificado", generating: "Gerando...", verifying: "Verificando...", score: (s) => `Pontuação: ${s}%` },
  ru: { failedToGenerate: "Не удалось создать сертификат", generating: "Создание...", verifying: "Проверка...", score: (s) => `Результат: ${s}%` },
  ja: { failedToGenerate: "証明書の生成に失敗しました", generating: "生成中...", verifying: "検証中...", score: (s) => `スコア: ${s}%` },
};

const certLocaleMap: Record<string, string> = {
  ar: "ar-SA", en: "en-US", zh: "zh-CN", hi: "hi-IN",
  es: "es-ES", fr: "fr-FR", bn: "bn-BD", pt: "pt-BR",
  ru: "ru-RU", ja: "ja-JP",
};

const certificateTypeIcons = {
  participation: Medal,
  completion: Award,
  excellence: Trophy,
};

const certificateTypeColors = {
  participation: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  completion: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  excellence: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
};

export function CertificateViewer({ deviceId, language, isOpen, onOpenChange, studentName }: Props) {
  const t = getTranslation(language);
  const isRTL = language === "ar";
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState<"list" | "verify">("list");
  const [verifyCode, setVerifyCode] = useState("");
  const [verifiedCert, setVerifiedCert] = useState<Certificate | null>(null);
  const [verifyError, setVerifyError] = useState(false);

  const { data: certificates = [], isLoading } = useQuery<Certificate[]>({
    queryKey: ["/api/certificates", deviceId],
    enabled: isOpen && !!deviceId,
  });

  const verifyCertificate = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/certificates/verify/${verifyCode}`);
      if (!res.ok) throw new Error("Not found");
      return res.json();
    },
    onSuccess: (data) => {
      setVerifiedCert(data);
      setVerifyError(false);
      toast({
        title: t.verified,
        description: t.verifiedDesc,
      });
    },
    onError: () => {
      setVerifiedCert(null);
      setVerifyError(true);
      toast({
        title: t.invalidCertificate,
        description: t.invalidCertificateDesc,
        variant: "destructive",
      });
    },
  });

  const copyLink = (code: string) => {
    const link = `${window.location.origin}/verify/${code}`;
    navigator.clipboard.writeText(link);
    toast({
      title: t.linkCopied,
      description: t.linkCopiedDesc,
    });
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({
      title: t.copied,
      description: t.copiedDesc,
    });
  };

  const getSubjectName = (subjectId: string) => {
    const subject = SUBJECTS.find((s) => s.id === subjectId);
    return language === "ar" ? subject?.name : (subject?.nameEn || subjectId);
  };

  const getCertificateTypeName = (type: string) => {
    switch (type) {
      case "participation":
        return t.participation;
      case "completion":
        return t.completion;
      case "excellence":
        return t.excellence;
      default:
        return type;
    }
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "";
    const d = new Date(date);
    return d.toLocaleDateString(certLocaleMap[language] || "en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const renderCertificateCard = (cert: Certificate, isVerification = false) => {
    const Icon = certificateTypeIcons[cert.certificateType as keyof typeof certificateTypeIcons] || Award;
    const colorClass = certificateTypeColors[cert.certificateType as keyof typeof certificateTypeColors] || certificateTypeColors.completion;

    return (
      <Card key={cert.id} className={isVerification ? "" : "hover-elevate"}>
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <div className={`p-3 rounded-lg ${colorClass}`}>
              <Icon className="w-8 h-8" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-semibold text-lg">{cert.studentName}</h3>
                <Badge variant="secondary" className={colorClass}>
                  {getCertificateTypeName(cert.certificateType)}
                </Badge>
              </div>
              <p className="text-muted-foreground mt-1">
                {getSubjectName(cert.subject)}
              </p>
              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground flex-wrap">
                <span>{t.issuedOn}: {formatDate(cert.issuedAt)}</span>
                {cert.score && (
                  <Badge variant="outline">
                    {(certLabels[language] || certLabels.en).score(cert.score)}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2 mt-3">
                <code className="text-xs bg-muted px-2 py-1 rounded font-mono">
                  {cert.certificateCode}
                </code>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => copyCode(cert.certificateCode)}
                  data-testid={`button-copy-code-${cert.id}`}
                >
                  <Copy className="w-4 h-4" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => copyLink(cert.certificateCode)}
                  data-testid={`button-share-${cert.id}`}
                >
                  <Share className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent
        className={`max-w-2xl max-h-[90vh] overflow-y-auto ${isRTL ? "rtl" : "ltr"}`}
        dir={isRTL ? "rtl" : "ltr"}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ScrollText className="w-5 h-5 text-primary" />
            {t.myCertificates}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="list" data-testid="tab-certificates-list">
              {t.certificates}
            </TabsTrigger>
            <TabsTrigger value="verify" data-testid="tab-verify-certificate">
              {t.verifyCertificate}
            </TabsTrigger>
          </TabsList>

          <AnimatePresence mode="wait">
            <TabsContent value="list" className="mt-4">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-32 w-full" />
                    ))}
                  </div>
                ) : certificates.length === 0 ? (
                  <div className="text-center py-12">
                    <Award className="w-16 h-16 mx-auto text-muted-foreground/50" />
                    <h3 className="mt-4 text-lg font-medium">{t.noCertificates}</h3>
                    <p className="text-muted-foreground mt-2">{t.earnCertificates}</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {certificates.map((cert) => renderCertificateCard(cert))}
                  </div>
                )}
              </motion.div>
            </TabsContent>

            <TabsContent value="verify" className="mt-4">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">{t.verifyCertificate}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>{t.certificateCode}</Label>
                      <Input
                        value={verifyCode}
                        onChange={(e) => {
                          setVerifyCode(e.target.value);
                          setVerifyError(false);
                          setVerifiedCert(null);
                        }}
                        placeholder={t.enterCode}
                        className="mt-2 font-mono"
                        data-testid="input-verify-code"
                      />
                    </div>
                    <Button
                      className="w-full"
                      onClick={() => verifyCertificate.mutate()}
                      disabled={!verifyCode.trim() || verifyCertificate.isPending}
                      data-testid="button-verify-certificate"
                    >
                      {verifyCertificate.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin mr-2" />
                          {(certLabels[language] || certLabels.en).verifying}
                        </>
                      ) : (
                        <>
                          <CheckCircle className="w-4 h-4 mr-2" />
                          {t.verify}
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>

                {verifyError && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                  >
                    <Card className="border-destructive/50">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3 text-destructive">
                          <XCircle className="w-6 h-6" />
                          <div>
                            <p className="font-medium">{t.invalidCertificate}</p>
                            <p className="text-sm text-muted-foreground">
                              {t.invalidCertificateDesc}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}

                {verifiedCert && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                  >
                    <div className="mb-3 flex items-center gap-2 text-green-600 dark:text-green-400">
                      <CheckCircle className="w-5 h-5" />
                      <span className="font-medium">{t.verified}</span>
                    </div>
                    {renderCertificateCard(verifiedCert, true)}
                  </motion.div>
                )}
              </motion.div>
            </TabsContent>
          </AnimatePresence>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
