import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Lightbulb, CheckCircle, XCircle, RefreshCw, BookOpen } from "lucide-react";
import { getTranslation, Language } from "@/lib/translations";
import { apiRequest } from "@/lib/queryClient";
import { motion, AnimatePresence } from "framer-motion";

interface PracticeProblem {
  id: number;
  question: string;
  hints: string[];
  solution: string;
}

interface SubmitResult {
  isCorrect: boolean;
  solution: string;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  personalityId: number;
  subject: string;
  deviceId: string;
  language: Language;
}

const labels: Record<string, {
  practiceMode: string;
  selectDifficulty: string;
  generateProblem: string;
  generating: string;
  hint: string;
  noMoreHints: string;
  yourAnswer: string;
  answerPlaceholder: string;
  submit: string;
  submitting: string;
  correct: string;
  incorrect: string;
  solution: string;
  feedback: string;
  newProblem: string;
  close: string;
  hintsUsed: string;
  curriculum: string;
  educationLevel: string;
  topic: string;
  topicPlaceholder: string;
  curriculumOptions: Record<string, string>;
  levelOptions: Record<string, string>;
}> = {
  ar: {
    practiceMode: "وضع التمرين",
    selectDifficulty: "مستوى الصعوبة",
    generateProblem: "إنشاء مسألة",
    generating: "جاري إنشاء المسألة...",
    hint: "تلميح",
    noMoreHints: "لا توجد تلميحات إضافية",
    yourAnswer: "إجابتك",
    answerPlaceholder: "اكتب إجابتك هنا...",
    submit: "إرسال",
    submitting: "جاري التحقق...",
    correct: "إجابة صحيحة!",
    incorrect: "إجابة خاطئة",
    solution: "الحل",
    feedback: "ملاحظات",
    newProblem: "مسألة جديدة",
    close: "إغلاق",
    hintsUsed: "التلميحات المستخدمة",
    curriculum: "المنهج الدراسي",
    educationLevel: "المستوى التعليمي",
    topic: "الدرس / الموضوع",
    topicPlaceholder: "مثال: الكسور، قوانين نيوتن، المعادلات...",
    curriculumOptions: { general: "عام", yemeni: "يمني", saudi: "سعودي", egyptian: "مصري", jordanian: "أردني", iraqi: "عراقي", american: "أمريكي", british: "بريطاني", french: "فرنسي", ib: "البكالوريا الدولية (IB)" },
    levelOptions: { primary: "ابتدائي", middle: "إعدادي / متوسط", secondary: "ثانوي", university: "جامعي", general: "عام" },
  },
  en: {
    practiceMode: "Practice Mode",
    selectDifficulty: "Difficulty Level",
    generateProblem: "Generate Problem",
    generating: "Generating problem...",
    hint: "Hint",
    noMoreHints: "No more hints available",
    yourAnswer: "Your Answer",
    answerPlaceholder: "Type your answer here...",
    submit: "Submit",
    submitting: "Checking...",
    correct: "Correct!",
    incorrect: "Incorrect",
    solution: "Solution",
    feedback: "Feedback",
    newProblem: "New Problem",
    close: "Close",
    hintsUsed: "Hints Used",
    curriculum: "Curriculum",
    educationLevel: "Education Level",
    topic: "Lesson / Topic",
    topicPlaceholder: "e.g. Fractions, Newton's Laws, Equations...",
    curriculumOptions: { general: "General", yemeni: "Yemeni", saudi: "Saudi", egyptian: "Egyptian", jordanian: "Jordanian", iraqi: "Iraqi", american: "American", british: "British", french: "French", ib: "International Baccalaureate (IB)" },
    levelOptions: { primary: "Primary", middle: "Middle School", secondary: "High School", university: "University", general: "General" },
  },
  zh: {
    practiceMode: "练习模式",
    selectDifficulty: "难度等级",
    generateProblem: "生成题目",
    generating: "正在生成题目...",
    hint: "提示",
    noMoreHints: "没有更多提示",
    yourAnswer: "你的答案",
    answerPlaceholder: "在此输入你的答案...",
    submit: "提交",
    submitting: "检查中...",
    correct: "正确！",
    incorrect: "不正确",
    solution: "解答",
    feedback: "反馈",
    newProblem: "新题目",
    close: "关闭",
    hintsUsed: "已使用提示",
    curriculum: "课程体系",
    educationLevel: "教育水平",
    topic: "课程 / 主题",
    topicPlaceholder: "例如：分数、牛顿定律、方程式...",
    curriculumOptions: { general: "通用", yemeni: "也门", saudi: "沙特", egyptian: "埃及", jordanian: "约旦", iraqi: "伊拉克", american: "美国", british: "英国", french: "法国", ib: "国际文凭 (IB)" },
    levelOptions: { primary: "小学", middle: "初中", secondary: "高中", university: "大学", general: "通用" },
  },
  hi: {
    practiceMode: "अभ्यास मोड",
    selectDifficulty: "कठिनाई स्तर",
    generateProblem: "प्रश्न बनाएं",
    generating: "प्रश्न बना रहा है...",
    hint: "संकेत",
    noMoreHints: "और संकेत उपलब्ध नहीं",
    yourAnswer: "आपका उत्तर",
    answerPlaceholder: "अपना उत्तर यहाँ लिखें...",
    submit: "जमा करें",
    submitting: "जाँच हो रही है...",
    correct: "सही!",
    incorrect: "गलत",
    solution: "हल",
    feedback: "प्रतिक्रिया",
    newProblem: "नया प्रश्न",
    close: "बंद करें",
    hintsUsed: "प्रयुक्त संकेत",
    curriculum: "पाठ्यक्रम",
    educationLevel: "शिक्षा स्तर",
    topic: "पाठ / विषय",
    topicPlaceholder: "उदाहरण: भिन्न, न्यूटन के नियम, समीकरण...",
    curriculumOptions: { general: "सामान्य", yemeni: "यमनी", saudi: "सऊदी", egyptian: "मिस्री", jordanian: "जॉर्डन", iraqi: "इराकी", american: "अमेरिकी", british: "ब्रिटिश", french: "फ्रेंच", ib: "अंतर्राष्ट्रीय बैकलॉरिएट (IB)" },
    levelOptions: { primary: "प्राथमिक", middle: "माध्यमिक", secondary: "उच्च माध्यमिक", university: "विश्वविद्यालय", general: "सामान्य" },
  },
  es: {
    practiceMode: "Modo Practica",
    selectDifficulty: "Nivel de dificultad",
    generateProblem: "Generar problema",
    generating: "Generando problema...",
    hint: "Pista",
    noMoreHints: "No hay mas pistas",
    yourAnswer: "Tu respuesta",
    answerPlaceholder: "Escribe tu respuesta aqui...",
    submit: "Enviar",
    submitting: "Verificando...",
    correct: "Correcto!",
    incorrect: "Incorrecto",
    solution: "Solucion",
    feedback: "Comentarios",
    newProblem: "Nuevo problema",
    close: "Cerrar",
    hintsUsed: "Pistas usadas",
    curriculum: "Plan de estudios",
    educationLevel: "Nivel educativo",
    topic: "Leccion / Tema",
    topicPlaceholder: "Ej: Fracciones, Leyes de Newton, Ecuaciones...",
    curriculumOptions: { general: "General", yemeni: "Yemeni", saudi: "Saudi", egyptian: "Egipcio", jordanian: "Jordano", iraqi: "Iraqui", american: "Americano", british: "Britanico", french: "Frances", ib: "Bachillerato Internacional (IB)" },
    levelOptions: { primary: "Primaria", middle: "Secundaria", secondary: "Preparatoria", university: "Universidad", general: "General" },
  },
  fr: {
    practiceMode: "Mode Pratique",
    selectDifficulty: "Niveau de difficulte",
    generateProblem: "Generer un probleme",
    generating: "Generation du probleme...",
    hint: "Indice",
    noMoreHints: "Plus d'indices disponibles",
    yourAnswer: "Votre reponse",
    answerPlaceholder: "Tapez votre reponse ici...",
    submit: "Soumettre",
    submitting: "Verification...",
    correct: "Correct !",
    incorrect: "Incorrect",
    solution: "Solution",
    feedback: "Commentaires",
    newProblem: "Nouveau probleme",
    close: "Fermer",
    hintsUsed: "Indices utilises",
    curriculum: "Programme scolaire",
    educationLevel: "Niveau d'education",
    topic: "Lecon / Sujet",
    topicPlaceholder: "Ex: Fractions, Lois de Newton, Equations...",
    curriculumOptions: { general: "General", yemeni: "Yemenite", saudi: "Saoudien", egyptian: "Egyptien", jordanian: "Jordanien", iraqi: "Irakien", american: "Americain", british: "Britannique", french: "Francais", ib: "Baccalaureat International (IB)" },
    levelOptions: { primary: "Primaire", middle: "College", secondary: "Lycee", university: "Universite", general: "General" },
  },
  bn: {
    practiceMode: "অনুশীলন মোড",
    selectDifficulty: "কঠিনতার স্তর",
    generateProblem: "সমস্যা তৈরি করুন",
    generating: "সমস্যা তৈরি হচ্ছে...",
    hint: "ইঙ্গিত",
    noMoreHints: "আর ইঙ্গিত নেই",
    yourAnswer: "আপনার উত্তর",
    answerPlaceholder: "এখানে আপনার উত্তর লিখুন...",
    submit: "জমা দিন",
    submitting: "যাচাই হচ্ছে...",
    correct: "সঠিক!",
    incorrect: "ভুল",
    solution: "সমাধান",
    feedback: "মতামত",
    newProblem: "নতুন সমস্যা",
    close: "বন্ধ করুন",
    hintsUsed: "ব্যবহৃত ইঙ্গিত",
    curriculum: "পাঠ্যক্রম",
    educationLevel: "শিক্ষার স্তর",
    topic: "পাঠ / বিষয়",
    topicPlaceholder: "উদাহরণ: ভগ্নাংশ, নিউটনের সূত্র, সমীকরণ...",
    curriculumOptions: { general: "সাধারণ", yemeni: "ইয়েমেনি", saudi: "সৌদি", egyptian: "মিশরীয়", jordanian: "জর্ডানীয়", iraqi: "ইরাকি", american: "আমেরিকান", british: "ব্রিটিশ", french: "ফরাসি", ib: "আন্তর্জাতিক ব্যাকালরেট (IB)" },
    levelOptions: { primary: "প্রাথমিক", middle: "মাধ্যমিক", secondary: "উচ্চ মাধ্যমিক", university: "বিশ্ববিদ্যালয়", general: "সাধারণ" },
  },
  pt: {
    practiceMode: "Modo Pratica",
    selectDifficulty: "Nivel de dificuldade",
    generateProblem: "Gerar problema",
    generating: "Gerando problema...",
    hint: "Dica",
    noMoreHints: "Sem mais dicas",
    yourAnswer: "Sua resposta",
    answerPlaceholder: "Digite sua resposta aqui...",
    submit: "Enviar",
    submitting: "Verificando...",
    correct: "Correto!",
    incorrect: "Incorreto",
    solution: "Solucao",
    feedback: "Feedback",
    newProblem: "Novo problema",
    close: "Fechar",
    hintsUsed: "Dicas usadas",
    curriculum: "Curriculo",
    educationLevel: "Nivel educacional",
    topic: "Licao / Topico",
    topicPlaceholder: "Ex: Fracoes, Leis de Newton, Equacoes...",
    curriculumOptions: { general: "Geral", yemeni: "Iemenita", saudi: "Saudita", egyptian: "Egipcio", jordanian: "Jordaniano", iraqi: "Iraquiano", american: "Americano", british: "Britanico", french: "Frances", ib: "Bacharelado Internacional (IB)" },
    levelOptions: { primary: "Fundamental I", middle: "Fundamental II", secondary: "Ensino Medio", university: "Universidade", general: "Geral" },
  },
  ru: {
    practiceMode: "Режим практики",
    selectDifficulty: "Уровень сложности",
    generateProblem: "Создать задачу",
    generating: "Создание задачи...",
    hint: "Подсказка",
    noMoreHints: "Больше подсказок нет",
    yourAnswer: "Ваш ответ",
    answerPlaceholder: "Введите ваш ответ здесь...",
    submit: "Отправить",
    submitting: "Проверка...",
    correct: "Правильно!",
    incorrect: "Неправильно",
    solution: "Решение",
    feedback: "Отзыв",
    newProblem: "Новая задача",
    close: "Закрыть",
    hintsUsed: "Использовано подсказок",
    curriculum: "Учебная программа",
    educationLevel: "Уровень образования",
    topic: "Урок / Тема",
    topicPlaceholder: "Например: Дроби, Законы Ньютона, Уравнения...",
    curriculumOptions: { general: "Общая", yemeni: "Йеменская", saudi: "Саудовская", egyptian: "Египетская", jordanian: "Иорданская", iraqi: "Иракская", american: "Американская", british: "Британская", french: "Французская", ib: "Международный бакалавриат (IB)" },
    levelOptions: { primary: "Начальная школа", middle: "Средняя школа", secondary: "Старшая школа", university: "Университет", general: "Общий" },
  },
  ja: {
    practiceMode: "練習モード",
    selectDifficulty: "難易度レベル",
    generateProblem: "問題を生成",
    generating: "問題を生成中...",
    hint: "ヒント",
    noMoreHints: "ヒントはもうありません",
    yourAnswer: "あなたの回答",
    answerPlaceholder: "ここに回答を入力...",
    submit: "提出",
    submitting: "確認中...",
    correct: "正解!",
    incorrect: "不正解",
    solution: "解答",
    feedback: "フィードバック",
    newProblem: "新しい問題",
    close: "閉じる",
    hintsUsed: "使用したヒント",
    curriculum: "カリキュラム",
    educationLevel: "教育レベル",
    topic: "レッスン / トピック",
    topicPlaceholder: "例：分数、ニュートンの法則、方程式...",
    curriculumOptions: { general: "一般", yemeni: "イエメン", saudi: "サウジ", egyptian: "エジプト", jordanian: "ヨルダン", iraqi: "イラク", american: "アメリカ", british: "イギリス", french: "フランス", ib: "国際バカロレア (IB)" },
    levelOptions: { primary: "小学校", middle: "中学校", secondary: "高校", university: "大学", general: "一般" },
  },
};

export function PracticeModeModal({ open, onOpenChange, personalityId, subject, deviceId, language }: Props) {
  const t = getTranslation(language);
  const l = labels[language] || labels.en;
  const isRTL = language === "ar";

  const [step, setStep] = useState<"config" | "problem" | "result">("config");
  const [difficulty, setDifficulty] = useState("medium");
  const [curriculum, setCurriculum] = useState("general");
  const [educationLevel, setEducationLevel] = useState("general");
  const [topic, setTopic] = useState("");
  const [problem, setProblem] = useState<PracticeProblem | null>(null);
  const [revealedHints, setRevealedHints] = useState<number>(0);
  const [answer, setAnswer] = useState("");
  const [result, setResult] = useState<SubmitResult | null>(null);

  const generateProblem = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/practice/generate", {
        deviceId,
        personalityId,
        subject,
        difficulty,
        curriculum,
        educationLevel,
        topic: topic.trim() || undefined,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setProblem(data);
      setStep("problem");
      setRevealedHints(0);
      setAnswer("");
      setResult(null);
    },
  });

  const submitAnswer = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/practice/${problem?.id}/submit`, {
        deviceId,
        answer,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setResult(data);
      setStep("result");
    },
  });

  const handleClose = () => {
    setStep("config");
    setProblem(null);
    setRevealedHints(0);
    setAnswer("");
    setResult(null);
    onOpenChange(false);
  };

  const handleNewProblem = () => {
    setStep("config");
    setProblem(null);
    setRevealedHints(0);
    setAnswer("");
    setResult(null);
  };

  const revealNextHint = () => {
    if (problem && revealedHints < problem.hints.length) {
      setRevealedHints(revealedHints + 1);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className={`max-w-2xl max-h-[90vh] overflow-y-auto ${isRTL ? "rtl" : "ltr"}`} dir={isRTL ? "rtl" : "ltr"}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary" />
            {l.practiceMode}
          </DialogTitle>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {step === "config" && (
            <motion.div
              key="config"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm">{l.curriculum}</Label>
                  <Select value={curriculum} onValueChange={setCurriculum}>
                    <SelectTrigger className="mt-1.5" data-testid="select-practice-curriculum">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(l.curriculumOptions).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm">{l.educationLevel}</Label>
                  <Select value={educationLevel} onValueChange={setEducationLevel}>
                    <SelectTrigger className="mt-1.5" data-testid="select-practice-level">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(l.levelOptions).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-sm">{l.selectDifficulty}</Label>
                <RadioGroup
                  value={difficulty}
                  onValueChange={setDifficulty}
                  className="flex gap-4 mt-1.5"
                >
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <RadioGroupItem value="easy" id="difficulty-easy" data-testid="radio-difficulty-easy" />
                    <Label htmlFor="difficulty-easy" className="cursor-pointer">{t.easy}</Label>
                  </div>
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <RadioGroupItem value="medium" id="difficulty-medium" data-testid="radio-difficulty-medium" />
                    <Label htmlFor="difficulty-medium" className="cursor-pointer">{t.medium}</Label>
                  </div>
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <RadioGroupItem value="hard" id="difficulty-hard" data-testid="radio-difficulty-hard" />
                    <Label htmlFor="difficulty-hard" className="cursor-pointer">{t.hard}</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label className="text-sm">{l.topic}</Label>
                <Input
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder={l.topicPlaceholder}
                  className="mt-1.5"
                  data-testid="input-practice-topic"
                />
              </div>

              <Button
                onClick={() => generateProblem.mutate()}
                disabled={generateProblem.isPending}
                className="w-full"
                data-testid="button-generate-problem"
              >
                {generateProblem.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    {l.generating}
                  </>
                ) : (
                  l.generateProblem
                )}
              </Button>
            </motion.div>
          )}

          {step === "problem" && problem && (
            <motion.div
              key="problem"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium leading-relaxed">{problem.question}</h3>
                </CardContent>
              </Card>

              {problem.hints.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={revealNextHint}
                      disabled={revealedHints >= problem.hints.length}
                      data-testid="button-hint"
                    >
                      <Lightbulb className="w-4 h-4" />
                      {l.hint}
                    </Button>
                    <span className="text-sm text-muted-foreground">
                      {l.hintsUsed}: {revealedHints} / {problem.hints.length}
                    </span>
                  </div>

                  {revealedHints > 0 && (
                    <div className="space-y-2">
                      {problem.hints.slice(0, revealedHints).map((hint, index) => (
                        <Card key={index} className="bg-muted/50">
                          <CardContent className="p-3">
                            <div className="flex items-start gap-2">
                              <Lightbulb className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
                              <p className="text-sm">{hint}</p>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="answer">{l.yourAnswer}</Label>
                <Textarea
                  id="answer"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder={l.answerPlaceholder}
                  className="min-h-[100px]"
                  data-testid="textarea-answer"
                />
              </div>

              <Button
                onClick={() => submitAnswer.mutate()}
                disabled={!answer.trim() || submitAnswer.isPending}
                className="w-full"
                data-testid="button-submit-answer"
              >
                {submitAnswer.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    {l.submitting}
                  </>
                ) : (
                  l.submit
                )}
              </Button>
            </motion.div>
          )}

          {step === "result" && result && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <div className="text-center py-6">
                {result.isCorrect ? (
                  <div className="flex flex-col items-center gap-3">
                    <CheckCircle className="w-16 h-16 text-green-500" />
                    <p className="text-2xl font-bold text-green-500">{l.correct}</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3">
                    <XCircle className="w-16 h-16 text-red-500" />
                    <p className="text-2xl font-bold text-red-500">{l.incorrect}</p>
                  </div>
                )}
              </div>

              <Card className={result.isCorrect ? "border-green-500/50" : "border-red-500/50"}>
                <CardContent className="p-4 space-y-4">
                  <div>
                    <p className="font-medium text-muted-foreground mb-1">{l.solution}</p>
                    <p className="leading-relaxed">{result.solution}</p>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handleNewProblem}
                  className="flex-1"
                  data-testid="button-new-problem"
                >
                  <RefreshCw className="w-4 h-4" />
                  {l.newProblem}
                </Button>
                <Button
                  onClick={handleClose}
                  className="flex-1"
                  data-testid="button-close-practice"
                >
                  {l.close}
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
