import { useState, useEffect } from "react";
import { WifiOff } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const offlineLabels: Record<string, string> = {
  ar: "أنت غير متصل بالإنترنت",
  en: "You are offline",
  zh: "您当前离线",
  hi: "आप ऑफ़लाइन हैं",
  es: "Estás sin conexión",
  fr: "Vous êtes hors ligne",
  bn: "আপনি অফলাইনে আছেন",
  pt: "Você está offline",
  ru: "Вы не в сети",
  ja: "オフラインです",
};

export function OfflineIndicator() {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const { language } = useLanguage();

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  if (!isOffline) return null;

  const label = offlineLabels[language] || offlineLabels.en;

  return (
    <div
      className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-destructive text-destructive-foreground px-4 py-2 rounded-md shadow-lg"
      data-testid="offline-indicator"
    >
      <WifiOff className="h-4 w-4" />
      <span className="text-sm font-medium">{label}</span>
    </div>
  );
}
