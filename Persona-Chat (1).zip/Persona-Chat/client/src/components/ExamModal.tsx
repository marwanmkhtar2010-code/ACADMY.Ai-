import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, XCircle, Trophy, ChevronLeft, ChevronRight, GraduationCap, Award, ScrollText, Copy, Share } from "lucide-react";
import { getTranslation, Language } from "@/lib/translations";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

const examLabels: Record<string, {
  examTitle: string;
  examDesc: string;
  examScope: string;
  unitExam: string;
  chapterExam: string;
  fullCurriculumExam: string;
  semesterExam: string;
  unitName: string;
  unitPlaceholder: string;
  chapterName: string;
  chapterPlaceholder: string;
  studentName: string;
  studentNamePlaceholder: string;
  numQuestions: string;
  startExam: string;
  generatingExam: string;
  questionOf: (c: number, t: number) => string;
  submitExam: string;
  examResult: string;
  passed: string;
  failed: string;
  passingGrade: string;
  yourScore: string;
  certificateEarned: string;
  certificateEarnedDesc: string;
  tryAgain: string;
  close: string;
  reviewAnswers: string;
  correctAnswer: string;
  explanation: string;
  certificateCode: string;
  copyCertCode: string;
  shareCert: string;
  curriculum: string;
  educationLevel: string;
  curriculumOptions: Record<string, string>;
  levelOptions: Record<string, string>;
  examSubject: string;
}> = {
  ar: {
    examTitle: "الامتحان الشامل",
    examDesc: "اجتز الامتحان واحصل على شهادة معتمدة",
    examScope: "نطاق الامتحان",
    unitExam: "امتحان وحدة",
    chapterExam: "امتحان فصل دراسي",
    fullCurriculumExam: "امتحان المنهج الكامل",
    semesterExam: "امتحان نصف السنة",
    unitName: "اسم الوحدة",
    unitPlaceholder: "مثال: الوحدة الأولى - الكسور",
    chapterName: "اسم الفصل",
    chapterPlaceholder: "مثال: الفصل الأول - الميكانيكا",
    studentName: "اسم الطالب",
    studentNamePlaceholder: "أدخل اسمك الكامل للشهادة",
    numQuestions: "عدد الأسئلة",
    startExam: "ابدأ الامتحان",
    generatingExam: "جاري إنشاء الامتحان...",
    questionOf: (c, t) => `السؤال ${c} من ${t}`,
    submitExam: "تسليم الامتحان",
    examResult: "نتيجة الامتحان",
    passed: "ناجح! مبروك!",
    failed: "لم تجتز الامتحان",
    passingGrade: "درجة النجاح: 70%",
    yourScore: "درجتك",
    certificateEarned: "تم الحصول على شهادة!",
    certificateEarnedDesc: "مبروك! لقد حصلت على شهادة اجتياز الامتحان",
    tryAgain: "حاول مرة أخرى",
    close: "إغلاق",
    reviewAnswers: "مراجعة الإجابات",
    correctAnswer: "الإجابة الصحيحة",
    explanation: "الشرح",
    certificateCode: "رمز الشهادة",
    copyCertCode: "نسخ الرمز",
    shareCert: "مشاركة الشهادة",
    curriculum: "المنهج الدراسي",
    educationLevel: "المستوى التعليمي",
    curriculumOptions: { general: "عام", yemeni: "يمني", saudi: "سعودي", egyptian: "مصري", jordanian: "أردني", iraqi: "عراقي", american: "أمريكي", british: "بريطاني", french: "فرنسي", ib: "البكالوريا الدولية (IB)" },
    levelOptions: { primary: "ابتدائي", middle: "إعدادي / متوسط", secondary: "ثانوي", university: "جامعي", general: "عام" },
    examSubject: "المادة",
  },
  en: {
    examTitle: "Comprehensive Exam",
    examDesc: "Pass the exam and earn a certified certificate",
    examScope: "Exam Scope",
    unitExam: "Unit Exam",
    chapterExam: "Chapter Exam",
    fullCurriculumExam: "Full Curriculum Exam",
    semesterExam: "Semester Exam",
    unitName: "Unit Name",
    unitPlaceholder: "e.g. Unit 1 - Fractions",
    chapterName: "Chapter Name",
    chapterPlaceholder: "e.g. Chapter 1 - Mechanics",
    studentName: "Student Name",
    studentNamePlaceholder: "Enter your full name for the certificate",
    numQuestions: "Number of Questions",
    startExam: "Start Exam",
    generatingExam: "Generating exam...",
    questionOf: (c, t) => `Question ${c} of ${t}`,
    submitExam: "Submit Exam",
    examResult: "Exam Result",
    passed: "Passed! Congratulations!",
    failed: "Did not pass the exam",
    passingGrade: "Passing grade: 70%",
    yourScore: "Your Score",
    certificateEarned: "Certificate Earned!",
    certificateEarnedDesc: "Congratulations! You have earned an exam completion certificate",
    tryAgain: "Try Again",
    close: "Close",
    reviewAnswers: "Review Answers",
    correctAnswer: "Correct Answer",
    explanation: "Explanation",
    certificateCode: "Certificate Code",
    copyCertCode: "Copy Code",
    shareCert: "Share Certificate",
    curriculum: "Curriculum",
    educationLevel: "Education Level",
    curriculumOptions: { general: "General", yemeni: "Yemeni", saudi: "Saudi", egyptian: "Egyptian", jordanian: "Jordanian", iraqi: "Iraqi", american: "American", british: "British", french: "French", ib: "International Baccalaureate (IB)" },
    levelOptions: { primary: "Primary", middle: "Middle School", secondary: "High School", university: "University", general: "General" },
    examSubject: "Subject",
  },
  zh: {
    examTitle: "综合考试",
    examDesc: "通过考试并获得认证证书",
    examScope: "考试范围",
    unitExam: "单元考试",
    chapterExam: "章节考试",
    fullCurriculumExam: "全课程考试",
    semesterExam: "学期考试",
    unitName: "单元名称",
    unitPlaceholder: "例如：第一单元 - 分数",
    chapterName: "章节名称",
    chapterPlaceholder: "例如：第一章 - 力学",
    studentName: "学生姓名",
    studentNamePlaceholder: "输入您的全名用于证书",
    numQuestions: "题目数量",
    startExam: "开始考试",
    generatingExam: "正在生成考试...",
    questionOf: (c, t) => `第 ${c} 题，共 ${t} 题`,
    submitExam: "提交考试",
    examResult: "考试结果",
    passed: "通过！恭喜！",
    failed: "未通过考试",
    passingGrade: "及格线：70%",
    yourScore: "您的成绩",
    certificateEarned: "获得证书！",
    certificateEarnedDesc: "恭喜！您已获得考试通过证书",
    tryAgain: "再试一次",
    close: "关闭",
    reviewAnswers: "查看答案",
    correctAnswer: "正确答案",
    explanation: "解释",
    certificateCode: "证书编码",
    copyCertCode: "复制编码",
    shareCert: "分享证书",
    curriculum: "课程体系",
    educationLevel: "教育水平",
    curriculumOptions: { general: "通用", yemeni: "也门", saudi: "沙特", egyptian: "埃及", jordanian: "约旦", iraqi: "伊拉克", american: "美国", british: "英国", french: "法国", ib: "国际文凭 (IB)" },
    levelOptions: { primary: "小学", middle: "初中", secondary: "高中", university: "大学", general: "通用" },
    examSubject: "科目",
  },
  hi: {
    examTitle: "व्यापक परीक्षा",
    examDesc: "परीक्षा उत्तीर्ण करें और प्रमाणित प्रमाणपत्र प्राप्त करें",
    examScope: "परीक्षा का दायरा",
    unitExam: "इकाई परीक्षा",
    chapterExam: "अध्याय परीक्षा",
    fullCurriculumExam: "पूर्ण पाठ्यक्रम परीक्षा",
    semesterExam: "सेमेस्टर परीक्षा",
    unitName: "इकाई का नाम",
    unitPlaceholder: "उदाहरण: इकाई 1 - भिन्न",
    chapterName: "अध्याय का नाम",
    chapterPlaceholder: "उदाहरण: अध्याय 1 - यांत्रिकी",
    studentName: "छात्र का नाम",
    studentNamePlaceholder: "प्रमाणपत्र के लिए अपना पूरा नाम दर्ज करें",
    numQuestions: "प्रश्नों की संख्या",
    startExam: "परीक्षा शुरू करें",
    generatingExam: "परीक्षा बना रहा है...",
    questionOf: (c, t) => `प्रश्न ${c} / ${t}`,
    submitExam: "परीक्षा जमा करें",
    examResult: "परीक्षा परिणाम",
    passed: "उत्तीर्ण! बधाई!",
    failed: "परीक्षा उत्तीर्ण नहीं हुई",
    passingGrade: "उत्तीर्ण अंक: 70%",
    yourScore: "आपका स्कोर",
    certificateEarned: "प्रमाणपत्र प्राप्त!",
    certificateEarnedDesc: "बधाई! आपने परीक्षा उत्तीर्ण प्रमाणपत्र प्राप्त किया",
    tryAgain: "फिर से प्रयास करें",
    close: "बंद करें",
    reviewAnswers: "उत्तर समीक्षा",
    correctAnswer: "सही उत्तर",
    explanation: "व्याख्या",
    certificateCode: "प्रमाणपत्र कोड",
    copyCertCode: "कोड कॉपी करें",
    shareCert: "प्रमाणपत्र साझा करें",
    curriculum: "पाठ्यक्रम",
    educationLevel: "शिक्षा स्तर",
    curriculumOptions: { general: "सामान्य", yemeni: "यमनी", saudi: "सऊदी", egyptian: "मिस्री", jordanian: "जॉर्डन", iraqi: "इराकी", american: "अमेरिकी", british: "ब्रिटिश", french: "फ्रेंच", ib: "अंतर्राष्ट्रीय बैकलॉरिएट (IB)" },
    levelOptions: { primary: "प्राथमिक", middle: "माध्यमिक", secondary: "उच्च माध्यमिक", university: "विश्वविद्यालय", general: "सामान्य" },
    examSubject: "विषय",
  },
  es: {
    examTitle: "Examen Integral",
    examDesc: "Aprueba el examen y obtén un certificado",
    examScope: "Alcance del examen",
    unitExam: "Examen de unidad",
    chapterExam: "Examen de capítulo",
    fullCurriculumExam: "Examen del currículo completo",
    semesterExam: "Examen semestral",
    unitName: "Nombre de la unidad",
    unitPlaceholder: "Ej: Unidad 1 - Fracciones",
    chapterName: "Nombre del capítulo",
    chapterPlaceholder: "Ej: Capítulo 1 - Mecánica",
    studentName: "Nombre del estudiante",
    studentNamePlaceholder: "Ingresa tu nombre completo para el certificado",
    numQuestions: "Número de preguntas",
    startExam: "Iniciar examen",
    generatingExam: "Generando examen...",
    questionOf: (c, t) => `Pregunta ${c} de ${t}`,
    submitExam: "Entregar examen",
    examResult: "Resultado del examen",
    passed: "Aprobado! Felicidades!",
    failed: "No aprobaste el examen",
    passingGrade: "Nota de aprobación: 70%",
    yourScore: "Tu puntuación",
    certificateEarned: "Certificado obtenido!",
    certificateEarnedDesc: "Felicidades! Has obtenido un certificado de aprobación",
    tryAgain: "Intentar de nuevo",
    close: "Cerrar",
    reviewAnswers: "Revisar respuestas",
    correctAnswer: "Respuesta correcta",
    explanation: "Explicación",
    certificateCode: "Código del certificado",
    copyCertCode: "Copiar código",
    shareCert: "Compartir certificado",
    curriculum: "Plan de estudios",
    educationLevel: "Nivel educativo",
    curriculumOptions: { general: "General", yemeni: "Yemení", saudi: "Saudí", egyptian: "Egipcio", jordanian: "Jordano", iraqi: "Iraquí", american: "Americano", british: "Británico", french: "Francés", ib: "Bachillerato Internacional (IB)" },
    levelOptions: { primary: "Primaria", middle: "Secundaria", secondary: "Preparatoria", university: "Universidad", general: "General" },
    examSubject: "Materia",
  },
  fr: {
    examTitle: "Examen Complet",
    examDesc: "Réussissez l'examen et obtenez un certificat",
    examScope: "Portée de l'examen",
    unitExam: "Examen d'unité",
    chapterExam: "Examen de chapitre",
    fullCurriculumExam: "Examen du programme complet",
    semesterExam: "Examen semestriel",
    unitName: "Nom de l'unité",
    unitPlaceholder: "Ex: Unité 1 - Fractions",
    chapterName: "Nom du chapitre",
    chapterPlaceholder: "Ex: Chapitre 1 - Mécanique",
    studentName: "Nom de l'étudiant",
    studentNamePlaceholder: "Entrez votre nom complet pour le certificat",
    numQuestions: "Nombre de questions",
    startExam: "Commencer l'examen",
    generatingExam: "Génération de l'examen...",
    questionOf: (c, t) => `Question ${c} sur ${t}`,
    submitExam: "Soumettre l'examen",
    examResult: "Résultat de l'examen",
    passed: "Réussi! Félicitations!",
    failed: "Examen non réussi",
    passingGrade: "Note de passage: 70%",
    yourScore: "Votre score",
    certificateEarned: "Certificat obtenu!",
    certificateEarnedDesc: "Félicitations! Vous avez obtenu un certificat de réussite",
    tryAgain: "Réessayer",
    close: "Fermer",
    reviewAnswers: "Revoir les réponses",
    correctAnswer: "Bonne réponse",
    explanation: "Explication",
    certificateCode: "Code du certificat",
    copyCertCode: "Copier le code",
    shareCert: "Partager le certificat",
    curriculum: "Programme scolaire",
    educationLevel: "Niveau d'éducation",
    curriculumOptions: { general: "Général", yemeni: "Yéménite", saudi: "Saoudien", egyptian: "Égyptien", jordanian: "Jordanien", iraqi: "Irakien", american: "Américain", british: "Britannique", french: "Français", ib: "Baccalauréat International (IB)" },
    levelOptions: { primary: "Primaire", middle: "Collège", secondary: "Lycée", university: "Université", general: "Général" },
    examSubject: "Matière",
  },
  bn: {
    examTitle: "সম্পূর্ণ পরীক্ষা",
    examDesc: "পরীক্ষায় উত্তীর্ণ হন এবং সার্টিফিকেট পান",
    examScope: "পরীক্ষার পরিসর",
    unitExam: "ইউনিট পরীক্ষা",
    chapterExam: "অধ্যায় পরীক্ষা",
    fullCurriculumExam: "সম্পূর্ণ পাঠ্যক্রম পরীক্ষা",
    semesterExam: "সেমিস্টার পরীক্ষা",
    unitName: "ইউনিটের নাম",
    unitPlaceholder: "উদাহরণ: ইউনিট ১ - ভগ্নাংশ",
    chapterName: "অধ্যায়ের নাম",
    chapterPlaceholder: "উদাহরণ: অধ্যায় ১ - বলবিদ্যা",
    studentName: "ছাত্রের নাম",
    studentNamePlaceholder: "সার্টিফিকেটের জন্য আপনার পূর্ণ নাম লিখুন",
    numQuestions: "প্রশ্নের সংখ্যা",
    startExam: "পরীক্ষা শুরু করুন",
    generatingExam: "পরীক্ষা তৈরি হচ্ছে...",
    questionOf: (c, t) => `প্রশ্ন ${c} / ${t}`,
    submitExam: "পরীক্ষা জমা দিন",
    examResult: "পরীক্ষার ফলাফল",
    passed: "উত্তীর্ণ! অভিনন্দন!",
    failed: "পরীক্ষায় উত্তীর্ণ হননি",
    passingGrade: "পাসিং গ্রেড: ৭০%",
    yourScore: "আপনার স্কোর",
    certificateEarned: "সার্টিফিকেট পেয়েছেন!",
    certificateEarnedDesc: "অভিনন্দন! আপনি পরীক্ষা উত্তীর্ণ সার্টিফিকেট পেয়েছেন",
    tryAgain: "আবার চেষ্টা করুন",
    close: "বন্ধ করুন",
    reviewAnswers: "উত্তর পর্যালোচনা",
    correctAnswer: "সঠিক উত্তর",
    explanation: "ব্যাখ্যা",
    certificateCode: "সার্টিফিকেট কোড",
    copyCertCode: "কোড কপি করুন",
    shareCert: "সার্টিফিকেট শেয়ার করুন",
    curriculum: "পাঠ্যক্রম",
    educationLevel: "শিক্ষার স্তর",
    curriculumOptions: { general: "সাধারণ", yemeni: "ইয়েমেনি", saudi: "সৌদি", egyptian: "মিশরীয়", jordanian: "জর্ডানীয়", iraqi: "ইরাকি", american: "আমেরিকান", british: "ব্রিটিশ", french: "ফরাসি", ib: "আন্তর্জাতিক ব্যাকালরেট (IB)" },
    levelOptions: { primary: "প্রাথমিক", middle: "মাধ্যমিক", secondary: "উচ্চ মাধ্যমিক", university: "বিশ্ববিদ্যালয়", general: "সাধারণ" },
    examSubject: "বিষয়",
  },
  pt: {
    examTitle: "Exame Completo",
    examDesc: "Passe no exame e ganhe um certificado",
    examScope: "Escopo do exame",
    unitExam: "Exame de unidade",
    chapterExam: "Exame de capítulo",
    fullCurriculumExam: "Exame do currículo completo",
    semesterExam: "Exame semestral",
    unitName: "Nome da unidade",
    unitPlaceholder: "Ex: Unidade 1 - Frações",
    chapterName: "Nome do capítulo",
    chapterPlaceholder: "Ex: Capítulo 1 - Mecânica",
    studentName: "Nome do estudante",
    studentNamePlaceholder: "Digite seu nome completo para o certificado",
    numQuestions: "Número de questões",
    startExam: "Iniciar exame",
    generatingExam: "Gerando exame...",
    questionOf: (c, t) => `Questão ${c} de ${t}`,
    submitExam: "Enviar exame",
    examResult: "Resultado do exame",
    passed: "Aprovado! Parabéns!",
    failed: "Não passou no exame",
    passingGrade: "Nota de aprovação: 70%",
    yourScore: "Sua pontuação",
    certificateEarned: "Certificado obtido!",
    certificateEarnedDesc: "Parabéns! Você obteve um certificado de aprovação",
    tryAgain: "Tentar novamente",
    close: "Fechar",
    reviewAnswers: "Revisar respostas",
    correctAnswer: "Resposta correta",
    explanation: "Explicação",
    certificateCode: "Código do certificado",
    copyCertCode: "Copiar código",
    shareCert: "Compartilhar certificado",
    curriculum: "Currículo",
    educationLevel: "Nível educacional",
    curriculumOptions: { general: "Geral", yemeni: "Iemenita", saudi: "Saudita", egyptian: "Egípcio", jordanian: "Jordaniano", iraqi: "Iraquiano", american: "Americano", british: "Britânico", french: "Francês", ib: "Bacharelado Internacional (IB)" },
    levelOptions: { primary: "Fundamental I", middle: "Fundamental II", secondary: "Ensino Médio", university: "Universidade", general: "Geral" },
    examSubject: "Disciplina",
  },
  ru: {
    examTitle: "Комплексный экзамен",
    examDesc: "Сдайте экзамен и получите сертификат",
    examScope: "Объём экзамена",
    unitExam: "Экзамен по разделу",
    chapterExam: "Экзамен по главе",
    fullCurriculumExam: "Экзамен по полной программе",
    semesterExam: "Семестровый экзамен",
    unitName: "Название раздела",
    unitPlaceholder: "Напр.: Раздел 1 - Дроби",
    chapterName: "Название главы",
    chapterPlaceholder: "Напр.: Глава 1 - Механика",
    studentName: "Имя ученика",
    studentNamePlaceholder: "Введите полное имя для сертификата",
    numQuestions: "Количество вопросов",
    startExam: "Начать экзамен",
    generatingExam: "Создание экзамена...",
    questionOf: (c, t) => `Вопрос ${c} из ${t}`,
    submitExam: "Сдать экзамен",
    examResult: "Результат экзамена",
    passed: "Сдано! Поздравляем!",
    failed: "Экзамен не сдан",
    passingGrade: "Проходной балл: 70%",
    yourScore: "Ваш результат",
    certificateEarned: "Сертификат получен!",
    certificateEarnedDesc: "Поздравляем! Вы получили сертификат о сдаче экзамена",
    tryAgain: "Попробовать снова",
    close: "Закрыть",
    reviewAnswers: "Обзор ответов",
    correctAnswer: "Правильный ответ",
    explanation: "Пояснение",
    certificateCode: "Код сертификата",
    copyCertCode: "Копировать код",
    shareCert: "Поделиться сертификатом",
    curriculum: "Учебная программа",
    educationLevel: "Уровень образования",
    curriculumOptions: { general: "Общая", yemeni: "Йеменская", saudi: "Саудовская", egyptian: "Египетская", jordanian: "Иорданская", iraqi: "Иракская", american: "Американская", british: "Британская", french: "Французская", ib: "Международный бакалавриат (IB)" },
    levelOptions: { primary: "Начальная школа", middle: "Средняя школа", secondary: "Старшая школа", university: "Университет", general: "Общий" },
    examSubject: "Предмет",
  },
  ja: {
    examTitle: "総合試験",
    examDesc: "試験に合格して証明書を取得しましょう",
    examScope: "試験範囲",
    unitExam: "単元試験",
    chapterExam: "章試験",
    fullCurriculumExam: "全カリキュラム試験",
    semesterExam: "学期試験",
    unitName: "単元名",
    unitPlaceholder: "例：第1単元 - 分数",
    chapterName: "章名",
    chapterPlaceholder: "例：第1章 - 力学",
    studentName: "生徒名",
    studentNamePlaceholder: "証明書に記載するフルネームを入力",
    numQuestions: "問題数",
    startExam: "試験開始",
    generatingExam: "試験を作成中...",
    questionOf: (c, t) => `問題 ${c} / ${t}`,
    submitExam: "試験を提出",
    examResult: "試験結果",
    passed: "合格！おめでとうございます！",
    failed: "試験に不合格",
    passingGrade: "合格ライン：70%",
    yourScore: "あなたの得点",
    certificateEarned: "証明書取得！",
    certificateEarnedDesc: "おめでとうございます！試験合格証明書を取得しました",
    tryAgain: "もう一度挑戦",
    close: "閉じる",
    reviewAnswers: "回答を確認",
    correctAnswer: "正解",
    explanation: "解説",
    certificateCode: "証明書コード",
    copyCertCode: "コードをコピー",
    shareCert: "証明書を共有",
    curriculum: "カリキュラム",
    educationLevel: "教育レベル",
    curriculumOptions: { general: "一般", yemeni: "イエメン", saudi: "サウジ", egyptian: "エジプト", jordanian: "ヨルダン", iraqi: "イラク", american: "アメリカ", british: "イギリス", french: "フランス", ib: "国際バカロレア (IB)" },
    levelOptions: { primary: "小学校", middle: "中学校", secondary: "高校", university: "大学", general: "一般" },
    examSubject: "科目",
  },
};

interface ExamQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface ExamData {
  title: string;
  questions: ExamQuestion[];
}

interface ExamResult {
  score: number;
  correctCount: number;
  totalQuestions: number;
  passed: boolean;
  certificate?: {
    id: number;
    certificateCode: string;
    certificateType: string;
    studentName: string;
    subject: string;
    score: number;
  };
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  personalityId: number;
  subject: string;
  deviceId: string;
  language: Language;
}

export function ExamModal({ open, onOpenChange, personalityId, subject, deviceId, language }: Props) {
  const t = getTranslation(language);
  const isRTL = language === "ar";
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const el = examLabels[language] || examLabels.en;

  const [step, setStep] = useState<"config" | "exam" | "result">("config");
  const [examScope, setExamScope] = useState("unit");
  const [unitName, setUnitName] = useState("");
  const [chapterName, setChapterName] = useState("");
  const [studentName, setStudentName] = useState(() => localStorage.getItem("acadmy_student_name") || "");
  const [numQuestions, setNumQuestions] = useState("15");
  const [curriculum, setCurriculum] = useState(() => localStorage.getItem("acadmy_curriculum") || "general");
  const [educationLevel, setEducationLevel] = useState(() => localStorage.getItem("acadmy_level") || "general");
  const [exam, setExam] = useState<ExamData | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<{ [key: number]: number }>({});
  const [result, setResult] = useState<ExamResult | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const generateExam = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/exam/generate", {
        deviceId,
        personalityId,
        subject,
        examScope,
        unitName: unitName.trim() || undefined,
        chapterName: chapterName.trim() || undefined,
        numQuestions: parseInt(numQuestions),
        curriculum,
        educationLevel,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setExam(data);
      setStep("exam");
      setCurrentQuestion(0);
      setAnswers({});
    },
  });

  const submitExam = useMutation({
    mutationFn: async () => {
      if (!studentName.trim()) return;
      localStorage.setItem("acadmy_student_name", studentName.trim());
      const res = await apiRequest("POST", "/api/exam/submit", {
        deviceId,
        personalityId,
        subject,
        studentName: studentName.trim(),
        examScope,
        unitName: unitName.trim() || undefined,
        chapterName: chapterName.trim() || undefined,
        curriculum,
        educationLevel,
        questions: exam?.questions || [],
        answers: Object.values(answers),
      });
      return res.json();
    },
    onSuccess: (data) => {
      setResult(data);
      setStep("result");
      queryClient.invalidateQueries({ queryKey: ["/api/progress", deviceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/achievements", deviceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/certificates", deviceId] });
      if (data.passed && data.certificate) {
        toast({
          title: el.certificateEarned,
          description: el.certificateEarnedDesc,
        });
      }
    },
  });

  const handleClose = () => {
    setStep("config");
    setExam(null);
    setAnswers({});
    setResult(null);
    setShowExplanation(false);
    setCurrentQuestion(0);
    onOpenChange(false);
  };

  const handleRetry = () => {
    setStep("config");
    setExam(null);
    setAnswers({});
    setResult(null);
    setShowExplanation(false);
    setCurrentQuestion(0);
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({ title: t.copied, description: t.copiedDesc });
  };

  const shareLink = (code: string) => {
    const link = `${window.location.origin}/verify/${code}`;
    navigator.clipboard.writeText(link);
    toast({ title: t.linkCopied, description: t.linkCopiedDesc });
  };

  const questions = exam?.questions || [];
  const progress = questions.length > 0 ? ((currentQuestion + 1) / questions.length) * 100 : 0;
  const allAnswered = Object.keys(answers).length === questions.length;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className={`max-w-2xl max-h-[90vh] overflow-y-auto ${isRTL ? "rtl" : "ltr"}`} dir={isRTL ? "rtl" : "ltr"}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-primary" />
            {el.examTitle}
          </DialogTitle>
          <p className="text-sm text-muted-foreground">{el.examDesc}</p>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {step === "config" && (
            <motion.div
              key="config"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              <div>
                <Label className="text-sm font-medium">{el.studentName}</Label>
                <Input
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder={el.studentNamePlaceholder}
                  className="mt-1.5"
                  data-testid="input-exam-student-name"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm">{el.curriculum}</Label>
                  <Select value={curriculum} onValueChange={setCurriculum}>
                    <SelectTrigger className="mt-1.5" data-testid="select-exam-curriculum">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(el.curriculumOptions).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm">{el.educationLevel}</Label>
                  <Select value={educationLevel} onValueChange={setEducationLevel}>
                    <SelectTrigger className="mt-1.5" data-testid="select-exam-level">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(el.levelOptions).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-sm">{el.examScope}</Label>
                <Select value={examScope} onValueChange={setExamScope}>
                  <SelectTrigger className="mt-1.5" data-testid="select-exam-scope">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unit">{el.unitExam}</SelectItem>
                    <SelectItem value="chapter">{el.chapterExam}</SelectItem>
                    <SelectItem value="semester">{el.semesterExam}</SelectItem>
                    <SelectItem value="full">{el.fullCurriculumExam}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {examScope === "unit" && (
                <div>
                  <Label className="text-sm">{el.unitName}</Label>
                  <Input
                    value={unitName}
                    onChange={(e) => setUnitName(e.target.value)}
                    placeholder={el.unitPlaceholder}
                    className="mt-1.5"
                    data-testid="input-exam-unit"
                  />
                </div>
              )}

              {examScope === "chapter" && (
                <div>
                  <Label className="text-sm">{el.chapterName}</Label>
                  <Input
                    value={chapterName}
                    onChange={(e) => setChapterName(e.target.value)}
                    placeholder={el.chapterPlaceholder}
                    className="mt-1.5"
                    data-testid="input-exam-chapter"
                  />
                </div>
              )}

              <div>
                <Label className="text-sm">{el.numQuestions}</Label>
                <Select value={numQuestions} onValueChange={setNumQuestions}>
                  <SelectTrigger className="mt-1.5" data-testid="select-exam-questions">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="15">15</SelectItem>
                    <SelectItem value="20">20</SelectItem>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="30">30</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-muted/50 rounded-lg p-3 text-sm text-muted-foreground">
                {el.passingGrade}
              </div>

              <Button
                onClick={() => generateExam.mutate()}
                disabled={generateExam.isPending || !studentName.trim()}
                className="w-full"
                data-testid="button-start-exam"
              >
                {generateExam.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    {el.generatingExam}
                  </>
                ) : (
                  <>
                    <GraduationCap className="w-4 h-4" />
                    {el.startExam}
                  </>
                )}
              </Button>
            </motion.div>
          )}

          {step === "exam" && exam && questions.length > 0 && (
            <motion.div
              key="exam"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <div className="flex justify-between gap-2 text-sm">
                  <span className="font-medium">{el.questionOf(currentQuestion + 1, questions.length)}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
                <div className="flex justify-between gap-2 text-xs text-muted-foreground">
                  <span>{Object.keys(answers).length} / {questions.length}</span>
                  <Badge variant="outline" className="text-xs">{el.passingGrade}</Badge>
                </div>
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-6">{questions[currentQuestion]?.question}</h3>

                  <RadioGroup
                    value={answers[currentQuestion]?.toString()}
                    onValueChange={(value) => setAnswers({ ...answers, [currentQuestion]: parseInt(value) })}
                    className="space-y-3"
                  >
                    {questions[currentQuestion]?.options.map((option, index) => (
                      <div key={index} className="flex items-center space-x-3 rtl:space-x-reverse">
                        <RadioGroupItem value={index.toString()} id={`exam-option-${index}`} data-testid={`exam-option-${index}`} />
                        <Label htmlFor={`exam-option-${index}`} className="flex-1 cursor-pointer p-3 rounded-lg hover:bg-muted">
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              <div className="flex justify-between gap-4">
                <Button
                  variant="outline"
                  onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                  disabled={currentQuestion === 0}
                  data-testid="button-exam-prev"
                >
                  <ChevronLeft className={`w-4 h-4 ${isRTL ? "rotate-180" : ""}`} />
                  {t.previousQuestion}
                </Button>

                {currentQuestion < questions.length - 1 ? (
                  <Button
                    onClick={() => setCurrentQuestion(currentQuestion + 1)}
                    disabled={answers[currentQuestion] === undefined}
                    data-testid="button-exam-next"
                  >
                    {t.nextQuestion}
                    <ChevronRight className={`w-4 h-4 ${isRTL ? "rotate-180" : ""}`} />
                  </Button>
                ) : (
                  <Button
                    onClick={() => submitExam.mutate()}
                    disabled={!allAnswered || submitExam.isPending}
                    data-testid="button-submit-exam"
                  >
                    {submitExam.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : el.submitExam}
                  </Button>
                )}
              </div>
            </motion.div>
          )}

          {step === "result" && result && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <div className="text-center py-6">
                {result.passed ? (
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100 dark:bg-green-900/30 mb-4">
                    <Trophy className="w-10 h-10 text-green-600 dark:text-green-400" />
                  </div>
                ) : (
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-red-100 dark:bg-red-900/30 mb-4">
                    <XCircle className="w-10 h-10 text-red-600 dark:text-red-400" />
                  </div>
                )}
                <div className={`text-6xl font-bold ${result.passed ? "text-green-500" : "text-red-500"}`}>
                  {result.score}%
                </div>
                <p className="text-xl mt-2 font-medium">
                  {result.passed ? el.passed : el.failed}
                </p>
                <div className="flex justify-center gap-4 mt-4 flex-wrap">
                  <Badge variant="secondary" className="text-lg py-2 px-4">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    {result.correctCount} / {result.totalQuestions}
                  </Badge>
                </div>
              </div>

              {result.passed && result.certificate && (
                <Card className="border-green-500/50 bg-green-50/50 dark:bg-green-900/10">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <Award className="w-6 h-6 text-green-600 dark:text-green-400" />
                      <h3 className="font-semibold text-green-700 dark:text-green-300">{el.certificateEarned}</h3>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-muted-foreground">{el.certificateCode}:</span>
                        <code className="bg-muted px-2 py-1 rounded font-mono text-xs">{result.certificate.certificateCode}</code>
                        <Button size="icon" variant="ghost" onClick={() => copyCode(result.certificate!.certificateCode)} data-testid="button-copy-exam-cert">
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => shareLink(result.certificate!.certificateCode)} data-testid="button-share-exam-cert">
                          <Share className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Button variant="outline" onClick={() => setShowExplanation(!showExplanation)} className="w-full" data-testid="button-exam-review">
                <ScrollText className="w-4 h-4" />
                {el.reviewAnswers}
              </Button>

              {showExplanation && (
                <div className="space-y-4 max-h-60 overflow-y-auto">
                  {questions.map((q, index) => (
                    <Card key={index} className={answers[index] === q.correctAnswer ? "border-green-500/50" : "border-red-500/50"}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-2">
                          {answers[index] === q.correctAnswer ? (
                            <CheckCircle className="w-5 h-5 text-green-500 shrink-0 mt-1" />
                          ) : (
                            <XCircle className="w-5 h-5 text-red-500 shrink-0 mt-1" />
                          )}
                          <div>
                            <p className="font-medium">{q.question}</p>
                            <p className="text-sm text-green-600 dark:text-green-400 mt-2">
                              {el.correctAnswer}: {q.options[q.correctAnswer]}
                            </p>
                            <p className="text-sm text-muted-foreground mt-1">
                              {el.explanation}: {q.explanation}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              <div className="flex gap-3">
                {!result.passed && (
                  <Button variant="outline" onClick={handleRetry} className="flex-1" data-testid="button-exam-retry">
                    {el.tryAgain}
                  </Button>
                )}
                <Button onClick={handleClose} className="flex-1" data-testid="button-exam-close">
                  {el.close}
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}