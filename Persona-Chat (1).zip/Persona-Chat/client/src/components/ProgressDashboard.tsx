import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Star, Target, Flame, Award, Users, BookOpen, ChevronLeft } from "lucide-react";
import { getTranslation, Language } from "@/lib/translations";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const progressLabels: Record<string, { toNextLevel: string; subjects: string; noSubjectsYet: string }> = {
  ar: { toNextLevel: "للمستوى التالي", subjects: "المواد", noSubjectsYet: "لم تدرس أي مادة بعد" },
  en: { toNextLevel: "to next level", subjects: "Subjects", noSubjectsYet: "No subjects studied yet" },
  zh: { toNextLevel: "升级还需", subjects: "科目", noSubjectsYet: "尚未学习任何科目" },
  hi: { toNextLevel: "अगले स्तर तक", subjects: "विषय", noSubjectsYet: "अभी तक कोई विषय नहीं पढ़ा" },
  es: { toNextLevel: "para el siguiente nivel", subjects: "Materias", noSubjectsYet: "Aún no has estudiado ninguna materia" },
  fr: { toNextLevel: "pour le prochain niveau", subjects: "Matières", noSubjectsYet: "Aucune matière étudiée" },
  bn: { toNextLevel: "পরবর্তী স্তরে", subjects: "বিষয়সমূহ", noSubjectsYet: "এখনো কোনো বিষয় পড়া হয়নি" },
  pt: { toNextLevel: "para o próximo nível", subjects: "Disciplinas", noSubjectsYet: "Nenhuma disciplina estudada ainda" },
  ru: { toNextLevel: "до следующего уровня", subjects: "Предметы", noSubjectsYet: "Ещё нет изученных предметов" },
  ja: { toNextLevel: "次のレベルまで", subjects: "科目", noSubjectsYet: "まだ科目を学習していません" },
};

interface UserProgress {
  id: number;
  deviceId: string;
  displayName: string | null;
  totalPoints: number | null;
  level: number | null;
  questionsAsked: number | null;
  quizzesCompleted: number | null;
  streakDays: number | null;
}

interface Achievement {
  id: number;
  achievementType: string;
  achievementName: string;
  description: string | null;
  iconUrl: string | null;
  earnedAt: string;
}

interface SubjectProgress {
  id: number;
  subject: string;
  points: number | null;
  questionsAsked: number | null;
  masteryLevel: number | null;
}

interface Props {
  deviceId: string;
  language: Language;
}

export function ProgressDashboard({ deviceId, language }: Props) {
  const t = getTranslation(language);
  const isRTL = language === "ar";

  const { data: progress } = useQuery<UserProgress>({
    queryKey: ["/api/progress", deviceId],
    queryFn: async () => {
      const res = await fetch(`/api/progress/${deviceId}`);
      return res.json();
    },
  });

  const { data: achievements = [] } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements", deviceId],
    queryFn: async () => {
      const res = await fetch(`/api/achievements/${deviceId}`);
      return res.json();
    },
  });

  const { data: leaderboard = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/leaderboard"],
  });

  const { data: subjectProgress = [] } = useQuery<SubjectProgress[]>({
    queryKey: ["/api/progress", deviceId, "subjects"],
    queryFn: async () => {
      const res = await fetch(`/api/progress/${deviceId}/subjects`);
      return res.json();
    },
  });

  const levelProgress = ((progress?.totalPoints || 0) % 100);
  const pointsToNextLevel = 100 - levelProgress;

  return (
    <div className={`min-h-screen bg-background p-4 md:p-6 ${isRTL ? "rtl" : "ltr"}`} dir={isRTL ? "rtl" : "ltr"}>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ChevronLeft className={`w-5 h-5 ${isRTL ? "rotate-180" : ""}`} />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">{t.myProgress}</h1>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border-yellow-500/30">
              <CardContent className="p-4 text-center">
                <Star className="w-8 h-8 mx-auto text-yellow-500 mb-2" />
                <p className="text-2xl font-bold">{progress?.totalPoints || 0}</p>
                <p className="text-sm text-muted-foreground">{t.points}</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border-blue-500/30">
              <CardContent className="p-4 text-center">
                <Trophy className="w-8 h-8 mx-auto text-blue-500 mb-2" />
                <p className="text-2xl font-bold">{progress?.level || 1}</p>
                <p className="text-sm text-muted-foreground">{t.level}</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <Card className="bg-gradient-to-br from-green-500/20 to-green-600/10 border-green-500/30">
              <CardContent className="p-4 text-center">
                <Target className="w-8 h-8 mx-auto text-green-500 mb-2" />
                <p className="text-2xl font-bold">{progress?.questionsAsked || 0}</p>
                <p className="text-sm text-muted-foreground">{t.questionsAsked}</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <Card className="bg-gradient-to-br from-orange-500/20 to-orange-600/10 border-orange-500/30">
              <CardContent className="p-4 text-center">
                <Flame className="w-8 h-8 mx-auto text-orange-500 mb-2" />
                <p className="text-2xl font-bold">{progress?.streakDays || 0}</p>
                <p className="text-sm text-muted-foreground">{t.streakDays}</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between mb-2">
              <span className="text-sm">{t.level} {progress?.level || 1}</span>
              <span className="text-sm text-muted-foreground">{pointsToNextLevel} {t.points} {(progressLabels[language] || progressLabels.en).toNextLevel}</span>
            </div>
            <Progress value={levelProgress} className="h-3" />
          </CardContent>
        </Card>

        <Tabs defaultValue="achievements" className="w-full">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="achievements" data-testid="tab-achievements">
              <Award className="w-4 h-4 mr-2" />
              {t.achievements}
            </TabsTrigger>
            <TabsTrigger value="leaderboard" data-testid="tab-leaderboard">
              <Users className="w-4 h-4 mr-2" />
              {t.leaderboard}
            </TabsTrigger>
            <TabsTrigger value="subjects" data-testid="tab-subjects">
              <BookOpen className="w-4 h-4 mr-2" />
              {(progressLabels[language] || progressLabels.en).subjects}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="achievements" className="mt-4">
            {achievements.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center text-muted-foreground">
                  <Award className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>{t.noAchievements}</p>
                  <p className="text-sm mt-2">{t.keepLearning}</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {achievements.map((achievement, index) => (
                  <motion.div
                    key={achievement.id}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="text-center hover-elevate">
                      <CardContent className="p-4">
                        <span className="text-3xl">{achievement.iconUrl}</span>
                        <p className="font-medium mt-2">{achievement.achievementName}</p>
                        <p className="text-xs text-muted-foreground">{achievement.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="leaderboard" className="mt-4">
            <Card>
              <CardContent className="p-0">
                {leaderboard.map((user, index) => (
                  <div
                    key={user.id}
                    className={`flex items-center gap-4 p-4 ${index !== leaderboard.length - 1 ? "border-b" : ""} ${user.deviceId === deviceId ? "bg-primary/10" : ""}`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${index === 0 ? "bg-yellow-500 text-white" : index === 1 ? "bg-gray-400 text-white" : index === 2 ? "bg-amber-700 text-white" : "bg-muted"}`}>
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{user.displayName || t.student}</p>
                      <p className="text-sm text-muted-foreground">{t.level} {user.level || 1}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-primary">{user.totalPoints || 0}</p>
                      <p className="text-xs text-muted-foreground">{t.points}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subjects" className="mt-4">
            {subjectProgress.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center text-muted-foreground">
                  <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>{(progressLabels[language] || progressLabels.en).noSubjectsYet}</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {subjectProgress.map((subject) => (
                  <Card key={subject.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{(t.subjects as any)[subject.subject] || subject.subject}</span>
                        <Badge variant="secondary">{subject.points || 0} {t.points}</Badge>
                      </div>
                      <div className="flex gap-4 text-sm text-muted-foreground">
                        <span>{subject.questionsAsked || 0} {t.questionsAsked}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
