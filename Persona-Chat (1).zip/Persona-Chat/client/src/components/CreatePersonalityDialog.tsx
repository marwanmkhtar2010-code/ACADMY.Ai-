import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPersonalitySchema, type CreatePersonalityRequest, SUBJECTS } from "@shared/schema";
import { useCreatePersonality } from "@/hooks/use-personalities";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Plus, User, FileText, BrainCircuit, GraduationCap } from "lucide-react";

export function CreatePersonalityDialog() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const createPersonality = useCreatePersonality();
  const { t, language, dir } = useLanguage();
  
  const form = useForm<CreatePersonalityRequest>({
    resolver: zodResolver(insertPersonalitySchema),
    defaultValues: {
      name: "",
      description: "",
      instructions: "",
      subject: "general",
      avatarUrl: "",
      isPublic: true,
    },
  });

  const getSubjectName = (subjectId: string): string => {
    const key = subjectId as keyof typeof t.subjects;
    return t.subjects[key] || t.subjects.general;
  };

  const onSubmit = async (data: CreatePersonalityRequest) => {
    try {
      await createPersonality.mutateAsync(data);
      toast({
        title: t.createdSuccess,
        description: `${data.name} ${t.readyToChat}`,
      });
      setOpen(false);
      form.reset();
    } catch (error) {
      toast({
        title: t.error,
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="w-full gap-2 rounded-full border-dashed justify-start px-4 py-6 text-muted-foreground hover:text-foreground hover:border-solid"
          data-testid="button-new-chat"
        >
          <Plus className="w-5 h-5" />
          <span>{t.addTeacher}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-medium">
            {t.addTeacher}
          </DialogTitle>
          <DialogDescription>
            {t.setupTeacher}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 mt-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="flex items-center gap-2 text-sm font-medium">
                <User className="w-4 h-4 text-muted-foreground" /> {t.teacherName}
              </Label>
              <Input
                id="name"
                placeholder={t.teacherNamePlaceholder}
                {...form.register("name")}
                className="rounded-xl"
                dir={dir}
                data-testid="input-personality-name"
              />
              {form.formState.errors.name && (
                <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="subject" className="flex items-center gap-2 text-sm font-medium">
                <GraduationCap className="w-4 h-4 text-muted-foreground" /> {t.specialization}
              </Label>
              <Select
                value={form.watch("subject") || "general"}
                onValueChange={(value) => form.setValue("subject", value)}
              >
                <SelectTrigger className="rounded-xl" data-testid="select-subject">
                  <SelectValue placeholder={t.chooseSpec} />
                </SelectTrigger>
                <SelectContent>
                  {SUBJECTS.map((subject) => (
                    <SelectItem key={subject.id} value={subject.id} data-testid={`option-subject-${subject.id}`}>
                      {getSubjectName(subject.id)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="flex items-center gap-2 text-sm font-medium">
                <FileText className="w-4 h-4 text-muted-foreground" /> {t.shortDescription}
              </Label>
              <Input
                id="description"
                placeholder={t.descriptionPlaceholder}
                {...form.register("description")}
                className="rounded-xl"
                dir={dir}
                data-testid="input-personality-description"
              />
              {form.formState.errors.description && (
                <p className="text-sm text-destructive">{form.formState.errors.description.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="instructions" className="flex items-center gap-2 text-sm font-medium">
                <BrainCircuit className="w-4 h-4 text-muted-foreground" /> {t.instructions}
              </Label>
              <Textarea
                id="instructions"
                placeholder={t.instructionsPlaceholder}
                className="min-h-[100px] rounded-xl resize-none"
                dir={dir}
                {...form.register("instructions")}
                data-testid="input-personality-instructions"
              />
              <p className="text-xs text-muted-foreground">
                {t.instructionsHint}
              </p>
              {form.formState.errors.instructions && (
                <p className="text-sm text-destructive">{form.formState.errors.instructions.message}</p>
              )}
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setOpen(false)}
              className="rounded-full"
              data-testid="button-cancel-create"
            >
              {t.cancel}
            </Button>
            <Button
              type="submit"
              disabled={createPersonality.isPending}
              className="rounded-full px-6"
              data-testid="button-submit-create"
            >
              {createPersonality.isPending ? t.creating : t.create}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
