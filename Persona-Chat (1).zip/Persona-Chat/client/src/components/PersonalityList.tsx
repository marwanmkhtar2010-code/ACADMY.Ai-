import { useState, useMemo, useEffect } from "react";
import { usePersonalities } from "@/hooks/use-personalities";
import { Link, useRoute } from "wouter";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  MessageSquare, GraduationCap, Search, X,
  Calculator, Atom, FlaskConical, Dna, Microscope, BookOpen, Languages, 
  Code, Brain, Landmark, Globe, TrendingUp, Lightbulb, Palette, BookHeart,
  BookMarked, Scale, Stethoscope, Cog, HeartHandshake, Croissant, Trophy,
  LogIn, LogOut,
  Mountain, Star, TreePine, Users, Building2, ScrollText, BookText,
  Monitor, Layout, Shield, BarChart3, Receipt, Briefcase, Megaphone,
  Wallet, GitBranch, Heart, Music, PenTool, Feather, Clapperboard,
  Bone, Apple, Pill, Cross, Wrench, Zap, HardHat, Ruler, Gavel,
  Globe2, Target, BookOpenCheck, Dumbbell, Activity,
  type LucideIcon
} from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { LanguageToggle } from "./LanguageToggle";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/hooks/use-auth";
import { getDeviceId } from "@/hooks/use-device-id";
import { apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";

const personalityLabels: Record<string, Record<string, string>> = {
  searchPlaceholder: {
    ar: "ابحث عن التخصص أو الأستاذ...",
    en: "Search by subject or teacher...",
    zh: "按学科或教师搜索...",
    hi: "विषय या शिक्षक से खोजें...",
    es: "Buscar por materia o profesor...",
    fr: "Rechercher par matière ou enseignant...",
    bn: "বিষয় বা শিক্ষক দিয়ে খুঁজুন...",
    pt: "Pesquisar por matéria ou professor...",
    ru: "Поиск по предмету или учителю...",
    ja: "科目または教師で検索...",
  },
  noResults: {
    ar: "لا توجد نتائج",
    en: "No results found",
    zh: "未找到结果",
    hi: "कोई परिणाम नहीं मिला",
    es: "No se encontraron resultados",
    fr: "Aucun résultat trouvé",
    bn: "কোনো ফলাফল পাওয়া যায়নি",
    pt: "Nenhum resultado encontrado",
    ru: "Результатов не найдено",
    ja: "結果が見つかりません",
  },
  tryDifferent: {
    ar: "جرب البحث بكلمة أخرى",
    en: "Try a different search term",
    zh: "请尝试其他搜索词",
    hi: "कोई अलग खोज शब्द आज़माएँ",
    es: "Prueba con otro término de búsqueda",
    fr: "Essayez un autre terme de recherche",
    bn: "অন্য একটি অনুসন্ধান শব্দ চেষ্টা করুন",
    pt: "Tente um termo de pesquisa diferente",
    ru: "Попробуйте другой поисковый запрос",
    ja: "別の検索語をお試しください",
  },
  noTeachers: {
    ar: "لا يوجد أساتذة بعد",
    en: "No teachers yet",
    zh: "还没有教师",
    hi: "अभी तक कोई शिक्षक नहीं",
    es: "Aún no hay profesores",
    fr: "Pas encore d'enseignants",
    bn: "এখনো কোনো শিক্ষক নেই",
    pt: "Nenhum professor ainda",
    ru: "Учителей пока нет",
    ja: "まだ教師がいません",
  },
  addTeacher: {
    ar: "أضف أستاذاً جديداً للبدء",
    en: "Add a new teacher to start",
    zh: "添加新教师以开始",
    hi: "शुरू करने के लिए एक नया शिक्षक जोड़ें",
    es: "Añade un nuevo profesor para empezar",
    fr: "Ajoutez un nouvel enseignant pour commencer",
    bn: "শুরু করতে একজন নতুন শিক্ষক যোগ করুন",
    pt: "Adicione um novo professor para começar",
    ru: "Добавьте нового учителя, чтобы начать",
    ja: "始めるには新しい教師を追加してください",
  },
  friends: {
    ar: "الأصدقاء",
    en: "Friends",
    zh: "好友",
    hi: "मित्र",
    es: "Amigos",
    fr: "Amis",
    bn: "বন্ধুরা",
    pt: "Amigos",
    ru: "Друзья",
    ja: "フレンド",
  },
  leaderboard: {
    ar: "قائمة المتصدرين",
    en: "Leaderboard",
    zh: "排行榜",
    hi: "लीडरबोर्ड",
    es: "Tabla de clasificación",
    fr: "Classement",
    bn: "লিডারবোর্ড",
    pt: "Classificação",
    ru: "Таблица лидеров",
    ja: "リーダーボード",
  },
  user: {
    ar: "مستخدم",
    en: "User",
    zh: "用户",
    hi: "उपयोगकर्ता",
    es: "Usuario",
    fr: "Utilisateur",
    bn: "ব্যবহারকারী",
    pt: "Usuário",
    ru: "Пользователь",
    ja: "ユーザー",
  },
  logout: {
    ar: "تسجيل الخروج",
    en: "Logout",
    zh: "退出登录",
    hi: "लॉग आउट",
    es: "Cerrar sesión",
    fr: "Déconnexion",
    bn: "লগ আউট",
    pt: "Sair",
    ru: "Выйти",
    ja: "ログアウト",
  },
  linkGoogle: {
    ar: "ربط حساب Google",
    en: "Link Google Account",
    zh: "关联 Google 账号",
    hi: "Google खाता लिंक करें",
    es: "Vincular cuenta de Google",
    fr: "Lier un compte Google",
    bn: "Google অ্যাকাউন্ট লিঙ্ক করুন",
    pt: "Vincular conta do Google",
    ru: "Привязать аккаунт Google",
    ja: "Google アカウントを連携",
  },
};

interface SubjectStyle {
  icon: LucideIcon;
  bgColor: string;
  iconColor: string;
  badgeColor: string;
}

function getSubjectStyle(subjectId: string | null | undefined): SubjectStyle {
  const styles: Record<string, SubjectStyle> = {
    math: { 
      icon: Calculator, 
      bgColor: "bg-gradient-to-br from-blue-500 to-blue-600", 
      iconColor: "text-white",
      badgeColor: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300"
    },
    physics: { 
      icon: Atom, 
      bgColor: "bg-gradient-to-br from-purple-500 to-purple-600", 
      iconColor: "text-white",
      badgeColor: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300"
    },
    chemistry: { 
      icon: FlaskConical, 
      bgColor: "bg-gradient-to-br from-pink-500 to-pink-600", 
      iconColor: "text-white",
      badgeColor: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300"
    },
    biology: { 
      icon: Dna, 
      bgColor: "bg-gradient-to-br from-green-500 to-green-600", 
      iconColor: "text-white",
      badgeColor: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300"
    },
    science: { 
      icon: Microscope, 
      bgColor: "bg-gradient-to-br from-indigo-500 to-indigo-600", 
      iconColor: "text-white",
      badgeColor: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300"
    },
    arabic: { 
      icon: BookOpen, 
      bgColor: "bg-gradient-to-br from-teal-500 to-teal-600", 
      iconColor: "text-white",
      badgeColor: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300"
    },
    english: { 
      icon: Languages, 
      bgColor: "bg-gradient-to-br from-yellow-500 to-amber-500", 
      iconColor: "text-white",
      badgeColor: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300"
    },
    french: { 
      icon: Croissant, 
      bgColor: "bg-gradient-to-br from-blue-500 via-white to-red-500", 
      iconColor: "text-blue-900",
      badgeColor: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300"
    },
    programming: { 
      icon: Code, 
      bgColor: "bg-gradient-to-br from-orange-500 to-orange-600", 
      iconColor: "text-white",
      badgeColor: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300"
    },
    ai: { 
      icon: Brain, 
      bgColor: "bg-gradient-to-br from-violet-500 to-purple-600", 
      iconColor: "text-white",
      badgeColor: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300"
    },
    history: { 
      icon: Landmark, 
      bgColor: "bg-gradient-to-br from-amber-500 to-amber-600", 
      iconColor: "text-white",
      badgeColor: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
    },
    geography: { 
      icon: Globe, 
      bgColor: "bg-gradient-to-br from-cyan-500 to-cyan-600", 
      iconColor: "text-white",
      badgeColor: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300"
    },
    economics: { 
      icon: TrendingUp, 
      bgColor: "bg-gradient-to-br from-rose-500 to-rose-600", 
      iconColor: "text-white",
      badgeColor: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300"
    },
    psychology: { 
      icon: HeartHandshake, 
      bgColor: "bg-gradient-to-br from-fuchsia-500 to-fuchsia-600", 
      iconColor: "text-white",
      badgeColor: "bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/30 dark:text-fuchsia-300"
    },
    philosophy: { 
      icon: Lightbulb, 
      bgColor: "bg-gradient-to-br from-violet-500 to-violet-600", 
      iconColor: "text-white",
      badgeColor: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300"
    },
    islamic: { 
      icon: BookHeart, 
      bgColor: "bg-gradient-to-br from-emerald-500 to-emerald-600", 
      iconColor: "text-white",
      badgeColor: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
    },
    quran: { 
      icon: BookMarked, 
      bgColor: "bg-gradient-to-br from-lime-500 to-green-600", 
      iconColor: "text-white",
      badgeColor: "bg-lime-100 text-lime-700 dark:bg-lime-900/30 dark:text-lime-300"
    },
    civics: { 
      icon: Scale, 
      bgColor: "bg-gradient-to-br from-slate-500 to-slate-600", 
      iconColor: "text-white",
      badgeColor: "bg-slate-100 text-slate-700 dark:bg-slate-900/30 dark:text-slate-300"
    },
    art: { 
      icon: Palette, 
      bgColor: "bg-gradient-to-br from-fuchsia-400 to-pink-500", 
      iconColor: "text-white",
      badgeColor: "bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/30 dark:text-fuchsia-300"
    },
    university: { 
      icon: GraduationCap, 
      bgColor: "bg-gradient-to-br from-gray-900 to-yellow-500", 
      iconColor: "text-yellow-400",
      badgeColor: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300"
    },
    engineering: { 
      icon: Cog, 
      bgColor: "bg-gradient-to-br from-slate-600 to-slate-700", 
      iconColor: "text-white",
      badgeColor: "bg-slate-100 text-slate-700 dark:bg-slate-900/30 dark:text-slate-300"
    },
    medicine: { 
      icon: Stethoscope, 
      bgColor: "bg-gradient-to-br from-red-500 to-red-600", 
      iconColor: "text-white",
      badgeColor: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"
    },
    geology: { 
      icon: Mountain, 
      bgColor: "bg-gradient-to-br from-amber-600 to-yellow-700", 
      iconColor: "text-white",
      badgeColor: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
    },
    astronomy: { 
      icon: Star, 
      bgColor: "bg-gradient-to-br from-indigo-600 to-blue-800", 
      iconColor: "text-white",
      badgeColor: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300"
    },
    environmental: { 
      icon: TreePine, 
      bgColor: "bg-gradient-to-br from-green-600 to-emerald-700", 
      iconColor: "text-white",
      badgeColor: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300"
    },
    german: { 
      icon: Languages, 
      bgColor: "bg-gradient-to-br from-red-600 to-yellow-500", 
      iconColor: "text-white",
      badgeColor: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"
    },
    spanish: { 
      icon: Languages, 
      bgColor: "bg-gradient-to-br from-yellow-500 to-red-500", 
      iconColor: "text-white",
      badgeColor: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300"
    },
    chinese: { 
      icon: Languages, 
      bgColor: "bg-gradient-to-br from-red-600 to-red-700", 
      iconColor: "text-white",
      badgeColor: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"
    },
    sociology: { 
      icon: Users, 
      bgColor: "bg-gradient-to-br from-violet-500 to-purple-700", 
      iconColor: "text-white",
      badgeColor: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300"
    },
    politics: { 
      icon: Building2, 
      bgColor: "bg-gradient-to-br from-slate-600 to-gray-700", 
      iconColor: "text-white",
      badgeColor: "bg-slate-100 text-slate-700 dark:bg-slate-900/30 dark:text-slate-300"
    },
    hadith: { 
      icon: ScrollText, 
      bgColor: "bg-gradient-to-br from-emerald-600 to-green-700", 
      iconColor: "text-white",
      badgeColor: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
    },
    fiqh: { 
      icon: BookText, 
      bgColor: "bg-gradient-to-br from-green-600 to-teal-700", 
      iconColor: "text-white",
      badgeColor: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300"
    },
    computerscience: { 
      icon: Monitor, 
      bgColor: "bg-gradient-to-br from-blue-600 to-indigo-700", 
      iconColor: "text-white",
      badgeColor: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300"
    },
    webdev: { 
      icon: Layout, 
      bgColor: "bg-gradient-to-br from-pink-500 to-rose-600", 
      iconColor: "text-white",
      badgeColor: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300"
    },
    cybersecurity: { 
      icon: Shield, 
      bgColor: "bg-gradient-to-br from-gray-700 to-slate-800", 
      iconColor: "text-white",
      badgeColor: "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-300"
    },
    dataanalysis: { 
      icon: BarChart3, 
      bgColor: "bg-gradient-to-br from-purple-500 to-violet-600", 
      iconColor: "text-white",
      badgeColor: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300"
    },
    accounting: { 
      icon: Receipt, 
      bgColor: "bg-gradient-to-br from-teal-500 to-cyan-600", 
      iconColor: "text-white",
      badgeColor: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300"
    },
    business: { 
      icon: Briefcase, 
      bgColor: "bg-gradient-to-br from-purple-600 to-indigo-600", 
      iconColor: "text-white",
      badgeColor: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300"
    },
    marketing: { 
      icon: Megaphone, 
      bgColor: "bg-gradient-to-br from-orange-500 to-red-500", 
      iconColor: "text-white",
      badgeColor: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300"
    },
    finance: { 
      icon: Wallet, 
      bgColor: "bg-gradient-to-br from-sky-500 to-blue-600", 
      iconColor: "text-white",
      badgeColor: "bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300"
    },
    logic: { 
      icon: GitBranch, 
      bgColor: "bg-gradient-to-br from-violet-600 to-purple-700", 
      iconColor: "text-white",
      badgeColor: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300"
    },
    ethics: { 
      icon: Heart, 
      bgColor: "bg-gradient-to-br from-rose-500 to-pink-600", 
      iconColor: "text-white",
      badgeColor: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300"
    },
    music: { 
      icon: Music, 
      bgColor: "bg-gradient-to-br from-rose-600 to-red-700", 
      iconColor: "text-white",
      badgeColor: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300"
    },
    design: { 
      icon: PenTool, 
      bgColor: "bg-gradient-to-br from-fuchsia-500 to-purple-600", 
      iconColor: "text-white",
      badgeColor: "bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/30 dark:text-fuchsia-300"
    },
    literature: { 
      icon: Feather, 
      bgColor: "bg-gradient-to-br from-cyan-600 to-teal-700", 
      iconColor: "text-white",
      badgeColor: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300"
    },
    theater: { 
      icon: Clapperboard, 
      bgColor: "bg-gradient-to-br from-amber-500 to-orange-600", 
      iconColor: "text-white",
      badgeColor: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
    },
    anatomy: { 
      icon: Bone, 
      bgColor: "bg-gradient-to-br from-red-600 to-rose-700", 
      iconColor: "text-white",
      badgeColor: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"
    },
    nutrition: { 
      icon: Apple, 
      bgColor: "bg-gradient-to-br from-lime-500 to-green-600", 
      iconColor: "text-white",
      badgeColor: "bg-lime-100 text-lime-700 dark:bg-lime-900/30 dark:text-lime-300"
    },
    pharmacy: { 
      icon: Pill, 
      bgColor: "bg-gradient-to-br from-indigo-500 to-blue-600", 
      iconColor: "text-white",
      badgeColor: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300"
    },
    nursing: { 
      icon: Cross, 
      bgColor: "bg-gradient-to-br from-pink-500 to-red-500", 
      iconColor: "text-white",
      badgeColor: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300"
    },
    mechanical: { 
      icon: Wrench, 
      bgColor: "bg-gradient-to-br from-stone-500 to-stone-600", 
      iconColor: "text-white",
      badgeColor: "bg-stone-100 text-stone-700 dark:bg-stone-900/30 dark:text-stone-300"
    },
    electrical: { 
      icon: Zap, 
      bgColor: "bg-gradient-to-br from-yellow-500 to-amber-600", 
      iconColor: "text-white",
      badgeColor: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300"
    },
    civil: { 
      icon: HardHat, 
      bgColor: "bg-gradient-to-br from-orange-500 to-amber-600", 
      iconColor: "text-white",
      badgeColor: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300"
    },
    architecture: { 
      icon: Ruler, 
      bgColor: "bg-gradient-to-br from-indigo-500 to-violet-600", 
      iconColor: "text-white",
      badgeColor: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300"
    },
    law: { 
      icon: Gavel, 
      bgColor: "bg-gradient-to-br from-gray-700 to-gray-800", 
      iconColor: "text-white",
      badgeColor: "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-300"
    },
    internationallaw: { 
      icon: Globe2, 
      bgColor: "bg-gradient-to-br from-sky-600 to-blue-700", 
      iconColor: "text-white",
      badgeColor: "bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300"
    },
    career: { 
      icon: Target, 
      bgColor: "bg-gradient-to-br from-emerald-500 to-green-600", 
      iconColor: "text-white",
      badgeColor: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
    },
    studyskills: { 
      icon: BookOpenCheck, 
      bgColor: "bg-gradient-to-br from-violet-500 to-fuchsia-600", 
      iconColor: "text-white",
      badgeColor: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300"
    },
    sports: { 
      icon: Dumbbell, 
      bgColor: "bg-gradient-to-br from-blue-500 to-cyan-600", 
      iconColor: "text-white",
      badgeColor: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300"
    },
    fitness: { 
      icon: Activity, 
      bgColor: "bg-gradient-to-br from-pink-500 to-fuchsia-600", 
      iconColor: "text-white",
      badgeColor: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300"
    },
    general: { 
      icon: GraduationCap, 
      bgColor: "bg-gradient-to-br from-gray-500 to-gray-600", 
      iconColor: "text-white",
      badgeColor: "bg-gray-100 text-gray-700 dark:bg-gray-800/50 dark:text-gray-300"
    },
  };
  return styles[subjectId || "general"] || styles.general;
}

export function PersonalityList() {
  const { data: personalities, isLoading } = usePersonalities();
  const [match, params] = useRoute("/chat/:id");
  const activeId = match ? parseInt(params.id) : null;
  const { t, language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const [hasLinked, setHasLinked] = useState(false);

  useEffect(() => {
    if (!authLoading && isAuthenticated && user && !hasLinked) {
      const deviceId = getDeviceId();
      setHasLinked(true);
      apiRequest("POST", "/api/account/link", { deviceId }).catch(() => {
        setHasLinked(false);
      });
    }
  }, [isAuthenticated, authLoading, user, hasLinked]);

  const getSubjectName = (subjectId: string | null | undefined): string => {
    const key = (subjectId || "general") as keyof typeof t.subjects;
    return t.subjects[key] || t.subjects.general;
  };

  const filteredPersonalities = useMemo(() => {
    if (!personalities || !searchQuery.trim()) return personalities;
    const query = searchQuery.toLowerCase().trim();
    return personalities.filter((p) => {
      const subjectName = getSubjectName(p.subject).toLowerCase();
      const name = p.name.toLowerCase();
      const translatedName = (p.subject && t.teacherNames[p.subject as keyof typeof t.teacherNames] || "").toLowerCase();
      const description = (p.description || "").toLowerCase();
      const translatedDesc = (p.subject && t.teacherDescriptions[p.subject as keyof typeof t.teacherDescriptions] || "").toLowerCase();
      return name.includes(query) || translatedName.includes(query) || subjectName.includes(query) || description.includes(query) || translatedDesc.includes(query);
    });
  }, [personalities, searchQuery, language]);

  if (isLoading) {
    return (
      <div className="p-4 space-y-2">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="flex items-center gap-3 p-3 rounded-2xl">
            <Skeleton className="h-12 w-12 rounded-full" />
            <div className="space-y-2 flex-1">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-3 w-16" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-muted/40 dark:bg-card/50">
      <div className="px-4 pt-4 pb-3 flex items-center justify-between gap-2">
        <Link href="/">
          <div className="flex items-center gap-2.5 cursor-pointer" data-testid="link-home">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-md">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent dark:from-blue-400 dark:via-purple-400 dark:to-pink-400">{t.appName}</span>
              <span className="text-[10px] text-muted-foreground leading-tight">{t.appSubtitle}</span>
            </div>
          </div>
        </Link>
        <div className="flex items-center gap-0.5">
          <LanguageToggle />
          <ThemeToggle />
        </div>
      </div>

      <div className="px-3 pb-2">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            type="text"
            placeholder={personalityLabels.searchPlaceholder[language] || personalityLabels.searchPlaceholder.en}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="ps-9 pe-9 h-9 rounded-lg bg-background/70 dark:bg-background/30 border-border/40 text-sm"
            data-testid="input-search-teachers"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute end-1 top-1/2 -translate-y-1/2 h-7 w-7 text-muted-foreground"
              onClick={() => setSearchQuery("")}
              data-testid="button-clear-search"
            >
              <X className="w-3.5 h-3.5" />
            </Button>
          )}
        </div>
      </div>

      <ScrollArea className="flex-1 px-2">
        <div className="space-y-0.5 py-1">
          {filteredPersonalities?.length === 0 && searchQuery && (
            <div className="text-center py-10 px-4 text-muted-foreground">
              <Search className="w-8 h-8 mx-auto mb-3 opacity-20" />
              <p className="text-sm font-medium">{personalityLabels.noResults[language] || personalityLabels.noResults.en}</p>
              <p className="text-xs mt-1.5 opacity-60">{personalityLabels.tryDifferent[language] || personalityLabels.tryDifferent.en}</p>
            </div>
          )}
          {personalities?.length === 0 && !searchQuery && (
            <div className="text-center py-12 px-4 text-muted-foreground">
              <MessageSquare className="w-10 h-10 mx-auto mb-3 opacity-20" />
              <p className="text-sm font-medium">{personalityLabels.noTeachers[language] || personalityLabels.noTeachers.en}</p>
              <p className="text-xs mt-1.5 opacity-60">{personalityLabels.addTeacher[language] || personalityLabels.addTeacher.en}</p>
            </div>
          )}

          {filteredPersonalities?.map((p) => {
            const style = getSubjectStyle(p.subject);
            const IconComponent = style.icon;
            const isActive = activeId === p.id;
            return (
              <div
                key={p.id}
                className={cn(
                  "group relative flex items-center gap-3 px-2.5 py-2 rounded-lg transition-all duration-150 cursor-pointer",
                  isActive
                    ? "bg-primary/10 dark:bg-primary/15"
                    : "hover:bg-background/70 dark:hover:bg-background/20"
                )}
                data-testid={`chat-item-${p.id}`}
              >
                <Link href={`/chat/${p.id}`} className="absolute inset-0 z-0" />
                
                <div className={cn(
                  "h-10 w-10 shrink-0 z-10 rounded-lg flex items-center justify-center shadow-sm transition-shadow",
                  style.bgColor,
                  isActive && "ring-2 ring-primary/50 ring-offset-1 ring-offset-background shadow-md"
                )}>
                  <IconComponent className={cn("w-5 h-5", style.iconColor)} />
                </div>

                <div className="flex-1 min-w-0 z-10">
                  <span className={cn(
                    "block truncate text-[13px] font-medium leading-snug",
                    isActive ? "text-primary" : "text-foreground"
                  )}>
                    {(p.subject && t.teacherNames[p.subject as keyof typeof t.teacherNames]) || p.name}
                  </span>
                  <span className={cn(
                    "block truncate text-[11px] mt-0.5 leading-snug",
                    isActive ? "text-primary/70" : "text-muted-foreground"
                  )}>
                    {getSubjectName(p.subject)}
                  </span>
                </div>

              </div>
            );
          })}
        </div>
      </ScrollArea>

      <div className="p-2 border-t border-border/30 space-y-0.5">
        <Link href="/friends">
          <div className="sidebar-item w-full text-sm" data-testid="button-friends">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 dark:bg-blue-500/20 flex items-center justify-center shrink-0">
              <Users className="w-4 h-4 text-blue-500" />
            </div>
            <span className="text-foreground/80">{personalityLabels.friends[language] || personalityLabels.friends.en}</span>
          </div>
        </Link>
        <Link href="/leaderboard">
          <div className="sidebar-item w-full text-sm" data-testid="button-leaderboard">
            <div className="w-8 h-8 rounded-lg bg-yellow-500/10 dark:bg-yellow-500/20 flex items-center justify-center shrink-0">
              <Trophy className="w-4 h-4 text-yellow-500" />
            </div>
            <span className="text-foreground/80">{personalityLabels.leaderboard[language] || personalityLabels.leaderboard.en}</span>
          </div>
        </Link>
        {isAuthenticated ? (
          <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-background/50 dark:bg-background/20">
            <Avatar className="w-8 h-8">
              <AvatarImage src={user?.profileImageUrl || ""} />
              <AvatarFallback className="text-xs bg-primary/10 text-primary">{user?.firstName?.[0] || "U"}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <span className="text-sm font-medium truncate block">{user?.firstName || (personalityLabels.user[language] || personalityLabels.user.en)}</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="shrink-0"
              onClick={() => { window.location.href = "/api/logout"; }}
              data-testid="button-logout"
              title={personalityLabels.logout[language] || personalityLabels.logout.en}
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <div
            className="sidebar-item w-full text-sm cursor-pointer"
            onClick={() => { window.location.href = "/api/login"; }}
            data-testid="button-login"
          >
            <div className="w-8 h-8 rounded-lg bg-green-500/10 dark:bg-green-500/20 flex items-center justify-center shrink-0">
              <LogIn className="w-4 h-4 text-green-500" />
            </div>
            <span className="text-foreground/80">{personalityLabels.linkGoogle[language] || personalityLabels.linkGoogle.en}</span>
          </div>
        )}
      </div>
      <div className="px-3 py-2 text-center">
        <p className="text-[10px] text-muted-foreground/60" data-testid="text-copyright">
          &copy; {new Date().getFullYear()} مروان مختار عوض خامع. جميع الحقوق محفوظة. | برعاية مدارس الفقيد نجيب السلامي
        </p>
      </div>
    </div>
  );
}
