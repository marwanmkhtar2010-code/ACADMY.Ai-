import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getDeviceId } from "@/hooks/use-device-id";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Plus, MessageSquare, Trash2, Edit2, Check, X, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

const sidebarLabels: Record<string, { newChat: string; today: string; yesterday: string; daysAgo: (n: number) => string; noChatsYet: string; clickNewChat: string }> = {
  ar: { newChat: "محادثة جديدة", today: "اليوم", yesterday: "أمس", daysAgo: (n) => `منذ ${n} أيام`, noChatsYet: "لا توجد محادثات بعد", clickNewChat: "انقر على 'محادثة جديدة' للبدء" },
  en: { newChat: "New Chat", today: "Today", yesterday: "Yesterday", daysAgo: (n) => `${n} days ago`, noChatsYet: "No chats yet", clickNewChat: "Click 'New Chat' to start" },
  zh: { newChat: "新对话", today: "今天", yesterday: "昨天", daysAgo: (n) => `${n}天前`, noChatsYet: "暂无对话", clickNewChat: "点击'新对话'开始" },
  hi: { newChat: "नई चैट", today: "आज", yesterday: "कल", daysAgo: (n) => `${n} दिन पहले`, noChatsYet: "अभी तक कोई चैट नहीं", clickNewChat: "शुरू करने के लिए 'नई चैट' पर क्लिक करें" },
  es: { newChat: "Nuevo chat", today: "Hoy", yesterday: "Ayer", daysAgo: (n) => `hace ${n} días`, noChatsYet: "Aún no hay chats", clickNewChat: "Haz clic en 'Nuevo chat' para comenzar" },
  fr: { newChat: "Nouvelle discussion", today: "Aujourd'hui", yesterday: "Hier", daysAgo: (n) => `il y a ${n} jours`, noChatsYet: "Pas encore de discussions", clickNewChat: "Cliquez sur 'Nouvelle discussion' pour commencer" },
  bn: { newChat: "নতুন চ্যাট", today: "আজ", yesterday: "গতকাল", daysAgo: (n) => `${n} দিন আগে`, noChatsYet: "এখনো কোনো চ্যাট নেই", clickNewChat: "শুরু করতে 'নতুন চ্যাট' ক্লিক করুন" },
  pt: { newChat: "Novo chat", today: "Hoje", yesterday: "Ontem", daysAgo: (n) => `${n} dias atrás`, noChatsYet: "Nenhum chat ainda", clickNewChat: "Clique em 'Novo chat' para começar" },
  ru: { newChat: "Новый чат", today: "Сегодня", yesterday: "Вчера", daysAgo: (n) => `${n} дней назад`, noChatsYet: "Пока нет чатов", clickNewChat: "Нажмите 'Новый чат', чтобы начать" },
  ja: { newChat: "新しいチャット", today: "今日", yesterday: "昨日", daysAgo: (n) => `${n}日前`, noChatsYet: "チャットはまだありません", clickNewChat: "'新しいチャット'をクリックして開始" },
};

const localeMap: Record<string, string> = {
  ar: "ar-SA", en: "en-US", zh: "zh-CN", hi: "hi-IN",
  es: "es-ES", fr: "fr-FR", bn: "bn-BD", pt: "pt-BR",
  ru: "ru-RU", ja: "ja-JP",
};

interface Session {
  id: number;
  personalityId: number;
  deviceId: string;
  title: string;
  createdAt: string;
  updatedAt: string;
}

interface ChatSessionsSidebarProps {
  personalityId: number;
  currentSessionId: number | null;
  onSessionChange: (sessionId: number | null) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export function ChatSessionsSidebar({
  personalityId,
  currentSessionId,
  onSessionChange,
  isCollapsed,
  onToggleCollapse,
}: ChatSessionsSidebarProps) {
  const { t, language } = useLanguage();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const deviceId = getDeviceId();

  const { data: sessions = [], isLoading } = useQuery<Session[]>({
    queryKey: ["/api/personalities", personalityId, "sessions", deviceId],
    queryFn: async () => {
      const res = await fetch(`/api/personalities/${personalityId}/sessions?deviceId=${deviceId}`);
      if (!res.ok) throw new Error("Failed to fetch sessions");
      return res.json();
    },
  });

  const createSession = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/personalities/${personalityId}/sessions`, {
        deviceId,
        title: (sidebarLabels[language] || sidebarLabels.en).newChat,
      });
      return res.json();
    },
    onSuccess: (newSession: Session) => {
      queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "sessions"] });
      onSessionChange(newSession.id);
    },
  });

  const updateSession = useMutation({
    mutationFn: async ({ id, title }: { id: number; title: string }) => {
      await apiRequest("PUT", `/api/sessions/${id}`, { title });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "sessions"] });
      setEditingId(null);
    },
  });

  const deleteSession = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/sessions/${id}`);
    },
    onSuccess: (_, deletedId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "sessions"] });
      if (currentSessionId === deletedId) {
        onSessionChange(null);
      }
    },
  });

  const handleStartEdit = (session: Session) => {
    setEditingId(session.id);
    setEditTitle(session.title);
  };

  const handleSaveEdit = () => {
    if (editingId && editTitle.trim()) {
      updateSession.mutate({ id: editingId, title: editTitle.trim() });
    }
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditTitle("");
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    const l = sidebarLabels[language] || sidebarLabels.en;
    if (diffDays === 0) return l.today;
    if (diffDays === 1) return l.yesterday;
    if (diffDays < 7) return l.daysAgo(diffDays);
    return date.toLocaleDateString(localeMap[language] || "en-US", { month: "short", day: "numeric" });
  };

  if (isCollapsed) {
    return (
      <div className="w-12 border-e bg-muted/30 flex flex-col items-center py-4">
        <Button
          size="icon"
          variant="ghost"
          onClick={onToggleCollapse}
          className="mb-4"
          data-testid="button-expand-sidebar"
        >
          {language === "ar" ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </Button>
        <Button
          size="icon"
          variant="ghost"
          onClick={() => createSession.mutate()}
          disabled={createSession.isPending}
          data-testid="button-new-chat-collapsed"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  return (
    <div className="w-64 border-e bg-muted/30 flex flex-col h-full">
      <div className="p-3 border-b flex items-center justify-between gap-2">
        <Button
          onClick={() => createSession.mutate()}
          disabled={createSession.isPending}
          className="flex-1 gap-2"
          size="sm"
          data-testid="button-new-chat"
        >
          <Plus className="h-4 w-4" />
          {(sidebarLabels[language] || sidebarLabels.en).newChat}
        </Button>
        <Button
          size="icon"
          variant="ghost"
          onClick={onToggleCollapse}
          className="shrink-0"
          data-testid="button-collapse-sidebar"
        >
          {language === "ar" ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          <AnimatePresence>
            {sessions.map((session) => (
              <motion.div
                key={session.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className={cn(
                  "group rounded-lg transition-colors",
                  currentSessionId === session.id
                    ? "bg-primary/10"
                    : "hover-elevate"
                )}
              >
                {editingId === session.id ? (
                  <div className="flex items-center gap-1 p-2">
                    <Input
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="h-7 text-sm"
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleSaveEdit();
                        if (e.key === "Escape") handleCancelEdit();
                      }}
                      data-testid="input-edit-session-title"
                    />
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleSaveEdit}>
                      <Check className="h-3 w-3" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleCancelEdit}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <button
                    onClick={() => onSessionChange(session.id)}
                    className={cn(
                      "w-full flex items-start gap-2 p-2 text-start rounded-lg",
                      currentSessionId === session.id && "bg-primary/10"
                    )}
                    data-testid={`button-session-${session.id}`}
                  >
                    <MessageSquare className="h-4 w-4 mt-0.5 shrink-0 text-muted-foreground" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{session.title}</div>
                      <div className="text-xs text-muted-foreground">{formatDate(session.updatedAt)}</div>
                    </div>
                    <div className="opacity-0 group-hover:opacity-100 flex items-center gap-0.5 transition-opacity">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleStartEdit(session);
                        }}
                        data-testid={`button-edit-session-${session.id}`}
                      >
                        <Edit2 className="h-3 w-3" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6 text-destructive hover:text-destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteSession.mutate(session.id);
                        }}
                        data-testid={`button-delete-session-${session.id}`}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </button>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
          
          {sessions.length === 0 && !isLoading && (
            <div className="text-center py-8 text-muted-foreground text-sm">
              {(sidebarLabels[language] || sidebarLabels.en).noChatsYet}
              <br />
              <span className="text-xs">
                {(sidebarLabels[language] || sidebarLabels.en).clickNewChat}
              </span>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
