import { useEffect, useRef, useState } from "react";
import { useMessages, useSendMessage, useRegenerateMessage, useClearChat, useSendMessageWithImage, transcribeAudio } from "@/hooks/use-chat";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { usePersonality } from "@/hooks/use-personalities";
import { getDeviceId } from "@/hooks/use-device-id";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Paperclip, SendHorizontal, ArrowLeft, Mic, MicOff, MoreVertical, ThumbsUp, ThumbsDown, Copy, RotateCcw, X, GraduationCap, Check, Download, Trash2, FileText, MessageSquare,
  Calculator, Atom, FlaskConical, Dna, Microscope, BookOpen, Languages, 
  Code, Brain, Landmark, Globe, TrendingUp, Lightbulb, Palette, BookHeart,
  BookMarked, Scale, Stethoscope, Cog, HeartHandshake, Croissant, Volume2, VolumeX, Pin, PinOff, Pencil, Share2, Search, Camera, SwitchCamera, ClipboardList, Trophy, Home, Award, Brush, Settings2, type LucideIcon
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ChatSessionsSidebar } from "./ChatSessionsSidebar";
import { QuizModal } from "./QuizModal";
import { PracticeModeModal } from "./PracticeModeModal";
import { InteractiveWhiteboard } from "./InteractiveWhiteboard";
import { CertificateViewer } from "./CertificateViewer";
import { ExamModal } from "./ExamModal";
import { useQuery } from "@tanstack/react-query";

const educationContextLabels: Record<string, {
  settings: string;
  curriculum: string;
  educationLevel: string;
  curriculumOptions: Record<string, string>;
  levelOptions: Record<string, string>;
}> = {
  ar: { settings: "إعدادات التعلم", curriculum: "المنهج", educationLevel: "المستوى", curriculumOptions: { general: "عام", yemeni: "يمني", saudi: "سعودي", egyptian: "مصري", jordanian: "أردني", iraqi: "عراقي", american: "أمريكي", british: "بريطاني", french: "فرنسي", ib: "IB" }, levelOptions: { general: "عام", primary: "ابتدائي", middle: "إعدادي", secondary: "ثانوي", university: "جامعي" } },
  en: { settings: "Learning Settings", curriculum: "Curriculum", educationLevel: "Level", curriculumOptions: { general: "General", yemeni: "Yemeni", saudi: "Saudi", egyptian: "Egyptian", jordanian: "Jordanian", iraqi: "Iraqi", american: "American", british: "British", french: "French", ib: "IB" }, levelOptions: { general: "General", primary: "Primary", middle: "Middle", secondary: "High School", university: "University" } },
  zh: { settings: "学习设置", curriculum: "课程", educationLevel: "等级", curriculumOptions: { general: "通用", yemeni: "也门", saudi: "沙特", egyptian: "埃及", jordanian: "约旦", iraqi: "伊拉克", american: "美国", british: "英国", french: "法国", ib: "IB" }, levelOptions: { general: "通用", primary: "小学", middle: "初中", secondary: "高中", university: "大学" } },
  hi: { settings: "सीखने की सेटिंग", curriculum: "पाठ्यक्रम", educationLevel: "स्तर", curriculumOptions: { general: "सामान्य", yemeni: "यमनी", saudi: "सऊदी", egyptian: "मिस्री", jordanian: "जॉर्डन", iraqi: "इराकी", american: "अमेरिकी", british: "ब्रिटिश", french: "फ्रेंच", ib: "IB" }, levelOptions: { general: "सामान्य", primary: "प्राथमिक", middle: "माध्यमिक", secondary: "उच्च माध्यमिक", university: "विश्वविद्यालय" } },
  es: { settings: "Ajustes de aprendizaje", curriculum: "Plan", educationLevel: "Nivel", curriculumOptions: { general: "General", yemeni: "Yemeni", saudi: "Saudi", egyptian: "Egipcio", jordanian: "Jordano", iraqi: "Iraqui", american: "Americano", british: "Britanico", french: "Frances", ib: "IB" }, levelOptions: { general: "General", primary: "Primaria", middle: "Secundaria", secondary: "Preparatoria", university: "Universidad" } },
  fr: { settings: "Parametres d'apprentissage", curriculum: "Programme", educationLevel: "Niveau", curriculumOptions: { general: "General", yemeni: "Yemenite", saudi: "Saoudien", egyptian: "Egyptien", jordanian: "Jordanien", iraqi: "Irakien", american: "Americain", british: "Britannique", french: "Francais", ib: "IB" }, levelOptions: { general: "General", primary: "Primaire", middle: "College", secondary: "Lycee", university: "Universite" } },
  bn: { settings: "শেখার সেটিংস", curriculum: "পাঠ্যক্রম", educationLevel: "স্তর", curriculumOptions: { general: "সাধারণ", yemeni: "ইয়েমেনি", saudi: "সৌদি", egyptian: "মিশরীয়", jordanian: "জর্ডানীয়", iraqi: "ইরাকি", american: "আমেরিকান", british: "ব্রিটিশ", french: "ফরাসি", ib: "IB" }, levelOptions: { general: "সাধারণ", primary: "প্রাথমিক", middle: "মাধ্যমিক", secondary: "উচ্চ মাধ্যমিক", university: "বিশ্ববিদ্যালয়" } },
  pt: { settings: "Configuracoes de aprendizado", curriculum: "Curriculo", educationLevel: "Nivel", curriculumOptions: { general: "Geral", yemeni: "Iemenita", saudi: "Saudita", egyptian: "Egipcio", jordanian: "Jordaniano", iraqi: "Iraquiano", american: "Americano", british: "Britanico", french: "Frances", ib: "IB" }, levelOptions: { general: "Geral", primary: "Fundamental I", middle: "Fundamental II", secondary: "Ensino Medio", university: "Universidade" } },
  ru: { settings: "Настройки обучения", curriculum: "Программа", educationLevel: "Уровень", curriculumOptions: { general: "Общая", yemeni: "Йеменская", saudi: "Саудовская", egyptian: "Египетская", jordanian: "Иорданская", iraqi: "Иракская", american: "Американская", british: "Британская", french: "Французская", ib: "IB" }, levelOptions: { general: "Общий", primary: "Начальная", middle: "Средняя", secondary: "Старшая", university: "Университет" } },
  ja: { settings: "学習設定", curriculum: "カリキュラム", educationLevel: "レベル", curriculumOptions: { general: "一般", yemeni: "イエメン", saudi: "サウジ", egyptian: "エジプト", jordanian: "ヨルダン", iraqi: "イラク", american: "アメリカ", british: "イギリス", french: "フランス", ib: "IB" }, levelOptions: { general: "一般", primary: "小学校", middle: "中学校", secondary: "高校", university: "大学" } },
};

const chatLabels: Record<string, { homeAriaLabel: string; takeQuiz: string; practiceMode: string; whiteboard: string; certificates: string; exam: string; myProgress: string; whiteboardDrawing: string; drawingAttached: string; drawingAttachedDesc: string; student: string }> = {
  ar: { homeAriaLabel: "القائمة الرئيسية", takeQuiz: "اختبار سريع", practiceMode: "وضع التدريب", whiteboard: "السبورة", certificates: "الشهادات", exam: "الامتحان", myProgress: "تقدمي", whiteboardDrawing: "رسم من السبورة", drawingAttached: "تم إرفاق الرسم", drawingAttachedDesc: "يمكنك الآن إرسال رسالتك مع الرسم", student: "طالب" },
  en: { homeAriaLabel: "Home", takeQuiz: "Take Quiz", practiceMode: "Practice Mode", whiteboard: "Whiteboard", certificates: "Certificates", exam: "Exam", myProgress: "My Progress", whiteboardDrawing: "Whiteboard Drawing", drawingAttached: "Drawing attached", drawingAttachedDesc: "You can now send your message with the drawing", student: "Student" },
  zh: { homeAriaLabel: "首页", takeQuiz: "参加测验", practiceMode: "练习模式", whiteboard: "白板", certificates: "证书", exam: "考试", myProgress: "我的进度", whiteboardDrawing: "白板绘图", drawingAttached: "绘图已附加", drawingAttachedDesc: "您现在可以发送带有绘图的消息", student: "学生" },
  hi: { homeAriaLabel: "होम", takeQuiz: "क्विज़ लें", practiceMode: "अभ्यास मोड", whiteboard: "व्हाइटबोर्ड", certificates: "प्रमाणपत्र", exam: "परीक्षा", myProgress: "मेरी प्रगति", whiteboardDrawing: "व्हाइटबोर्ड ड्राइंग", drawingAttached: "ड्राइंग संलग्न", drawingAttachedDesc: "अब आप ड्राइंग के साथ अपना संदेश भेज सकते हैं", student: "छात्र" },
  es: { homeAriaLabel: "Inicio", takeQuiz: "Hacer prueba", practiceMode: "Modo práctica", whiteboard: "Pizarra", certificates: "Certificados", exam: "Examen", myProgress: "Mi progreso", whiteboardDrawing: "Dibujo de pizarra", drawingAttached: "Dibujo adjunto", drawingAttachedDesc: "Ahora puedes enviar tu mensaje con el dibujo", student: "Estudiante" },
  fr: { homeAriaLabel: "Accueil", takeQuiz: "Faire un quiz", practiceMode: "Mode pratique", whiteboard: "Tableau blanc", certificates: "Certificats", exam: "Examen", myProgress: "Mon progrès", whiteboardDrawing: "Dessin du tableau", drawingAttached: "Dessin joint", drawingAttachedDesc: "Vous pouvez maintenant envoyer votre message avec le dessin", student: "Étudiant" },
  bn: { homeAriaLabel: "হোম", takeQuiz: "কুইজ দিন", practiceMode: "অনুশীলন মোড", whiteboard: "হোয়াইটবোর্ড", certificates: "সার্টিফিকেট", exam: "পরীক্ষা", myProgress: "আমার অগ্রগতি", whiteboardDrawing: "হোয়াইটবোর্ড ড্রয়িং", drawingAttached: "ড্রয়িং সংযুক্ত", drawingAttachedDesc: "আপনি এখন ড্রয়িং সহ আপনার বার্তা পাঠাতে পারেন", student: "ছাত্র" },
  pt: { homeAriaLabel: "Início", takeQuiz: "Fazer quiz", practiceMode: "Modo prática", whiteboard: "Quadro branco", certificates: "Certificados", exam: "Exame", myProgress: "Meu progresso", whiteboardDrawing: "Desenho do quadro", drawingAttached: "Desenho anexado", drawingAttachedDesc: "Agora você pode enviar sua mensagem com o desenho", student: "Estudante" },
  ru: { homeAriaLabel: "Главная", takeQuiz: "Пройти тест", practiceMode: "Режим практики", whiteboard: "Доска", certificates: "Сертификаты", exam: "Экзамен", myProgress: "Мой прогресс", whiteboardDrawing: "Рисунок с доски", drawingAttached: "Рисунок прикреплён", drawingAttachedDesc: "Теперь вы можете отправить сообщение с рисунком", student: "Ученик" },
  ja: { homeAriaLabel: "ホーム", takeQuiz: "クイズに挑戦", practiceMode: "練習モード", whiteboard: "ホワイトボード", certificates: "証明書", exam: "試験", myProgress: "進捗状況", whiteboardDrawing: "ホワイトボード描画", drawingAttached: "描画を添付しました", drawingAttachedDesc: "描画と一緒にメッセージを送信できます", student: "生徒" },
};

interface ChatInterfaceProps {
  personalityId: number;
}

interface SubjectStyle {
  icon: LucideIcon;
  bgColor: string;
  iconColor: string;
  badgeColor: string;
}

function getSubjectStyle(subjectId: string | null | undefined): SubjectStyle {
  const styles: Record<string, SubjectStyle> = {
    math: { icon: Calculator, bgColor: "bg-gradient-to-br from-blue-500 to-blue-600", iconColor: "text-white", badgeColor: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300" },
    physics: { icon: Atom, bgColor: "bg-gradient-to-br from-purple-500 to-purple-600", iconColor: "text-white", badgeColor: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300" },
    chemistry: { icon: FlaskConical, bgColor: "bg-gradient-to-br from-pink-500 to-pink-600", iconColor: "text-white", badgeColor: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300" },
    biology: { icon: Dna, bgColor: "bg-gradient-to-br from-green-500 to-green-600", iconColor: "text-white", badgeColor: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300" },
    science: { icon: Microscope, bgColor: "bg-gradient-to-br from-indigo-500 to-indigo-600", iconColor: "text-white", badgeColor: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300" },
    arabic: { icon: BookOpen, bgColor: "bg-gradient-to-br from-teal-500 to-teal-600", iconColor: "text-white", badgeColor: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300" },
    english: { icon: Languages, bgColor: "bg-gradient-to-br from-yellow-500 to-amber-500", iconColor: "text-white", badgeColor: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300" },
    french: { icon: Croissant, bgColor: "bg-gradient-to-br from-blue-500 via-white to-red-500", iconColor: "text-blue-900", badgeColor: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300" },
    programming: { icon: Code, bgColor: "bg-gradient-to-br from-orange-500 to-orange-600", iconColor: "text-white", badgeColor: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300" },
    ai: { icon: Brain, bgColor: "bg-gradient-to-br from-violet-500 to-purple-600", iconColor: "text-white", badgeColor: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300" },
    history: { icon: Landmark, bgColor: "bg-gradient-to-br from-amber-500 to-amber-600", iconColor: "text-white", badgeColor: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300" },
    geography: { icon: Globe, bgColor: "bg-gradient-to-br from-cyan-500 to-cyan-600", iconColor: "text-white", badgeColor: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300" },
    economics: { icon: TrendingUp, bgColor: "bg-gradient-to-br from-rose-500 to-rose-600", iconColor: "text-white", badgeColor: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300" },
    psychology: { icon: HeartHandshake, bgColor: "bg-gradient-to-br from-fuchsia-500 to-fuchsia-600", iconColor: "text-white", badgeColor: "bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/30 dark:text-fuchsia-300" },
    philosophy: { icon: Lightbulb, bgColor: "bg-gradient-to-br from-violet-500 to-violet-600", iconColor: "text-white", badgeColor: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300" },
    islamic: { icon: BookHeart, bgColor: "bg-gradient-to-br from-emerald-500 to-emerald-600", iconColor: "text-white", badgeColor: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300" },
    quran: { icon: BookMarked, bgColor: "bg-gradient-to-br from-lime-500 to-green-600", iconColor: "text-white", badgeColor: "bg-lime-100 text-lime-700 dark:bg-lime-900/30 dark:text-lime-300" },
    civics: { icon: Scale, bgColor: "bg-gradient-to-br from-slate-500 to-slate-600", iconColor: "text-white", badgeColor: "bg-slate-100 text-slate-700 dark:bg-slate-900/30 dark:text-slate-300" },
    art: { icon: Palette, bgColor: "bg-gradient-to-br from-fuchsia-400 to-pink-500", iconColor: "text-white", badgeColor: "bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/30 dark:text-fuchsia-300" },
    university: { icon: GraduationCap, bgColor: "bg-gradient-to-br from-gray-900 to-yellow-500", iconColor: "text-yellow-400", badgeColor: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300" },
    engineering: { icon: Cog, bgColor: "bg-gradient-to-br from-slate-600 to-slate-700", iconColor: "text-white", badgeColor: "bg-slate-100 text-slate-700 dark:bg-slate-900/30 dark:text-slate-300" },
    medicine: { icon: Stethoscope, bgColor: "bg-gradient-to-br from-red-500 to-red-600", iconColor: "text-white", badgeColor: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300" },
    general: { icon: GraduationCap, bgColor: "bg-gradient-to-br from-gray-500 to-gray-600", iconColor: "text-white", badgeColor: "bg-gray-100 text-gray-700 dark:bg-gray-800/50 dark:text-gray-300" },
  };
  return styles[subjectId || "general"] || styles.general;
}

function getSubjectColor(subjectId: string | null | undefined): string {
  return getSubjectStyle(subjectId).badgeColor;
}

export function ChatInterface({ personalityId }: ChatInterfaceProps) {
  const { data: personality, isLoading: isLoadingPersonality } = usePersonality(personalityId);
  const sendMessage = useSendMessage();
  const sendMessageWithImage = useSendMessageWithImage();
  const regenerateMessage = useRegenerateMessage();
  const clearChat = useClearChat();
  const { toast } = useToast();
  const { t, language } = useLanguage();
  
  const [inputValue, setInputValue] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<{ file: File; base64: string; name: string; mimeType: string }[]>([]);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [likedIds, setLikedIds] = useState<Set<number>>(new Set());
  const [dislikedIds, setDislikedIds] = useState<Set<number>>(new Set());
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [playingId, setPlayingId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editContent, setEditContent] = useState("");
  const [pinnedIds, setPinnedIds] = useState<Set<number>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCameraRecording, setIsCameraRecording] = useState(false);
  const [showQuizModal, setShowQuizModal] = useState(false);
  const [showPracticeModal, setShowPracticeModal] = useState(false);
  const [showWhiteboard, setShowWhiteboard] = useState(false);
  const [showCertificates, setShowCertificates] = useState(false);
  const [showExamModal, setShowExamModal] = useState(false);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("environment");
  const [showContextSettings, setShowContextSettings] = useState(false);
  const [chatCurriculum, setChatCurriculum] = useState(() => localStorage.getItem("acadmy_curriculum") || "general");
  const [chatEducationLevel, setChatEducationLevel] = useState(() => localStorage.getItem("acadmy_level") || "general");
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const cameraAudioRecorderRef = useRef<MediaRecorder | null>(null);
  const cameraAudioChunksRef = useRef<Blob[]>([]);
  
  const deviceId = getDeviceId();
  
  const { data: messages = [] } = useQuery({
    queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId],
    queryFn: async () => {
      const url = currentSessionId 
        ? `/api/personalities/${personalityId}/messages?deviceId=${deviceId}&sessionId=${currentSessionId}`
        : `/api/personalities/${personalityId}/messages?deviceId=${deviceId}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch messages");
      return res.json();
    },
  });

  const getSubjectName = (subjectId: string | null | undefined): string => {
    const key = (subjectId || "general") as keyof typeof t.subjects;
    return t.subjects[key] || t.subjects.general;
  };

  useEffect(() => {
    if (scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);

  useEffect(() => {
    if (!isLoadingPersonality) {
      textareaRef.current?.focus();
    }
  }, [isLoadingPersonality, personalityId]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const isSending = sendMessage.isPending || sendMessageWithImage.isPending;
    if ((!inputValue.trim() && attachedFiles.length === 0) || isSending) return;

    const content = inputValue;
    const files = [...attachedFiles];
    
    setInputValue("");
    setAttachedFiles([]);

    try {
      const educationContext = {
        curriculum: chatCurriculum !== "general" ? chatCurriculum : undefined,
        educationLevel: chatEducationLevel !== "general" ? chatEducationLevel : undefined,
      };
      if (files.length > 0) {
        await apiRequest("POST", `/api/personalities/${personalityId}/messages/with-files`, {
          content,
          deviceId,
          sessionId: currentSessionId,
          ...educationContext,
          files: files.map(f => ({
            name: f.name,
            mimeType: f.mimeType,
            base64: f.base64
          }))
        });
        queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId] });
      } else {
        await apiRequest("POST", `/api/personalities/${personalityId}/messages`, {
          content,
          deviceId,
          sessionId: currentSessionId,
          ...educationContext,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId] });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "sessions"] });
    } catch (error) {
      setInputValue(content);
      setAttachedFiles(files);
      toast({ title: t.error, description: t.sendError, variant: "destructive" });
    }
  };

  const adjustTextareaHeight = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    for (const file of files) {
      const maxSize = 100 * 1024 * 1024; // 100MB
      if (file.size > maxSize) {
        toast({ title: t.error, description: t.fileTooLarge, variant: "destructive" });
        continue;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(",")[1];
        setAttachedFiles(prev => [...prev, { file, base64, name: file.name, mimeType: file.type }]);
        toast({ title: t.fileAttached, description: t.fileAttachedDesc });
      };
      reader.readAsDataURL(file);
    }

    if (e.target) e.target.value = '';
  };

  const removeFile = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const toggleRecording = async () => {
    if (isRecording) {
      if (mediaRecorderRef.current?.state === "recording") mediaRecorderRef.current.stop();
      setIsRecording(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream, { mimeType: "audio/webm;codecs=opus" });
        mediaRecorderRef.current = mediaRecorder;
        audioChunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) audioChunksRef.current.push(event.data);
        };

        mediaRecorder.onstop = async () => {
          stream.getTracks().forEach(track => track.stop());
          if (audioChunksRef.current.length === 0) return;
          const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
          setIsTranscribing(true);
          toast({ title: t.transcribing });
          try {
            const transcribedText = await transcribeAudio(audioBlob);
            if (transcribedText) {
              setInputValue(prev => prev ? `${prev} ${transcribedText}` : transcribedText);
              toast({ title: t.transcribed, description: t.transcribedDesc });
            }
          } catch {
            toast({ title: t.error, description: t.transcribeError, variant: "destructive" });
          } finally {
            setIsTranscribing(false);
          }
        };

        mediaRecorder.start(100);
        setIsRecording(true);
        toast({ title: t.recording, description: t.recordingDesc });
      } catch {
        toast({ title: t.error, description: t.micError, variant: "destructive" });
      }
    }
  };

  const openCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode }, 
        audio: true 
      });
      setCameraStream(stream);
      setShowCamera(true);
      setCapturedImage(null);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 100);
    } catch {
      toast({ title: t.error, description: t.cameraError, variant: "destructive" });
    }
  };

  const closeCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    if (cameraAudioRecorderRef.current?.state === "recording") {
      cameraAudioRecorderRef.current.stop();
    }
    setShowCamera(false);
    setCapturedImage(null);
    setIsCameraRecording(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement("canvas");
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
        setCapturedImage(dataUrl);
        toast({ title: t.capturedPhoto });
      }
    }
  };

  const switchCamera = async () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
    }
    const newMode = facingMode === "user" ? "environment" : "user";
    setFacingMode(newMode);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: newMode }, 
        audio: true 
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch {
      toast({ title: t.error, description: t.cameraError, variant: "destructive" });
    }
  };

  const toggleCameraRecording = async () => {
    if (isCameraRecording) {
      if (cameraAudioRecorderRef.current?.state === "recording") {
        cameraAudioRecorderRef.current.stop();
      }
      setIsCameraRecording(false);
    } else {
      try {
        const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(audioStream, { mimeType: "audio/webm;codecs=opus" });
        cameraAudioRecorderRef.current = mediaRecorder;
        cameraAudioChunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) cameraAudioChunksRef.current.push(event.data);
        };

        mediaRecorder.onstop = async () => {
          audioStream.getTracks().forEach(track => track.stop());
          if (cameraAudioChunksRef.current.length === 0) return;
          const audioBlob = new Blob(cameraAudioChunksRef.current, { type: "audio/webm" });
          setIsTranscribing(true);
          toast({ title: t.transcribing });
          try {
            const transcribedText = await transcribeAudio(audioBlob);
            if (transcribedText) {
              setInputValue(prev => prev ? `${prev} ${transcribedText}` : transcribedText);
              toast({ title: t.transcribed, description: t.transcribedDesc });
            }
          } catch {
            toast({ title: t.error, description: t.transcribeError, variant: "destructive" });
          } finally {
            setIsTranscribing(false);
          }
        };

        mediaRecorder.start(100);
        setIsCameraRecording(true);
        toast({ title: t.listening, description: t.speakNow });
      } catch {
        toast({ title: t.error, description: t.micError, variant: "destructive" });
      }
    }
  };

  const sendWithCamera = async () => {
    if (!capturedImage && !inputValue.trim()) return;
    
    const messageText = inputValue.trim() || t.capturedPhoto;
    const base64Data = capturedImage ? capturedImage.split(",")[1] : undefined;
    
    closeCamera();
    setInputValue("");
    
    try {
      if (base64Data) {
        await apiRequest("POST", `/api/personalities/${personalityId}/messages/with-files`, {
          content: messageText,
          deviceId,
          sessionId: currentSessionId,
          files: [{
            name: "camera-photo.jpg",
            mimeType: "image/jpeg",
            base64: base64Data
          }]
        });
        queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId] });
        queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "sessions"] });
      } else {
        await apiRequest("POST", `/api/personalities/${personalityId}/messages`, {
          content: messageText,
          deviceId,
          sessionId: currentSessionId
        });
        queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId] });
        queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "sessions"] });
      }
    } catch {
      toast({ title: t.error, description: t.sendError, variant: "destructive" });
    }
  };

  const copyToClipboard = async (text: string, msgId: number) => {
    await navigator.clipboard.writeText(text);
    setCopiedId(msgId);
    toast({ title: t.copied, description: t.copiedDesc });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleLike = (msgId: number) => {
    setLikedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(msgId)) newSet.delete(msgId);
      else { newSet.add(msgId); setDislikedIds(d => { const nd = new Set(d); nd.delete(msgId); return nd; }); }
      return newSet;
    });
  };

  const handleDislike = (msgId: number) => {
    setDislikedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(msgId)) newSet.delete(msgId);
      else { newSet.add(msgId); setLikedIds(l => { const nl = new Set(l); nl.delete(msgId); return nl; }); }
      return newSet;
    });
  };

  const handleRegenerate = async () => {
    if (regenerateMessage.isPending) return;
    try {
      await regenerateMessage.mutateAsync({ personalityId, sessionId: currentSessionId });
      queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId] });
      toast({ title: t.regenerated, description: t.regeneratedDesc });
    } catch {
      toast({ title: t.error, description: t.regenerateError, variant: "destructive" });
    }
  };

  const handleClearChat = async () => {
    if (clearChat.isPending) return;
    try {
      await clearChat.mutateAsync({ personalityId, sessionId: currentSessionId });
      queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId] });
      toast({ title: t.cleared, description: t.clearedDesc });
    } catch {
      toast({ title: t.error, description: t.clearError, variant: "destructive" });
    }
  };

  const handleTextToSpeech = async (text: string, msgId: number) => {
    if (playingId === msgId) {
      audioRef.current?.pause();
      setPlayingId(null);
      return;
    }
    try {
      setPlayingId(msgId);
      // Use the teacher's specific voice from personality data
      const teacherVoice = personality?.voice || "nova";
      const response = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.slice(0, 4000), voice: teacherVoice }),
      });
      if (!response.ok) throw new Error("TTS failed");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      if (audioRef.current) audioRef.current.pause();
      audioRef.current = new Audio(url);
      audioRef.current.onended = () => setPlayingId(null);
      audioRef.current.play();
    } catch {
      toast({ title: t.error, variant: "destructive" });
      setPlayingId(null);
    }
  };

  const handlePin = async (msgId: number, isPinned: boolean) => {
    try {
      await fetch(`/api/messages/${msgId}/pin`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isPinned: !isPinned, deviceId }),
      });
      setPinnedIds(prev => {
        const newSet = new Set(prev);
        if (isPinned) newSet.delete(msgId);
        else newSet.add(msgId);
        return newSet;
      });
      queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId] });
    } catch {
      toast({ title: t.error, variant: "destructive" });
    }
  };

  const handleEdit = async (msgId: number) => {
    if (!editContent.trim()) return;
    try {
      await fetch(`/api/messages/${msgId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: editContent, deviceId }),
      });
      setEditingId(null);
      setEditContent("");
      queryClient.invalidateQueries({ queryKey: ["/api/personalities", personalityId, "messages", deviceId, currentSessionId] });
      toast({ title: t.edited, description: t.editedDesc });
    } catch {
      toast({ title: t.error, variant: "destructive" });
    }
  };

  const handleShare = async () => {
    try {
      const response = await fetch(`/api/personalities/${personalityId}/share`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deviceId, sessionId: currentSessionId }),
      });
      if (!response.ok) throw new Error("Share failed");
      const { shareUrl } = await response.json();
      const fullUrl = `${window.location.origin}${shareUrl}`;
      await navigator.clipboard.writeText(fullUrl);
      toast({ title: t.shareSuccess, description: t.shareSuccessDesc });
    } catch {
      toast({ title: t.error, description: t.shareFailed, variant: "destructive" });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
    if (e.key === "Enter" && e.ctrlKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const filteredMessages = searchQuery 
    ? messages.filter((msg: { content: string }) => 
        msg.content.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : messages;

  if (isLoadingPersonality) {
    return (
      <div className="h-full flex flex-col items-center justify-center">
        <Skeleton className="w-48 h-8" />
      </div>
    );
  }

  if (!personality) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-muted-foreground p-6 text-center">
        <GraduationCap className="w-16 h-16 text-primary mb-4" />
        <h3 className="text-lg font-medium text-foreground">{t.notFound}</h3>
        <Link href="/" className="text-primary hover:underline">{t.backToHome}</Link>
      </div>
    );
  }

  return (
    <div className="h-full flex bg-background relative overflow-hidden">
      <ChatSessionsSidebar
        personalityId={personalityId}
        currentSessionId={currentSessionId}
        onSessionChange={setCurrentSessionId}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 flex items-center justify-between px-4 md:px-6 shrink-0 border-b border-border/50">
        <div className="flex items-center gap-3">
          <Link href="/">
            <Button 
              variant="ghost" 
              size="icon" 
              data-testid="button-home"
              aria-label={(chatLabels[language] || chatLabels.en).homeAriaLabel}
            >
              <Home className="w-5 h-5" />
            </Button>
          </Link>
          {(() => {
            const style = getSubjectStyle(personality.subject);
            const IconComponent = style.icon;
            return (
              <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center shadow-md", style.bgColor)}>
                <IconComponent className={cn("w-5 h-5", style.iconColor)} />
              </div>
            );
          })()}
          <div>
            <span className="text-base font-medium block">{(personality.subject && t.teacherNames[personality.subject as keyof typeof t.teacherNames]) || personality.name}</span>
            <Badge variant="secondary" className={cn("text-[10px] px-2 py-0 h-5 mt-0.5", getSubjectColor(personality.subject))}>
              {getSubjectName(personality.subject)}
            </Badge>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {showSearch && (
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-48 h-9 px-3 text-sm bg-secondary rounded-full outline-none focus:ring-2 focus:ring-primary"
                data-testid="input-search"
                dir="auto"
              />
            </div>
          )}
          <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setShowSearch(!showSearch)} data-testid="button-search">
            <Search className="w-5 h-5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full" data-testid="button-more-options">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowQuizModal(true)} data-testid="button-quiz">
                <ClipboardList className="w-4 h-4 mr-2" /> {(chatLabels[language] || chatLabels.en).takeQuiz}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowPracticeModal(true)} data-testid="button-practice">
                <Calculator className="w-4 h-4 mr-2" /> {(chatLabels[language] || chatLabels.en).practiceMode}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowWhiteboard(true)} data-testid="button-whiteboard">
                <Brush className="w-4 h-4 mr-2" /> {(chatLabels[language] || chatLabels.en).whiteboard}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowExamModal(true)} data-testid="button-exam">
                <GraduationCap className="w-4 h-4 mr-2" /> {(chatLabels[language] || chatLabels.en).exam}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowCertificates(true)} data-testid="button-certificates">
                <Award className="w-4 h-4 mr-2" /> {(chatLabels[language] || chatLabels.en).certificates}
              </DropdownMenuItem>
              <DropdownMenuItem asChild data-testid="button-progress-link">
                <Link href="/progress">
                  <Trophy className="w-4 h-4 mr-2" /> {(chatLabels[language] || chatLabels.en).myProgress}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleShare} data-testid="button-share">
                <Share2 className="w-4 h-4 mr-2" /> {t.share}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => window.open(`/api/personalities/${personalityId}/export?deviceId=${getDeviceId()}`, '_blank')} data-testid="button-export">
                <Download className="w-4 h-4 mr-2" /> {t.export}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleClearChat} className="text-destructive" data-testid="button-clear">
                <Trash2 className="w-4 h-4 mr-2" /> {t.clear}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        </header>

        <ScrollArea className="flex-1 px-4 md:px-6" ref={scrollRef}>
        <div className="max-w-3xl mx-auto py-6 space-y-6">
          {messages.length === 0 && (
            <div className="text-center py-16 space-y-6">
              {(() => {
                const style = getSubjectStyle(personality.subject);
                const IconComponent = style.icon;
                return (
                  <div className={cn("h-24 w-24 mx-auto rounded-2xl flex items-center justify-center shadow-lg", style.bgColor)}>
                    <IconComponent className={cn("w-12 h-12", style.iconColor)} />
                  </div>
                );
              })()}
              <div>
                <h1 className="text-3xl md:text-4xl font-medium mb-2">
                  <span className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">{t.hello}</span>
                </h1>
                <p className="text-muted-foreground text-lg">{t.iAm} {(personality.subject && t.teacherNames[personality.subject as keyof typeof t.teacherNames]) || personality.name}</p>
                <Badge variant="secondary" className={cn("text-sm px-3 py-1 mt-2", getSubjectColor(personality.subject))}>
                  {t.specialist} {getSubjectName(personality.subject)}
                </Badge>
              </div>
              <div className="flex flex-wrap justify-center gap-3 pt-4">
                {t.suggestions.map((suggestion, i) => (
                  <button
                    key={i}
                    onClick={() => { setInputValue(suggestion); textareaRef.current?.focus(); }}
                    className="suggestion-chip"
                    data-testid={`button-suggestion-${i}`}
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {searchQuery && filteredMessages.length === 0 && messages.length > 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="w-12 h-12 mx-auto mb-3 opacity-40" />
              <p>{t.noResults}</p>
            </div>
          )}

          {filteredMessages.map((msg: { id: number; role: string; content: string; isPinned?: boolean }) => (
            <motion.div key={msg.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={cn("flex gap-3 group relative", msg.role === 'user' ? "justify-end" : "justify-start")}>
              {(msg.isPinned || pinnedIds.has(msg.id)) && (
                <div className="absolute -top-2 left-0 text-yellow-500">
                  <Pin className="w-3 h-3" />
                </div>
              )}
              {msg.role !== 'user' && (() => {
                const style = getSubjectStyle(personality.subject);
                const IconComponent = style.icon;
                return (
                  <div className={cn("h-8 w-8 shrink-0 mt-1 rounded-lg flex items-center justify-center", style.bgColor)}>
                    <IconComponent className={cn("w-4 h-4", style.iconColor)} />
                  </div>
                );
              })()}
              <div className={cn("max-w-[85%] md:max-w-[75%]", msg.role === 'user' ? "items-end" : "items-start")}>
                {editingId === msg.id && msg.role === 'user' ? (
                  <div className="flex flex-col gap-2">
                    <textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="px-4 py-2 rounded-xl bg-secondary border resize-none min-h-[60px]"
                      dir="auto"
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => handleEdit(msg.id)} data-testid={`button-save-edit-${msg.id}`}>{t.save}</Button>
                      <Button size="sm" variant="outline" onClick={() => { setEditingId(null); setEditContent(""); }} data-testid={`button-cancel-edit-${msg.id}`}>{t.cancel}</Button>
                    </div>
                  </div>
                ) : (
                  <div className={cn("px-5 py-3 rounded-3xl text-sm md:text-base leading-relaxed", msg.role === 'user' ? "bg-primary text-primary-foreground rounded-br-lg whitespace-pre-wrap" : "bg-secondary dark:bg-card rounded-bl-lg prose prose-sm dark:prose-invert max-w-none")} dir="auto">
                    {msg.role === 'user' ? msg.content : <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content}</ReactMarkdown>}
                  </div>
                )}
                <div className={cn("flex items-center gap-1 mt-2 transition-opacity", editingId === msg.id ? "hidden" : "opacity-0 group-hover:opacity-100")}>
                  {msg.role === 'user' ? (
                    <>
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => { setEditingId(msg.id); setEditContent(msg.content); }} title={t.edit} data-testid={`button-edit-${msg.id}`}><Pencil className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" className={cn("h-8 w-8 rounded-full", (msg.isPinned || pinnedIds.has(msg.id)) && "text-yellow-500")} onClick={() => handlePin(msg.id, msg.isPinned || pinnedIds.has(msg.id))} title={(msg.isPinned || pinnedIds.has(msg.id)) ? t.unpin : t.pin} data-testid={`button-pin-${msg.id}`}>{(msg.isPinned || pinnedIds.has(msg.id)) ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}</Button>
                    </>
                  ) : (
                    <>
                      <Button variant="ghost" size="icon" className={cn("h-8 w-8 rounded-full", playingId === msg.id && "text-primary animate-pulse")} onClick={() => handleTextToSpeech(msg.content, msg.id)} title={playingId === msg.id ? t.stopReading : t.readAloud} data-testid={`button-tts-${msg.id}`}>{playingId === msg.id ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}</Button>
                      <Button variant="ghost" size="icon" className={cn("h-8 w-8 rounded-full", likedIds.has(msg.id) && "text-green-500")} onClick={() => handleLike(msg.id)} data-testid={`button-like-${msg.id}`}><ThumbsUp className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" className={cn("h-8 w-8 rounded-full", dislikedIds.has(msg.id) && "text-red-500")} onClick={() => handleDislike(msg.id)} data-testid={`button-dislike-${msg.id}`}><ThumbsDown className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => copyToClipboard(msg.content, msg.id)} data-testid={`button-copy-${msg.id}`}>{copiedId === msg.id ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}</Button>
                      <Button variant="ghost" size="icon" className={cn("h-8 w-8 rounded-full", (msg.isPinned || pinnedIds.has(msg.id)) && "text-yellow-500")} onClick={() => handlePin(msg.id, msg.isPinned || pinnedIds.has(msg.id))} title={(msg.isPinned || pinnedIds.has(msg.id)) ? t.unpin : t.pin} data-testid={`button-pin-${msg.id}`}>{(msg.isPinned || pinnedIds.has(msg.id)) ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}</Button>
                      <Button variant="ghost" size="icon" className={cn("h-8 w-8 rounded-full", regenerateMessage.isPending && "animate-spin")} onClick={handleRegenerate} disabled={regenerateMessage.isPending} data-testid={`button-regenerate-${msg.id}`}><RotateCcw className="w-4 h-4" /></Button>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        </ScrollArea>

        <div className="p-4 md:p-6 border-t">
        <div className="max-w-3xl mx-auto space-y-4">
          {attachedFiles.length > 0 && (
            <div className="flex flex-wrap gap-2 px-2 pb-2">
              {attachedFiles.map((file, index) => (
                <div key={index} className="relative group p-1 border rounded-lg bg-muted flex items-center gap-2">
                  {file.mimeType.startsWith('image/') ? (
                    <img src={`data:${file.mimeType};base64,${file.base64}`} alt="preview" className="w-10 h-10 object-cover rounded" />
                  ) : (
                    <FileText className="w-10 h-10 p-2" />
                  )}
                  <span className="text-xs truncate max-w-[100px]">{file.name}</span>
                  <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full" onClick={() => removeFile(index)} data-testid={`button-remove-file-${index}`}><X className="w-3 h-3" /></Button>
                </div>
              ))}
            </div>
          )}
          {showContextSettings && (
            <div className="flex items-center gap-2 flex-wrap px-2 pb-2">
              {(() => {
                const ecl = educationContextLabels[language] || educationContextLabels.en;
                return (
                  <>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-muted-foreground whitespace-nowrap">{ecl.curriculum}:</span>
                      <Select value={chatCurriculum} onValueChange={(v) => { setChatCurriculum(v); localStorage.setItem("acadmy_curriculum", v); }}>
                        <SelectTrigger className="h-7 text-xs w-auto min-w-[80px]" data-testid="select-chat-curriculum">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(ecl.curriculumOptions).map(([key, label]) => (
                            <SelectItem key={key} value={key}>{label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-muted-foreground whitespace-nowrap">{ecl.educationLevel}:</span>
                      <Select value={chatEducationLevel} onValueChange={(v) => { setChatEducationLevel(v); localStorage.setItem("acadmy_level", v); }}>
                        <SelectTrigger className="h-7 text-xs w-auto min-w-[80px]" data-testid="select-chat-level">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(ecl.levelOptions).map(([key, label]) => (
                            <SelectItem key={key} value={key}>{label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                );
              })()}
            </div>
          )}
          <div className="relative flex items-end gap-2 bg-secondary dark:bg-card rounded-[28px] p-2 border border-border/50">
            <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" multiple data-testid="input-file" />
            <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setShowContextSettings(!showContextSettings)} title={(educationContextLabels[language] || educationContextLabels.en).settings} data-testid="button-context-settings"><Settings2 className="w-5 h-5" /></Button>
            <Button variant="ghost" size="icon" className="rounded-full" onClick={() => fileInputRef.current?.click()} disabled={isTranscribing || sendMessage.isPending} title={t.attachFile} data-testid="button-attach"><Paperclip className="w-5 h-5" /></Button>
            <Button variant="ghost" size="icon" className="rounded-full" onClick={openCamera} disabled={isTranscribing || sendMessage.isPending} title={t.cameraSearch} data-testid="button-camera"><Camera className="w-5 h-5" /></Button>
            <textarea
              ref={textareaRef}
              value={inputValue}
              onChange={(e) => { setInputValue(e.target.value); adjustTextareaHeight(); }}
              onKeyDown={handleKeyDown}
              placeholder={isTranscribing ? t.transcribing : `${t.askPlaceholder} ${personality.name}...`}
              className="flex-1 bg-transparent resize-none p-2 outline-none min-h-[40px] max-h-[200px]"
              disabled={sendMessage.isPending || sendMessageWithImage.isPending || isTranscribing}
              dir="auto"
              rows={1}
              data-testid="input-message"
            />
            <Button variant="ghost" size="icon" className={cn("rounded-full", isRecording && "bg-destructive text-white animate-pulse")} onClick={toggleRecording} disabled={isTranscribing || sendMessage.isPending} title={isRecording ? t.stopRecording : t.voiceInput} data-testid="button-voice">{isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}</Button>
            <Button size="icon" className="rounded-full" onClick={() => handleSend()} disabled={(!inputValue.trim() && attachedFiles.length === 0) || sendMessage.isPending || isTranscribing} data-testid="button-send"><SendHorizontal className="w-5 h-5" /></Button>
          </div>
          <p className="text-center text-xs text-muted-foreground">{t.appName} - {t.disclaimer}</p>
          <p className="text-center text-[10px] text-muted-foreground/60">&copy; {new Date().getFullYear()} مروان مختار عوض خامع. جميع الحقوق محفوظة. | برعاية مدارس الفقيد نجيب السلامي</p>
          </div>
        </div>
      </div>

      {showCamera && (
        <div className="fixed inset-0 z-50 bg-black/90 flex flex-col" data-testid="camera-modal">
          <div className="flex items-center justify-between p-4 text-white">
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={closeCamera} data-testid="button-close-camera">
              <X className="w-6 h-6" />
            </Button>
            <h2 className="text-lg font-semibold">{t.cameraSearch}</h2>
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={switchCamera} data-testid="button-switch-camera">
              <SwitchCamera className="w-6 h-6" />
            </Button>
          </div>

          <div className="flex-1 flex items-center justify-center relative overflow-hidden">
            {capturedImage ? (
              <img src={capturedImage} alt="Captured" className="max-w-full max-h-full object-contain" />
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="max-w-full max-h-full object-contain"
              />
            )}
          </div>

          <div className="p-6 bg-gradient-to-t from-black/80 to-transparent">
            <p className="text-center text-white/80 text-sm mb-4">{t.askWithCamera}</p>
            
            {inputValue && (
              <div className="bg-white/10 rounded-lg p-3 mb-4 text-white text-center" dir="auto">
                {inputValue}
              </div>
            )}

            <div className="flex items-center justify-center gap-6">
              {capturedImage ? (
                <>
                  <Button
                    variant="outline"
                    className="rounded-full bg-white/10 border-white/30 text-white hover:bg-white/20"
                    onClick={() => setCapturedImage(null)}
                    data-testid="button-retake"
                  >
                    <RotateCcw className="w-5 h-5 mr-2" />
                    {t.retakePhoto}
                  </Button>
                  <Button
                    className="rounded-full bg-primary text-primary-foreground px-6"
                    onClick={sendWithCamera}
                    disabled={!inputValue.trim() && !capturedImage}
                    data-testid="button-send-with-camera"
                  >
                    <SendHorizontal className="w-5 h-5 mr-2" />
                    {t.sendWithPhoto}
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={cn(
                      "w-14 h-14 rounded-full border-2",
                      isCameraRecording 
                        ? "bg-red-500 border-red-400 animate-pulse" 
                        : "bg-white/10 border-white/30 hover:bg-white/20"
                    )}
                    onClick={toggleCameraRecording}
                    data-testid="button-camera-voice"
                  >
                    {isCameraRecording ? (
                      <MicOff className="w-6 h-6 text-white" />
                    ) : (
                      <Mic className="w-6 h-6 text-white" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-16 h-16 rounded-full bg-white border-4 border-white/50 hover:bg-white/90"
                    onClick={capturePhoto}
                    data-testid="button-capture"
                  >
                    <div className="w-12 h-12 rounded-full bg-white border-2 border-gray-300" />
                  </Button>
                  <div className="w-14" />
                </>
              )}
            </div>

            {isCameraRecording && (
              <p className="text-center text-red-400 text-sm mt-4 animate-pulse">
                {t.listening}
              </p>
            )}
          </div>
        </div>
      )}

      <QuizModal
        open={showQuizModal}
        onOpenChange={setShowQuizModal}
        personalityId={personalityId}
        subject={personality?.subject || "general"}
        deviceId={deviceId}
        language={language}
      />

      <PracticeModeModal
        open={showPracticeModal}
        onOpenChange={setShowPracticeModal}
        personalityId={personalityId}
        subject={personality?.subject || "general"}
        deviceId={deviceId}
        language={language}
      />

      <InteractiveWhiteboard
        isOpen={showWhiteboard}
        onClose={() => setShowWhiteboard(false)}
        onImageCapture={(imageData) => {
          // Attach whiteboard drawing as image
          const base64Data = imageData.split(",")[1];
          setAttachedFiles(prev => [...prev, {
            file: new File([], "whiteboard.png"),
            base64: base64Data,
            name: (chatLabels[language] || chatLabels.en).whiteboardDrawing,
            mimeType: "image/png"
          }]);
          setShowWhiteboard(false);
          toast({
            title: (chatLabels[language] || chatLabels.en).drawingAttached,
            description: (chatLabels[language] || chatLabels.en).drawingAttachedDesc
          });
        }}
        language={language}
      />

      <CertificateViewer
        isOpen={showCertificates}
        onOpenChange={setShowCertificates}
        deviceId={deviceId}
        studentName={(chatLabels[language] || chatLabels.en).student}
        language={language}
      />

      <ExamModal
        open={showExamModal}
        onOpenChange={setShowExamModal}
        personalityId={personalityId}
        subject={personality?.subject || "general"}
        deviceId={deviceId}
        language={language}
      />
    </div>
  );
}
