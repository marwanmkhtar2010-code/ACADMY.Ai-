import { useRef, useState, useEffect, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Pen, Eraser, Trash2, Undo, Send, Grid } from "lucide-react";
import { cn } from "@/lib/utils";

interface InteractiveWhiteboardProps {
  onImageCapture: (imageData: string) => void;
  language: "ar" | "en";
  isOpen: boolean;
  onClose: () => void;
}

type Tool = "pen" | "eraser";
type BrushSize = "small" | "medium" | "large";
type BrushColor = "black" | "red" | "blue" | "green";

interface DrawingState {
  imageData: ImageData;
}

const brushSizes: Record<BrushSize, number> = {
  small: 2,
  medium: 5,
  large: 10,
};

const brushColors: Record<BrushColor, string> = {
  black: "#000000",
  red: "#ef4444",
  blue: "#3b82f6",
  green: "#22c55e",
};

const translations = {
  en: {
    title: "Interactive Whiteboard",
    pen: "Pen",
    eraser: "Eraser",
    clear: "Clear",
    undo: "Undo",
    sendToAI: "Send to AI",
    grid: "Grid",
    small: "S",
    medium: "M",
    large: "L",
  },
  ar: {
    title: "السبورة التفاعلية",
    pen: "قلم",
    eraser: "ممحاة",
    clear: "مسح",
    undo: "تراجع",
    sendToAI: "إرسال للذكاء الاصطناعي",
    grid: "شبكة",
    small: "ص",
    medium: "م",
    large: "ك",
  },
};

export function InteractiveWhiteboard({
  onImageCapture,
  language,
  isOpen,
  onClose,
}: InteractiveWhiteboardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<Tool>("pen");
  const [brushSize, setBrushSize] = useState<BrushSize>("medium");
  const [brushColor, setBrushColor] = useState<BrushColor>("black");
  const [showGrid, setShowGrid] = useState(false);
  const [history, setHistory] = useState<DrawingState[]>([]);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);

  const t = translations[language];
  const isRTL = language === "ar";

  const getCanvasContext = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    return canvas.getContext("2d");
  }, []);

  const saveState = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = getCanvasContext();
    if (!canvas || !ctx) return;
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory((prev) => [...prev, { imageData }]);
  }, [getCanvasContext]);

  const drawGrid = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = getCanvasContext();
    if (!canvas || !ctx) return;

    ctx.strokeStyle = "#e5e7eb";
    ctx.lineWidth = 0.5;

    const gridSize = 20;

    for (let x = 0; x <= canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }

    for (let y = 0; y <= canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }
  }, [getCanvasContext]);

  const clearCanvas = useCallback(
    (saveToHistory = true) => {
      const canvas = canvasRef.current;
      const ctx = getCanvasContext();
      if (!canvas || !ctx) return;

      if (saveToHistory) {
        saveState();
      }

      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (showGrid) {
        drawGrid();
      }
    },
    [getCanvasContext, saveState, showGrid, drawGrid]
  );

  const initCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = getCanvasContext();
    if (!canvas || !ctx) return;

    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (showGrid) {
      drawGrid();
    }

    setHistory([]);
  }, [getCanvasContext, showGrid, drawGrid]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(initCanvas, 100);
    }
  }, [isOpen, initCanvas]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = getCanvasContext();
    if (!canvas || !ctx || !isOpen) return;

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (showGrid) {
      drawGrid();
    }

    if (history.length > 0) {
      const lastState = history[history.length - 1];
      ctx.putImageData(lastState.imageData, 0, 0);
      if (showGrid) {
        drawGrid();
      }
    }
  }, [showGrid, getCanvasContext, drawGrid, history, isOpen]);

  const getCoordinates = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();
    let clientX: number, clientY: number;

    if ("touches" in e) {
      if (e.touches.length === 0) return null;
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  const startDrawing = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ) => {
    e.preventDefault();
    const coords = getCoordinates(e);
    if (!coords) return;

    saveState();
    setIsDrawing(true);
    lastPointRef.current = coords;
  };

  const draw = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ) => {
    e.preventDefault();
    if (!isDrawing) return;

    const coords = getCoordinates(e);
    const ctx = getCanvasContext();
    if (!coords || !ctx || !lastPointRef.current) return;

    ctx.beginPath();
    ctx.moveTo(lastPointRef.current.x, lastPointRef.current.y);
    ctx.lineTo(coords.x, coords.y);

    if (tool === "eraser") {
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = brushSizes[brushSize] * 3;
    } else {
      ctx.strokeStyle = brushColors[brushColor];
      ctx.lineWidth = brushSizes[brushSize];
    }

    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();

    lastPointRef.current = coords;
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    lastPointRef.current = null;
  };

  const handleUndo = () => {
    if (history.length === 0) return;

    const ctx = getCanvasContext();
    const canvas = canvasRef.current;
    if (!ctx || !canvas) return;

    const newHistory = [...history];
    newHistory.pop();

    if (newHistory.length === 0) {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      if (showGrid) {
        drawGrid();
      }
    } else {
      const prevState = newHistory[newHistory.length - 1];
      ctx.putImageData(prevState.imageData, 0, 0);
    }

    setHistory(newHistory);
  };

  const handleSendToAI = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const imageData = canvas.toDataURL("image/png");
    onImageCapture(imageData);
    onClose();
  };

  const colorButtons: { color: BrushColor; bgClass: string }[] = [
    { color: "black", bgClass: "bg-black" },
    { color: "red", bgClass: "bg-red-500" },
    { color: "blue", bgClass: "bg-blue-500" },
    { color: "green", bgClass: "bg-green-500" },
  ];

  const sizeButtons: { size: BrushSize; label: string }[] = [
    { size: "small", label: t.small },
    { size: "medium", label: t.medium },
    { size: "large", label: t.large },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent
        className={cn(
          "max-w-4xl w-[95vw] h-[85vh] flex flex-col p-4",
          isRTL && "rtl"
        )}
        data-testid="whiteboard-dialog"
      >
        <DialogHeader>
          <DialogTitle data-testid="whiteboard-title">{t.title}</DialogTitle>
        </DialogHeader>

        <div
          className={cn(
            "flex flex-wrap items-center gap-2 py-2 border-b",
            isRTL && "flex-row-reverse"
          )}
        >
          <div className="flex items-center gap-1">
            <Button
              size="icon"
              variant={tool === "pen" ? "default" : "outline"}
              onClick={() => setTool("pen")}
              data-testid="button-pen"
              title={t.pen}
            >
              <Pen className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              variant={tool === "eraser" ? "default" : "outline"}
              onClick={() => setTool("eraser")}
              data-testid="button-eraser"
              title={t.eraser}
            >
              <Eraser className="h-4 w-4" />
            </Button>
          </div>

          <div className="h-6 w-px bg-border mx-1" />

          <div className="flex items-center gap-1">
            {colorButtons.map(({ color, bgClass }) => (
              <button
                key={color}
                className={cn(
                  "w-6 h-6 rounded-full border-2 transition-transform",
                  bgClass,
                  brushColor === color
                    ? "border-primary scale-110"
                    : "border-transparent"
                )}
                onClick={() => setBrushColor(color)}
                data-testid={`button-color-${color}`}
                disabled={tool === "eraser"}
              />
            ))}
          </div>

          <div className="h-6 w-px bg-border mx-1" />

          <div className="flex items-center gap-1">
            {sizeButtons.map(({ size, label }) => (
              <Button
                key={size}
                size="sm"
                variant={brushSize === size ? "default" : "outline"}
                onClick={() => setBrushSize(size)}
                data-testid={`button-size-${size}`}
                className="w-8 h-8 p-0"
              >
                {label}
              </Button>
            ))}
          </div>

          <div className="h-6 w-px bg-border mx-1" />

          <Button
            size="icon"
            variant={showGrid ? "default" : "outline"}
            onClick={() => setShowGrid(!showGrid)}
            data-testid="button-grid"
            title={t.grid}
          >
            <Grid className="h-4 w-4" />
          </Button>

          <div className="flex-1" />

          <div className="flex items-center gap-1">
            <Button
              size="icon"
              variant="outline"
              onClick={handleUndo}
              disabled={history.length === 0}
              data-testid="button-undo"
              title={t.undo}
            >
              <Undo className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              variant="outline"
              onClick={() => clearCanvas()}
              data-testid="button-clear"
              title={t.clear}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
            <Button
              onClick={handleSendToAI}
              data-testid="button-send-to-ai"
              className="gap-2"
            >
              <Send className="h-4 w-4" />
              {t.sendToAI}
            </Button>
          </div>
        </div>

        <div className="flex-1 relative border rounded-md overflow-hidden bg-white">
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full cursor-crosshair touch-none"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            onTouchCancel={stopDrawing}
            data-testid="whiteboard-canvas"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
