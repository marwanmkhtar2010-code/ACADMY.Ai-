import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, XCircle, Trophy, ChevronLeft, ChevronRight } from "lucide-react";
import { getTranslation, Language } from "@/lib/translations";
import { apiRequest } from "@/lib/queryClient";
import { motion, AnimatePresence } from "framer-motion";

const configLabels: Record<string, {
  generatingQuiz: string;
  questionOf: (c: number, t: number) => string;
  close: string;
  curriculum: string;
  educationLevel: string;
  topic: string;
  topicPlaceholder: string;
  curriculumOptions: Record<string, string>;
  levelOptions: Record<string, string>;
}> = {
  ar: {
    generatingQuiz: "جاري إنشاء الاختبار...",
    questionOf: (c, t) => `السؤال ${c} من ${t}`,
    close: "إغلاق",
    curriculum: "المنهج الدراسي",
    educationLevel: "المستوى التعليمي",
    topic: "الدرس / الموضوع",
    topicPlaceholder: "مثال: الكسور، قوانين نيوتن، المعادلات...",
    curriculumOptions: { general: "عام", yemeni: "يمني", saudi: "سعودي", egyptian: "مصري", jordanian: "أردني", iraqi: "عراقي", american: "أمريكي", british: "بريطاني", french: "فرنسي", ib: "البكالوريا الدولية (IB)" },
    levelOptions: { primary: "ابتدائي", middle: "إعدادي / متوسط", secondary: "ثانوي", university: "جامعي", general: "عام" },
  },
  en: {
    generatingQuiz: "Generating quiz...",
    questionOf: (c, t) => `Question ${c} of ${t}`,
    close: "Close",
    curriculum: "Curriculum",
    educationLevel: "Education Level",
    topic: "Lesson / Topic",
    topicPlaceholder: "e.g. Fractions, Newton's Laws, Equations...",
    curriculumOptions: { general: "General", yemeni: "Yemeni", saudi: "Saudi", egyptian: "Egyptian", jordanian: "Jordanian", iraqi: "Iraqi", american: "American", british: "British", french: "French", ib: "International Baccalaureate (IB)" },
    levelOptions: { primary: "Primary", middle: "Middle School", secondary: "High School", university: "University", general: "General" },
  },
  zh: {
    generatingQuiz: "正在生成测验...",
    questionOf: (c, t) => `第 ${c} 题，共 ${t} 题`,
    close: "关闭",
    curriculum: "课程体系",
    educationLevel: "教育水平",
    topic: "课程 / 主题",
    topicPlaceholder: "例如：分数、牛顿定律、方程式...",
    curriculumOptions: { general: "通用", yemeni: "也门", saudi: "沙特", egyptian: "埃及", jordanian: "约旦", iraqi: "伊拉克", american: "美国", british: "英国", french: "法国", ib: "国际文凭 (IB)" },
    levelOptions: { primary: "小学", middle: "初中", secondary: "高中", university: "大学", general: "通用" },
  },
  hi: {
    generatingQuiz: "क्विज़ बना रहा है...",
    questionOf: (c, t) => `प्रश्न ${c} / ${t}`,
    close: "बंद करें",
    curriculum: "पाठ्यक्रम",
    educationLevel: "शिक्षा स्तर",
    topic: "पाठ / विषय",
    topicPlaceholder: "उदाहरण: भिन्न, न्यूटन के नियम, समीकरण...",
    curriculumOptions: { general: "सामान्य", yemeni: "यमनी", saudi: "सऊदी", egyptian: "मिस्री", jordanian: "जॉर्डन", iraqi: "इराकी", american: "अमेरिकी", british: "ब्रिटिश", french: "फ्रेंच", ib: "अंतर्राष्ट्रीय बैकलॉरिएट (IB)" },
    levelOptions: { primary: "प्राथमिक", middle: "माध्यमिक", secondary: "उच्च माध्यमिक", university: "विश्वविद्यालय", general: "सामान्य" },
  },
  es: {
    generatingQuiz: "Generando prueba...",
    questionOf: (c, t) => `Pregunta ${c} de ${t}`,
    close: "Cerrar",
    curriculum: "Plan de estudios",
    educationLevel: "Nivel educativo",
    topic: "Lección / Tema",
    topicPlaceholder: "Ej: Fracciones, Leyes de Newton, Ecuaciones...",
    curriculumOptions: { general: "General", yemeni: "Yemení", saudi: "Saudí", egyptian: "Egipcio", jordanian: "Jordano", iraqi: "Iraquí", american: "Americano", british: "Británico", french: "Francés", ib: "Bachillerato Internacional (IB)" },
    levelOptions: { primary: "Primaria", middle: "Secundaria", secondary: "Preparatoria", university: "Universidad", general: "General" },
  },
  fr: {
    generatingQuiz: "Génération du quiz...",
    questionOf: (c, t) => `Question ${c} sur ${t}`,
    close: "Fermer",
    curriculum: "Programme scolaire",
    educationLevel: "Niveau d'éducation",
    topic: "Leçon / Sujet",
    topicPlaceholder: "Ex: Fractions, Lois de Newton, Équations...",
    curriculumOptions: { general: "Général", yemeni: "Yéménite", saudi: "Saoudien", egyptian: "Égyptien", jordanian: "Jordanien", iraqi: "Irakien", american: "Américain", british: "Britannique", french: "Français", ib: "Baccalauréat International (IB)" },
    levelOptions: { primary: "Primaire", middle: "Collège", secondary: "Lycée", university: "Université", general: "Général" },
  },
  bn: {
    generatingQuiz: "কুইজ তৈরি হচ্ছে...",
    questionOf: (c, t) => `প্রশ্ন ${c} / ${t}`,
    close: "বন্ধ করুন",
    curriculum: "পাঠ্যক্রম",
    educationLevel: "শিক্ষার স্তর",
    topic: "পাঠ / বিষয়",
    topicPlaceholder: "উদাহরণ: ভগ্নাংশ, নিউটনের সূত্র, সমীকরণ...",
    curriculumOptions: { general: "সাধারণ", yemeni: "ইয়েমেনি", saudi: "সৌদি", egyptian: "মিশরীয়", jordanian: "জর্ডানীয়", iraqi: "ইরাকি", american: "আমেরিকান", british: "ব্রিটিশ", french: "ফরাসি", ib: "আন্তর্জাতিক ব্যাকালরেট (IB)" },
    levelOptions: { primary: "প্রাথমিক", middle: "মাধ্যমিক", secondary: "উচ্চ মাধ্যমিক", university: "বিশ্ববিদ্যালয়", general: "সাধারণ" },
  },
  pt: {
    generatingQuiz: "Gerando quiz...",
    questionOf: (c, t) => `Questão ${c} de ${t}`,
    close: "Fechar",
    curriculum: "Currículo",
    educationLevel: "Nível educacional",
    topic: "Lição / Tópico",
    topicPlaceholder: "Ex: Frações, Leis de Newton, Equações...",
    curriculumOptions: { general: "Geral", yemeni: "Iemenita", saudi: "Saudita", egyptian: "Egípcio", jordanian: "Jordaniano", iraqi: "Iraquiano", american: "Americano", british: "Britânico", french: "Francês", ib: "Bacharelado Internacional (IB)" },
    levelOptions: { primary: "Fundamental I", middle: "Fundamental II", secondary: "Ensino Médio", university: "Universidade", general: "Geral" },
  },
  ru: {
    generatingQuiz: "Создание теста...",
    questionOf: (c, t) => `Вопрос ${c} из ${t}`,
    close: "Закрыть",
    curriculum: "Учебная программа",
    educationLevel: "Уровень образования",
    topic: "Урок / Тема",
    topicPlaceholder: "Например: Дроби, Законы Ньютона, Уравнения...",
    curriculumOptions: { general: "Общая", yemeni: "Йеменская", saudi: "Саудовская", egyptian: "Египетская", jordanian: "Иорданская", iraqi: "Иракская", american: "Американская", british: "Британская", french: "Французская", ib: "Международный бакалавриат (IB)" },
    levelOptions: { primary: "Начальная школа", middle: "Средняя школа", secondary: "Старшая школа", university: "Университет", general: "Общий" },
  },
  ja: {
    generatingQuiz: "クイズを生成中...",
    questionOf: (c, t) => `問題 ${c} / ${t}`,
    close: "閉じる",
    curriculum: "カリキュラム",
    educationLevel: "教育レベル",
    topic: "レッスン / トピック",
    topicPlaceholder: "例：分数、ニュートンの法則、方程式...",
    curriculumOptions: { general: "一般", yemeni: "イエメン", saudi: "サウジ", egyptian: "エジプト", jordanian: "ヨルダン", iraqi: "イラク", american: "アメリカ", british: "イギリス", french: "フランス", ib: "国際バカロレア (IB)" },
    levelOptions: { primary: "小学校", middle: "中学校", secondary: "高校", university: "大学", general: "一般" },
  },
};

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface Quiz {
  id: number;
  title: string;
  questions: Question[];
  totalQuestions: number;
}

interface QuizResult {
  score: number;
  correctCount: number;
  totalQuestions: number;
  pointsEarned: number;
  questions: Question[];
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  personalityId: number;
  subject: string;
  deviceId: string;
  language: Language;
}

export function QuizModal({ open, onOpenChange, personalityId, subject, deviceId, language }: Props) {
  const t = getTranslation(language);
  const isRTL = language === "ar";
  const queryClient = useQueryClient();
  const cl = configLabels[language] || configLabels.en;

  const [step, setStep] = useState<"config" | "quiz" | "result">("config");
  const [difficulty, setDifficulty] = useState("medium");
  const [numQuestions, setNumQuestions] = useState("5");
  const [curriculum, setCurriculum] = useState("general");
  const [educationLevel, setEducationLevel] = useState("general");
  const [topic, setTopic] = useState("");
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<{ [key: number]: number }>({});
  const [result, setResult] = useState<QuizResult | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const generateQuiz = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/quiz/generate", {
        deviceId,
        personalityId,
        subject,
        difficulty,
        numQuestions: parseInt(numQuestions),
        curriculum,
        educationLevel,
        topic: topic.trim() || undefined,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setQuiz(data);
      setStep("quiz");
      setCurrentQuestion(0);
      setAnswers({});
    },
  });

  const submitQuiz = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/quiz/${quiz?.id}/submit`, {
        deviceId,
        answers: Object.values(answers),
      });
      return res.json();
    },
    onSuccess: (data) => {
      setResult(data);
      setStep("result");
      queryClient.invalidateQueries({ queryKey: ["/api/progress", deviceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/achievements", deviceId] });
    },
  });

  const handleClose = () => {
    setStep("config");
    setQuiz(null);
    setAnswers({});
    setResult(null);
    setShowExplanation(false);
    onOpenChange(false);
  };

  const questions = (quiz?.questions || []) as Question[];
  const progress = questions.length > 0 ? ((currentQuestion + 1) / questions.length) * 100 : 0;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className={`max-w-2xl max-h-[90vh] overflow-y-auto ${isRTL ? "rtl" : "ltr"}`} dir={isRTL ? "rtl" : "ltr"}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-primary" />
            {t.quiz}
          </DialogTitle>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {step === "config" && (
            <motion.div
              key="config"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm">{cl.curriculum}</Label>
                  <Select value={curriculum} onValueChange={setCurriculum}>
                    <SelectTrigger className="mt-1.5" data-testid="select-curriculum">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(cl.curriculumOptions).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm">{cl.educationLevel}</Label>
                  <Select value={educationLevel} onValueChange={setEducationLevel}>
                    <SelectTrigger className="mt-1.5" data-testid="select-education-level">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(cl.levelOptions).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm">{t.quizDifficulty}</Label>
                  <Select value={difficulty} onValueChange={setDifficulty}>
                    <SelectTrigger className="mt-1.5" data-testid="select-difficulty">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">{t.easy}</SelectItem>
                      <SelectItem value="medium">{t.medium}</SelectItem>
                      <SelectItem value="hard">{t.hard}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm">{t.numQuestions}</Label>
                  <Select value={numQuestions} onValueChange={setNumQuestions}>
                    <SelectTrigger className="mt-1.5" data-testid="select-num-questions">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3</SelectItem>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="15">15</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-sm">{cl.topic}</Label>
                <Input
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder={cl.topicPlaceholder}
                  className="mt-1.5"
                  data-testid="input-quiz-topic"
                />
              </div>

              <Button
                onClick={() => generateQuiz.mutate()}
                disabled={generateQuiz.isPending}
                className="w-full"
                data-testid="button-generate-quiz"
              >
                {generateQuiz.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    {cl.generatingQuiz}
                  </>
                ) : (
                  t.generateQuiz
                )}
              </Button>
            </motion.div>
          )}

          {step === "quiz" && quiz && questions.length > 0 && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{cl.questionOf(currentQuestion + 1, questions.length)}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-6">{questions[currentQuestion]?.question}</h3>
                  
                  <RadioGroup
                    value={answers[currentQuestion]?.toString()}
                    onValueChange={(value) => setAnswers({ ...answers, [currentQuestion]: parseInt(value) })}
                    className="space-y-3"
                  >
                    {questions[currentQuestion]?.options.map((option, index) => (
                      <div key={index} className="flex items-center space-x-3 rtl:space-x-reverse">
                        <RadioGroupItem value={index.toString()} id={`option-${index}`} data-testid={`option-${index}`} />
                        <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer p-3 rounded-lg hover:bg-muted">
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              <div className="flex justify-between gap-4">
                <Button
                  variant="outline"
                  onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                  disabled={currentQuestion === 0}
                  data-testid="button-prev-question"
                >
                  <ChevronLeft className={`w-4 h-4 ${isRTL ? "rotate-180" : ""}`} />
                  {t.previousQuestion}
                </Button>

                {currentQuestion < questions.length - 1 ? (
                  <Button
                    onClick={() => setCurrentQuestion(currentQuestion + 1)}
                    disabled={answers[currentQuestion] === undefined}
                    data-testid="button-next-question"
                  >
                    {t.nextQuestion}
                    <ChevronRight className={`w-4 h-4 ${isRTL ? "rotate-180" : ""}`} />
                  </Button>
                ) : (
                  <Button
                    onClick={() => submitQuiz.mutate()}
                    disabled={Object.keys(answers).length !== questions.length || submitQuiz.isPending}
                    data-testid="button-submit-quiz"
                  >
                    {submitQuiz.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : t.submitQuiz}
                  </Button>
                )}
              </div>
            </motion.div>
          )}

          {step === "result" && result && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <div className="text-center py-6">
                <div className={`text-6xl font-bold ${result.score >= 70 ? "text-green-500" : result.score >= 50 ? "text-yellow-500" : "text-red-500"}`}>
                  {result.score}%
                </div>
                <p className="text-xl mt-2">{t.quizScore}</p>
                <div className="flex justify-center gap-4 mt-4 flex-wrap">
                  <Badge variant="secondary" className="text-lg py-2 px-4">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    {result.correctCount} / {result.totalQuestions}
                  </Badge>
                  <Badge variant="secondary" className="text-lg py-2 px-4">
                    <Trophy className="w-4 h-4 mr-2 text-yellow-500" />
                    +{result.pointsEarned} {t.points}
                  </Badge>
                </div>
              </div>

              <Button variant="outline" onClick={() => setShowExplanation(!showExplanation)} className="w-full" data-testid="button-review">
                {t.reviewAnswers}
              </Button>

              {showExplanation && (
                <div className="space-y-4 max-h-60 overflow-y-auto">
                  {result.questions.map((q, index) => (
                    <Card key={index} className={answers[index] === q.correctAnswer ? "border-green-500/50" : "border-red-500/50"}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-2">
                          {answers[index] === q.correctAnswer ? (
                            <CheckCircle className="w-5 h-5 text-green-500 shrink-0 mt-1" />
                          ) : (
                            <XCircle className="w-5 h-5 text-red-500 shrink-0 mt-1" />
                          )}
                          <div>
                            <p className="font-medium">{q.question}</p>
                            <p className="text-sm text-green-600 dark:text-green-400 mt-2">
                              {t.correctAnswers}: {q.options[q.correctAnswer]}
                            </p>
                            <p className="text-sm text-muted-foreground mt-1">
                              {t.explanation}: {q.explanation}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              <Button onClick={handleClose} className="w-full" data-testid="button-close-quiz">
                {cl.close}
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
