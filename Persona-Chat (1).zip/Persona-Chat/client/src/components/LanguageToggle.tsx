import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { Languages, Check } from "lucide-react";
import { Language } from "@/lib/translations";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const languageOptions: { code: Language; label: string; shortCode: string }[] = [
  { code: "ar", label: "العربية", shortCode: "AR" },
  { code: "en", label: "English", shortCode: "EN" },
  { code: "zh", label: "中文", shortCode: "ZH" },
  { code: "hi", label: "हिन्दी", shortCode: "HI" },
  { code: "es", label: "Español", shortCode: "ES" },
  { code: "fr", label: "Français", shortCode: "FR" },
  { code: "bn", label: "বাংলা", shortCode: "BN" },
  { code: "pt", label: "Português", shortCode: "PT" },
  { code: "ru", label: "Русский", shortCode: "RU" },
  { code: "ja", label: "日本語", shortCode: "JA" },
];

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage();
  const currentLang = languageOptions.find((l) => l.code === language);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full"
          data-testid="button-language-toggle"
          title={currentLang?.label || "Language"}
        >
          <Languages className="h-5 w-5" />
          <span className="sr-only">Select language</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[160px]">
        {languageOptions.map((option) => (
          <DropdownMenuItem
            key={option.code}
            onClick={() => setLanguage(option.code)}
            className="flex items-center justify-between gap-2 cursor-pointer"
            data-testid={`lang-option-${option.code}`}
          >
            <span className="flex items-center gap-2">
              <span className="text-xs font-mono text-muted-foreground w-5">{option.shortCode}</span>
              <span>{option.label}</span>
            </span>
            {language === option.code && (
              <Check className="h-4 w-4 text-primary" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
