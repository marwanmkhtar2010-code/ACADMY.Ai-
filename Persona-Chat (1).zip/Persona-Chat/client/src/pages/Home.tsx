import { PersonalityList } from "@/components/PersonalityList";
import { GraduationCap, BookOpen, Calculator, Atom, Code, Trophy } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const homeLabels: Record<string, Record<string, string>> = {
  subtitle: {
    ar: "منصتك الذكية للتعلم مع أساتذة متخصصين",
    en: "Your smart learning platform with specialized teachers",
    zh: "与专业教师一起学习的智能平台",
    hi: "विशेषज्ञ शिक्षकों के साथ आपका स्मार्ट लर्निंग प्लेटफ़ॉर्म",
    es: "Tu plataforma de aprendizaje inteligente con profesores especializados",
    fr: "Votre plateforme d'apprentissage intelligente avec des enseignants spécialisés",
    bn: "বিশেষজ্ঞ শিক্ষকদের সাথে আপনার স্মার্ট লার্নিং প্ল্যাটফর্ম",
    pt: "Sua plataforma inteligente de aprendizado com professores especializados",
    ru: "Ваша умная образовательная платформа со специализированными учителями",
    ja: "専門教師と学ぶスマートラーニングプラットフォーム",
  },
  mathTeacher: {
    ar: "أستاذ الرياضيات",
    en: "Math Teacher",
    zh: "数学教师",
    hi: "गणित शिक्षक",
    es: "Profesor de Matemáticas",
    fr: "Professeur de Mathématiques",
    bn: "গণিত শিক্ষক",
    pt: "Professor de Matemática",
    ru: "Учитель математики",
    ja: "数学の先生",
  },
  physicsTeacher: {
    ar: "أستاذة الفيزياء",
    en: "Physics Teacher",
    zh: "物理教师",
    hi: "भौतिकी शिक्षक",
    es: "Profesor de Física",
    fr: "Professeur de Physique",
    bn: "পদার্থবিদ্যা শিক্ষক",
    pt: "Professor de Física",
    ru: "Учитель физики",
    ja: "物理の先生",
  },
  programmingTeacher: {
    ar: "أستاذ البرمجة",
    en: "Programming Teacher",
    zh: "编程教师",
    hi: "प्रोग्रामिंग शिक्षक",
    es: "Profesor de Programación",
    fr: "Professeur de Programmation",
    bn: "প্রোগ্রামিং শিক্ষক",
    pt: "Professor de Programação",
    ru: "Учитель программирования",
    ja: "プログラミングの先生",
  },
  andMore: {
    ar: "والمزيد...",
    en: "And more...",
    zh: "更多...",
    hi: "और भी...",
    es: "Y más...",
    fr: "Et plus encore...",
    bn: "এবং আরও...",
    pt: "E mais...",
    ru: "И другие...",
    ja: "その他...",
  },
  selectTeacher: {
    ar: "اختر أستاذاً من القائمة الجانبية للبدء في المحادثة",
    en: "Select a teacher from the sidebar to start chatting",
    zh: "从侧边栏选择一位教师开始对话",
    hi: "चैट शुरू करने के लिए साइडबार से एक शिक्षक चुनें",
    es: "Selecciona un profesor de la barra lateral para comenzar a chatear",
    fr: "Sélectionnez un enseignant dans la barre latérale pour commencer à discuter",
    bn: "চ্যাট শুরু করতে সাইডবার থেকে একজন শিক্ষক নির্বাচন করুন",
    pt: "Selecione um professor na barra lateral para começar a conversar",
    ru: "Выберите учителя на боковой панели, чтобы начать общение",
    ja: "サイドバーから教師を選んでチャットを始めましょう",
  },
  progressButton: {
    ar: "تقدمي وإنجازاتي",
    en: "My Progress & Achievements",
    zh: "我的进度与成就",
    hi: "मेरी प्रगति और उपलब्धियाँ",
    es: "Mi progreso y logros",
    fr: "Mes progrès et réalisations",
    bn: "আমার অগ্রগতি ও অর্জন",
    pt: "Meu progresso e conquistas",
    ru: "Мой прогресс и достижения",
    ja: "学習の進捗と実績",
  },
};

export default function Home() {
  const { t, language } = useLanguage();

  return (
    <div className="h-screen w-full flex overflow-hidden bg-background">
      <aside className="w-full md:w-[280px] lg:w-[300px] shrink-0 h-full">
        <PersonalityList />
      </aside>

      <main className="hidden md:flex flex-1 flex-col items-center justify-center p-6">
        <div className="text-center space-y-8 max-w-2xl animate-fade-in">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center mx-auto shadow-lg">
            <GraduationCap className="w-12 h-12 text-white" />
          </div>
          
          <div className="space-y-3">
            <h1 className="text-4xl md:text-5xl font-bold">
              <span className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">{t.appName}</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              {homeLabels.subtitle[language] || homeLabels.subtitle.en}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-6 max-w-lg mx-auto">
            <div className="suggestion-chip flex items-center gap-3" data-testid="feature-math">
              <Calculator className="w-5 h-5 text-blue-500 shrink-0" />
              <span>{homeLabels.mathTeacher[language] || homeLabels.mathTeacher.en}</span>
            </div>
            <div className="suggestion-chip flex items-center gap-3" data-testid="feature-physics">
              <Atom className="w-5 h-5 text-purple-500 shrink-0" />
              <span>{homeLabels.physicsTeacher[language] || homeLabels.physicsTeacher.en}</span>
            </div>
            <div className="suggestion-chip flex items-center gap-3" data-testid="feature-programming">
              <Code className="w-5 h-5 text-orange-500 shrink-0" />
              <span>{homeLabels.programmingTeacher[language] || homeLabels.programmingTeacher.en}</span>
            </div>
            <div className="suggestion-chip flex items-center gap-3" data-testid="feature-more">
              <BookOpen className="w-5 h-5 text-green-500 shrink-0" />
              <span>{homeLabels.andMore[language] || homeLabels.andMore.en}</span>
            </div>
          </div>

          <p className="text-sm text-muted-foreground pt-4">
            {homeLabels.selectTeacher[language] || homeLabels.selectTeacher.en}
          </p>

          <Link href="/progress">
            <Button variant="outline" size="lg" className="mt-6 gap-2" data-testid="button-progress">
              <Trophy className="w-5 h-5 text-yellow-500" />
              {homeLabels.progressButton[language] || homeLabels.progressButton.en}
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
