import { ProgressDashboard } from "@/components/ProgressDashboard";
import { useLanguage } from "@/contexts/LanguageContext";
import { getDeviceId } from "@/hooks/use-device-id";

export default function Progress() {
  const { language } = useLanguage();
  const deviceId = getDeviceId();

  return <ProgressDashboard deviceId={deviceId} language={language} />;
}
