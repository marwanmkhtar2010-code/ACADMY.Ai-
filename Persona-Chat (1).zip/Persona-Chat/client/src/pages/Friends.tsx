import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLanguage } from "@/contexts/LanguageContext";
import type { Language } from "@/lib/translations";
import { useAuth } from "@/hooks/use-auth";
import { getDeviceId } from "@/hooks/use-device-id";
import { PersonalityList } from "@/components/PersonalityList";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Users, UserPlus, Search, ArrowLeft, LogIn, Check, X,
  Trophy, Star, BookOpen, Clock, Trash2, Send,
} from "lucide-react";
import { Link } from "wouter";
import type { Friendship, UserProgress, Quiz } from "@shared/schema";

const labels: Record<string, typeof labels.en> = {
  ar: {
    title: "الأصدقاء",
    subtitle: "أضف أصدقاءك وتنافسوا في الاختبارات",
    friends: "أصدقائي",
    requests: "الطلبات",
    addFriend: "إضافة صديق",
    searchUsers: "ابحث عن صديق بالاسم...",
    noFriends: "لم تضف أصدقاء بعد",
    noFriendsDesc: "ابحث عن أصدقائك وأضفهم للتنافس",
    noRequests: "لا توجد طلبات صداقة",
    sendRequest: "إرسال طلب صداقة",
    accept: "قبول",
    reject: "رفض",
    remove: "إزالة",
    pending: "معلق",
    sent: "مرسل",
    loginPrompt: "سجل دخولك بحساب Google لإضافة أصدقاء",
    login: "ربط حساب Google",
    back: "العودة",
    points: "نقطة",
    level: "المستوى",
    quizzes: "اختبارات",
    quizCompetition: "منافسات الاختبارات",
    noQuizzes: "لا توجد اختبارات مكتملة",
    score: "النتيجة",
    subject: "المادة",
    date: "التاريخ",
    you: "أنت",
    vs: "ضد",
    friendQuizzes: "اختبارات الصديق",
    myQuizzes: "اختباراتي",
    requestSent: "تم إرسال الطلب",
    requestSentDesc: "تم إرسال طلب الصداقة بنجاح",
    requestAccepted: "تم قبول الطلب",
    requestRejected: "تم رفض الطلب",
    friendRemoved: "تم إزالة الصديق",
    error: "خطأ",
    alreadyFriends: "يوجد طلب صداقة مسبق",
    incomingRequests: "طلبات واردة",
    sentRequests: "طلبات مرسلة",
    viewQuizzes: "عرض الاختبارات",
    compareQuizzes: "مقارنة الاختبارات",
    noResults: "لا توجد نتائج",
    searchByName: "ابحث عن أصدقائك بالاسم",
  },
  en: {
    title: "Friends",
    subtitle: "Add friends and compete in quizzes",
    friends: "My Friends",
    requests: "Requests",
    addFriend: "Add Friend",
    searchUsers: "Search for a friend by name...",
    noFriends: "No friends added yet",
    noFriendsDesc: "Search for friends and add them to compete",
    noRequests: "No friend requests",
    sendRequest: "Send Friend Request",
    accept: "Accept",
    reject: "Reject",
    remove: "Remove",
    pending: "Pending",
    sent: "Sent",
    loginPrompt: "Sign in with Google to add friends",
    login: "Link Google Account",
    back: "Back",
    points: "points",
    level: "Level",
    quizzes: "quizzes",
    quizCompetition: "Quiz Competition",
    noQuizzes: "No completed quizzes",
    score: "Score",
    subject: "Subject",
    date: "Date",
    you: "You",
    vs: "vs",
    friendQuizzes: "Friend's Quizzes",
    myQuizzes: "My Quizzes",
    requestSent: "Request Sent",
    requestSentDesc: "Friend request sent successfully",
    requestAccepted: "Request Accepted",
    requestRejected: "Request Rejected",
    friendRemoved: "Friend Removed",
    error: "Error",
    alreadyFriends: "Friend request already exists",
    incomingRequests: "Incoming Requests",
    sentRequests: "Sent Requests",
    viewQuizzes: "View Quizzes",
    compareQuizzes: "Compare Quizzes",
    noResults: "No results found",
    searchByName: "Search for friends by name",
  },
  zh: {
    title: "\u670B\u53CB",
    subtitle: "\u6DFB\u52A0\u670B\u53CB\u5E76\u5728\u6D4B\u9A8C\u4E2D\u7ADE\u4E89",
    friends: "\u6211\u7684\u670B\u53CB",
    requests: "\u8BF7\u6C42",
    addFriend: "\u6DFB\u52A0\u670B\u53CB",
    searchUsers: "\u6309\u540D\u79F0\u641C\u7D22\u670B\u53CB...",
    noFriends: "\u8FD8\u6CA1\u6709\u6DFB\u52A0\u670B\u53CB",
    noFriendsDesc: "\u641C\u7D22\u670B\u53CB\u5E76\u6DFB\u52A0\u4ED6\u4EEC\u6765\u7ADE\u4E89",
    noRequests: "\u6CA1\u6709\u597D\u53CB\u8BF7\u6C42",
    sendRequest: "\u53D1\u9001\u597D\u53CB\u8BF7\u6C42",
    accept: "\u63A5\u53D7",
    reject: "\u62D2\u7EDD",
    remove: "\u79FB\u9664",
    pending: "\u5F85\u5904\u7406",
    sent: "\u5DF2\u53D1\u9001",
    loginPrompt: "\u4F7F\u7528Google\u767B\u5F55\u4EE5\u6DFB\u52A0\u670B\u53CB",
    login: "\u5173\u8054Google\u8D26\u6237",
    back: "\u8FD4\u56DE",
    points: "\u5206",
    level: "\u7B49\u7EA7",
    quizzes: "\u6D4B\u9A8C",
    quizCompetition: "\u6D4B\u9A8C\u7ADE\u8D5B",
    noQuizzes: "\u6CA1\u6709\u5DF2\u5B8C\u6210\u7684\u6D4B\u9A8C",
    score: "\u5206\u6570",
    subject: "\u79D1\u76EE",
    date: "\u65E5\u671F",
    you: "\u4F60",
    vs: "\u5BF9",
    friendQuizzes: "\u670B\u53CB\u7684\u6D4B\u9A8C",
    myQuizzes: "\u6211\u7684\u6D4B\u9A8C",
    requestSent: "\u8BF7\u6C42\u5DF2\u53D1\u9001",
    requestSentDesc: "\u597D\u53CB\u8BF7\u6C42\u53D1\u9001\u6210\u529F",
    requestAccepted: "\u8BF7\u6C42\u5DF2\u63A5\u53D7",
    requestRejected: "\u8BF7\u6C42\u5DF2\u62D2\u7EDD",
    friendRemoved: "\u670B\u53CB\u5DF2\u79FB\u9664",
    error: "\u9519\u8BEF",
    alreadyFriends: "\u597D\u53CB\u8BF7\u6C42\u5DF2\u5B58\u5728",
    incomingRequests: "\u6536\u5230\u7684\u8BF7\u6C42",
    sentRequests: "\u53D1\u9001\u7684\u8BF7\u6C42",
    viewQuizzes: "\u67E5\u770B\u6D4B\u9A8C",
    compareQuizzes: "\u6BD4\u8F83\u6D4B\u9A8C",
    noResults: "\u6CA1\u6709\u627E\u5230\u7ED3\u679C",
    searchByName: "\u6309\u540D\u79F0\u641C\u7D22\u670B\u53CB",
  },
  hi: {
    title: "\u0926\u094B\u0938\u094D\u0924",
    subtitle: "\u0926\u094B\u0938\u094D\u0924\u094B\u0902 \u0915\u094B \u091C\u094B\u0921\u093C\u0947\u0902 \u0914\u0930 \u0915\u094D\u0935\u093F\u091C\u093C \u092E\u0947\u0902 \u092A\u094D\u0930\u0924\u093F\u0938\u094D\u092A\u0930\u094D\u0927\u093E \u0915\u0930\u0947\u0902",
    friends: "\u092E\u0947\u0930\u0947 \u0926\u094B\u0938\u094D\u0924",
    requests: "\u0905\u0928\u0941\u0930\u094B\u0927",
    addFriend: "\u0926\u094B\u0938\u094D\u0924 \u091C\u094B\u0921\u093C\u0947\u0902",
    searchUsers: "\u0928\u093E\u092E \u0938\u0947 \u0926\u094B\u0938\u094D\u0924 \u0916\u094B\u091C\u0947\u0902...",
    noFriends: "\u0905\u092D\u0940 \u0924\u0915 \u0915\u094B\u0908 \u0926\u094B\u0938\u094D\u0924 \u0928\u0939\u0940\u0902 \u091C\u094B\u0921\u093C\u093E",
    noFriendsDesc: "\u092A\u094D\u0930\u0924\u093F\u0938\u094D\u092A\u0930\u094D\u0927\u093E \u0915\u0947 \u0932\u093F\u090F \u0926\u094B\u0938\u094D\u0924\u094B\u0902 \u0915\u094B \u0916\u094B\u091C\u0947\u0902 \u0914\u0930 \u091C\u094B\u0921\u093C\u0947\u0902",
    noRequests: "\u0915\u094B\u0908 \u0926\u094B\u0938\u094D\u0924\u0940 \u0905\u0928\u0941\u0930\u094B\u0927 \u0928\u0939\u0940\u0902",
    sendRequest: "\u0926\u094B\u0938\u094D\u0924\u0940 \u0905\u0928\u0941\u0930\u094B\u0927 \u092D\u0947\u091C\u0947\u0902",
    accept: "\u0938\u094D\u0935\u0940\u0915\u093E\u0930 \u0915\u0930\u0947\u0902",
    reject: "\u0905\u0938\u094D\u0935\u0940\u0915\u093E\u0930 \u0915\u0930\u0947\u0902",
    remove: "\u0939\u091F\u093E\u090F\u0902",
    pending: "\u0932\u0902\u092C\u093F\u0924",
    sent: "\u092D\u0947\u091C\u093E \u0917\u092F\u093E",
    loginPrompt: "\u0926\u094B\u0938\u094D\u0924\u094B\u0902 \u0915\u094B \u091C\u094B\u0921\u093C\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F Google \u0938\u0947 \u0938\u093E\u0907\u0928 \u0907\u0928 \u0915\u0930\u0947\u0902",
    login: "Google \u0916\u093E\u0924\u093E \u0932\u093F\u0902\u0915 \u0915\u0930\u0947\u0902",
    back: "\u0935\u093E\u092A\u0938",
    points: "\u0905\u0902\u0915",
    level: "\u0938\u094D\u0924\u0930",
    quizzes: "\u0915\u094D\u0935\u093F\u091C\u093C",
    quizCompetition: "\u0915\u094D\u0935\u093F\u091C\u093C \u092A\u094D\u0930\u0924\u093F\u092F\u094B\u0917\u093F\u0924\u093E",
    noQuizzes: "\u0915\u094B\u0908 \u092A\u0942\u0930\u094D\u0923 \u0915\u094D\u0935\u093F\u091C\u093C \u0928\u0939\u0940\u0902",
    score: "\u0938\u094D\u0915\u094B\u0930",
    subject: "\u0935\u093F\u0937\u092F",
    date: "\u0924\u093E\u0930\u0940\u0916",
    you: "\u0906\u092A",
    vs: "\u092C\u0928\u093E\u092E",
    friendQuizzes: "\u0926\u094B\u0938\u094D\u0924 \u0915\u0947 \u0915\u094D\u0935\u093F\u091C\u093C",
    myQuizzes: "\u092E\u0947\u0930\u0947 \u0915\u094D\u0935\u093F\u091C\u093C",
    requestSent: "\u0905\u0928\u0941\u0930\u094B\u0927 \u092D\u0947\u091C\u093E \u0917\u092F\u093E",
    requestSentDesc: "\u0926\u094B\u0938\u094D\u0924\u0940 \u0905\u0928\u0941\u0930\u094B\u0927 \u0938\u092B\u0932\u0924\u093E\u092A\u0942\u0930\u094D\u0935\u0915 \u092D\u0947\u091C\u093E \u0917\u092F\u093E",
    requestAccepted: "\u0905\u0928\u0941\u0930\u094B\u0927 \u0938\u094D\u0935\u0940\u0915\u093E\u0930 \u0915\u093F\u092F\u093E \u0917\u092F\u093E",
    requestRejected: "\u0905\u0928\u0941\u0930\u094B\u0927 \u0905\u0938\u094D\u0935\u0940\u0915\u093E\u0930 \u0915\u093F\u092F\u093E \u0917\u092F\u093E",
    friendRemoved: "\u0926\u094B\u0938\u094D\u0924 \u0939\u091F\u093E\u092F\u093E \u0917\u092F\u093E",
    error: "\u0924\u094D\u0930\u0941\u091F\u093F",
    alreadyFriends: "\u0926\u094B\u0938\u094D\u0924\u0940 \u0905\u0928\u0941\u0930\u094B\u0927 \u092A\u0939\u0932\u0947 \u0938\u0947 \u092E\u094C\u091C\u0942\u0926 \u0939\u0948",
    incomingRequests: "\u0906\u0928\u0947 \u0935\u093E\u0932\u0947 \u0905\u0928\u0941\u0930\u094B\u0927",
    sentRequests: "\u092D\u0947\u091C\u0947 \u0917\u090F \u0905\u0928\u0941\u0930\u094B\u0927",
    viewQuizzes: "\u0915\u094D\u0935\u093F\u091C\u093C \u0926\u0947\u0916\u0947\u0902",
    compareQuizzes: "\u0915\u094D\u0935\u093F\u091C\u093C \u0924\u0941\u0932\u0928\u093E \u0915\u0930\u0947\u0902",
    noResults: "\u0915\u094B\u0908 \u092A\u0930\u093F\u0923\u093E\u092E \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u093E",
    searchByName: "\u0928\u093E\u092E \u0938\u0947 \u0926\u094B\u0938\u094D\u0924\u094B\u0902 \u0915\u094B \u0916\u094B\u091C\u0947\u0902",
  },
  es: {
    title: "Amigos",
    subtitle: "Agrega amigos y compite en cuestionarios",
    friends: "Mis Amigos",
    requests: "Solicitudes",
    addFriend: "Agregar Amigo",
    searchUsers: "Buscar un amigo por nombre...",
    noFriends: "A\u00FAn no has agregado amigos",
    noFriendsDesc: "Busca amigos y agr\u00E9galos para competir",
    noRequests: "No hay solicitudes de amistad",
    sendRequest: "Enviar Solicitud de Amistad",
    accept: "Aceptar",
    reject: "Rechazar",
    remove: "Eliminar",
    pending: "Pendiente",
    sent: "Enviado",
    loginPrompt: "Inicia sesi\u00F3n con Google para agregar amigos",
    login: "Vincular Cuenta de Google",
    back: "Volver",
    points: "puntos",
    level: "Nivel",
    quizzes: "cuestionarios",
    quizCompetition: "Competencia de Cuestionarios",
    noQuizzes: "No hay cuestionarios completados",
    score: "Puntuaci\u00F3n",
    subject: "Materia",
    date: "Fecha",
    you: "T\u00FA",
    vs: "vs",
    friendQuizzes: "Cuestionarios del Amigo",
    myQuizzes: "Mis Cuestionarios",
    requestSent: "Solicitud Enviada",
    requestSentDesc: "Solicitud de amistad enviada exitosamente",
    requestAccepted: "Solicitud Aceptada",
    requestRejected: "Solicitud Rechazada",
    friendRemoved: "Amigo Eliminado",
    error: "Error",
    alreadyFriends: "La solicitud de amistad ya existe",
    incomingRequests: "Solicitudes Recibidas",
    sentRequests: "Solicitudes Enviadas",
    viewQuizzes: "Ver Cuestionarios",
    compareQuizzes: "Comparar Cuestionarios",
    noResults: "No se encontraron resultados",
    searchByName: "Buscar amigos por nombre",
  },
  fr: {
    title: "Amis",
    subtitle: "Ajoutez des amis et rivalisez dans les quiz",
    friends: "Mes Amis",
    requests: "Demandes",
    addFriend: "Ajouter un Ami",
    searchUsers: "Rechercher un ami par nom...",
    noFriends: "Aucun ami ajout\u00E9 pour le moment",
    noFriendsDesc: "Recherchez des amis et ajoutez-les pour rivaliser",
    noRequests: "Aucune demande d'amiti\u00E9",
    sendRequest: "Envoyer une Demande d'Amiti\u00E9",
    accept: "Accepter",
    reject: "Refuser",
    remove: "Supprimer",
    pending: "En attente",
    sent: "Envoy\u00E9",
    loginPrompt: "Connectez-vous avec Google pour ajouter des amis",
    login: "Lier le Compte Google",
    back: "Retour",
    points: "points",
    level: "Niveau",
    quizzes: "quiz",
    quizCompetition: "Comp\u00E9tition de Quiz",
    noQuizzes: "Aucun quiz compl\u00E9t\u00E9",
    score: "Score",
    subject: "Mati\u00E8re",
    date: "Date",
    you: "Vous",
    vs: "contre",
    friendQuizzes: "Quiz de l'Ami",
    myQuizzes: "Mes Quiz",
    requestSent: "Demande Envoy\u00E9e",
    requestSentDesc: "Demande d'amiti\u00E9 envoy\u00E9e avec succ\u00E8s",
    requestAccepted: "Demande Accept\u00E9e",
    requestRejected: "Demande Refus\u00E9e",
    friendRemoved: "Ami Supprim\u00E9",
    error: "Erreur",
    alreadyFriends: "La demande d'amiti\u00E9 existe d\u00E9j\u00E0",
    incomingRequests: "Demandes Re\u00E7ues",
    sentRequests: "Demandes Envoy\u00E9es",
    viewQuizzes: "Voir les Quiz",
    compareQuizzes: "Comparer les Quiz",
    noResults: "Aucun résultat trouvé",
    searchByName: "Rechercher des amis par nom",
  },
  bn: {
    title: "\u09AC\u09A8\u09CD\u09A7\u09C1\u09B0\u09BE",
    subtitle: "\u09AC\u09A8\u09CD\u09A7\u09C1\u09A6\u09C7\u09B0 \u09AF\u09CB\u0997 \u0995\u09B0\u09C1\u09A8 \u098F\u09AC\u0982 \u0995\u09C1\u0987\u099C\u09C7 \u09AA\u09CD\u09B0\u09A4\u09BF\u09AF\u09CB\u0997\u09BF\u09A4\u09BE \u0995\u09B0\u09C1\u09A8",
    friends: "\u0986\u09AE\u09BE\u09B0 \u09AC\u09A8\u09CD\u09A7\u09C1\u09B0\u09BE",
    requests: "\u0985\u09A8\u09C1\u09B0\u09CB\u09A7",
    addFriend: "\u09AC\u09A8\u09CD\u09A7\u09C1 \u09AF\u09CB\u0997 \u0995\u09B0\u09C1\u09A8",
    searchUsers: "\u09A8\u09BE\u09AE \u09A6\u09BF\u09AF\u09BC\u09C7 \u09AC\u09A8\u09CD\u09A7\u09C1 \u0996\u09C1\u0981\u099C\u09C1\u09A8...",
    noFriends: "\u098F\u0996\u09A8\u0993 \u0995\u09CB\u09A8\u09CB \u09AC\u09A8\u09CD\u09A7\u09C1 \u09AF\u09CB\u0997 \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09A8\u09BF",
    noFriendsDesc: "\u09AA\u09CD\u09B0\u09A4\u09BF\u09AF\u09CB\u0997\u09BF\u09A4\u09BE\u09B0 \u099C\u09A8\u09CD\u09AF \u09AC\u09A8\u09CD\u09A7\u09C1\u09A6\u09C7\u09B0 \u0996\u09C1\u0981\u099C\u09C1\u09A8 \u098F\u09AC\u0982 \u09AF\u09CB\u0997 \u0995\u09B0\u09C1\u09A8",
    noRequests: "\u0995\u09CB\u09A8\u09CB \u09AC\u09A8\u09CD\u09A7\u09C1\u09A4\u09CD\u09AC\u09C7\u09B0 \u0985\u09A8\u09C1\u09B0\u09CB\u09A7 \u09A8\u09C7\u0987",
    sendRequest: "\u09AC\u09A8\u09CD\u09A7\u09C1\u09A4\u09CD\u09AC\u09C7\u09B0 \u0985\u09A8\u09C1\u09B0\u09CB\u09A7 \u09AA\u09BE\u09A0\u09BE\u09A8",
    accept: "\u0997\u09CD\u09B0\u09B9\u09A3 \u0995\u09B0\u09C1\u09A8",
    reject: "\u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u0996\u09CD\u09AF\u09BE\u09A8 \u0995\u09B0\u09C1\u09A8",
    remove: "\u09B8\u09B0\u09BE\u09A8",
    pending: "\u09AC\u09BF\u099A\u09BE\u09B0\u09BE\u09A7\u09C0\u09A8",
    sent: "\u09AA\u09BE\u09A0\u09BE\u09A8\u09CB \u09B9\u09AF\u09BC\u09C7\u099B\u09C7",
    loginPrompt: "\u09AC\u09A8\u09CD\u09A7\u09C1\u09A6\u09C7\u09B0 \u09AF\u09CB\u0997 \u0995\u09B0\u09A4\u09C7 Google \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B8\u09BE\u0987\u09A8 \u0987\u09A8 \u0995\u09B0\u09C1\u09A8",
    login: "Google \u0985\u09CD\u09AF\u09BE\u0995\u09BE\u0989\u09A8\u09CD\u099F \u09B2\u09BF\u0999\u09CD\u0995 \u0995\u09B0\u09C1\u09A8",
    back: "\u09AB\u09BF\u09B0\u09C7 \u09AF\u09BE\u09A8",
    points: "\u09AA\u09AF\u09BC\u09C7\u09A8\u09CD\u099F",
    level: "\u09B8\u09CD\u09A4\u09B0",
    quizzes: "\u0995\u09C1\u0987\u099C",
    quizCompetition: "\u0995\u09C1\u0987\u099C \u09AA\u09CD\u09B0\u09A4\u09BF\u09AF\u09CB\u0997\u09BF\u09A4\u09BE",
    noQuizzes: "\u0995\u09CB\u09A8\u09CB \u09B8\u09AE\u09CD\u09AA\u09A8\u09CD\u09A8 \u0995\u09C1\u0987\u099C \u09A8\u09C7\u0987",
    score: "\u09B8\u09CD\u0995\u09CB\u09B0",
    subject: "\u09AC\u09BF\u09B7\u09AF\u09BC",
    date: "\u09A4\u09BE\u09B0\u09BF\u0996",
    you: "\u0986\u09AA\u09A8\u09BF",
    vs: "\u09AC\u09A8\u09BE\u09AE",
    friendQuizzes: "\u09AC\u09A8\u09CD\u09A7\u09C1\u09B0 \u0995\u09C1\u0987\u099C",
    myQuizzes: "\u0986\u09AE\u09BE\u09B0 \u0995\u09C1\u0987\u099C",
    requestSent: "\u0985\u09A8\u09C1\u09B0\u09CB\u09A7 \u09AA\u09BE\u09A0\u09BE\u09A8\u09CB \u09B9\u09AF\u09BC\u09C7\u099B\u09C7",
    requestSentDesc: "\u09AC\u09A8\u09CD\u09A7\u09C1\u09A4\u09CD\u09AC\u09C7\u09B0 \u0985\u09A8\u09C1\u09B0\u09CB\u09A7 \u09B8\u09AB\u09B2\u09AD\u09BE\u09AC\u09C7 \u09AA\u09BE\u09A0\u09BE\u09A8\u09CB \u09B9\u09AF\u09BC\u09C7\u099B\u09C7",
    requestAccepted: "\u0985\u09A8\u09C1\u09B0\u09CB\u09A7 \u0997\u09CD\u09B0\u09B9\u09A3 \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7",
    requestRejected: "\u0985\u09A8\u09C1\u09B0\u09CB\u09A7 \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u0996\u09CD\u09AF\u09BE\u09A8 \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7",
    friendRemoved: "\u09AC\u09A8\u09CD\u09A7\u09C1 \u09B8\u09B0\u09BE\u09A8\u09CB \u09B9\u09AF\u09BC\u09C7\u099B\u09C7",
    error: "\u09A4\u09CD\u09B0\u09C1\u099F\u09BF",
    alreadyFriends: "\u09AC\u09A8\u09CD\u09A7\u09C1\u09A4\u09CD\u09AC\u09C7\u09B0 \u0985\u09A8\u09C1\u09B0\u09CB\u09A7 \u0987\u09A4\u09BF\u09AE\u09A7\u09CD\u09AF\u09C7 \u09AC\u09BF\u09A6\u09CD\u09AF\u09AE\u09BE\u09A8",
    incomingRequests: "\u0986\u0997\u09A4 \u0985\u09A8\u09C1\u09B0\u09CB\u09A7",
    sentRequests: "\u09AA\u09BE\u09A0\u09BE\u09A8\u09CB \u0985\u09A8\u09C1\u09B0\u09CB\u09A7",
    viewQuizzes: "\u0995\u09C1\u0987\u099C \u09A6\u09C7\u0996\u09C1\u09A8",
    compareQuizzes: "\u0995\u09C1\u0987\u099C \u09A4\u09C1\u09B2\u09A8\u09BE \u0995\u09B0\u09C1\u09A8",
    noResults: "\u0995\u09CB\u09A8\u09CB \u09AB\u09B2\u09BE\u09AB\u09B2 \u09AA\u09BE\u0993\u09DF\u09BE \u09AF\u09BE\u09DF\u09A8\u09BF",
    searchByName: "\u09A8\u09BE\u09AE \u09A6\u09BF\u09AF\u09BC\u09C7 \u09AC\u09A8\u09CD\u09A7\u09C1\u09A6\u09C7\u09B0 \u0996\u09C1\u0981\u099C\u09C1\u09A8",
  },
  pt: {
    title: "Amigos",
    subtitle: "Adicione amigos e compita em question\u00E1rios",
    friends: "Meus Amigos",
    requests: "Solicita\u00E7\u00F5es",
    addFriend: "Adicionar Amigo",
    searchUsers: "Pesquisar um amigo pelo nome...",
    noFriends: "Nenhum amigo adicionado ainda",
    noFriendsDesc: "Pesquise amigos e adicione-os para competir",
    noRequests: "Nenhuma solicita\u00E7\u00E3o de amizade",
    sendRequest: "Enviar Solicita\u00E7\u00E3o de Amizade",
    accept: "Aceitar",
    reject: "Rejeitar",
    remove: "Remover",
    pending: "Pendente",
    sent: "Enviado",
    loginPrompt: "Entre com Google para adicionar amigos",
    login: "Vincular Conta Google",
    back: "Voltar",
    points: "pontos",
    level: "N\u00EDvel",
    quizzes: "question\u00E1rios",
    quizCompetition: "Competi\u00E7\u00E3o de Question\u00E1rios",
    noQuizzes: "Nenhum question\u00E1rio conclu\u00EDdo",
    score: "Pontua\u00E7\u00E3o",
    subject: "Mat\u00E9ria",
    date: "Data",
    you: "Voc\u00EA",
    vs: "vs",
    friendQuizzes: "Question\u00E1rios do Amigo",
    myQuizzes: "Meus Question\u00E1rios",
    requestSent: "Solicita\u00E7\u00E3o Enviada",
    requestSentDesc: "Solicita\u00E7\u00E3o de amizade enviada com sucesso",
    requestAccepted: "Solicita\u00E7\u00E3o Aceita",
    requestRejected: "Solicita\u00E7\u00E3o Rejeitada",
    friendRemoved: "Amigo Removido",
    error: "Erro",
    alreadyFriends: "Solicita\u00E7\u00E3o de amizade j\u00E1 existe",
    incomingRequests: "Solicita\u00E7\u00F5es Recebidas",
    sentRequests: "Solicita\u00E7\u00F5es Enviadas",
    viewQuizzes: "Ver Question\u00E1rios",
    compareQuizzes: "Comparar Question\u00E1rios",
    noResults: "Nenhum resultado encontrado",
    searchByName: "Pesquisar amigos por nome",
  },
  ru: {
    title: "\u0414\u0440\u0443\u0437\u044C\u044F",
    subtitle: "\u0414\u043E\u0431\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0434\u0440\u0443\u0437\u0435\u0439 \u0438 \u0441\u043E\u0440\u0435\u0432\u043D\u0443\u0439\u0442\u0435\u0441\u044C \u0432 \u0432\u0438\u043A\u0442\u043E\u0440\u0438\u043D\u0430\u0445",
    friends: "\u041C\u043E\u0438 \u0414\u0440\u0443\u0437\u044C\u044F",
    requests: "\u0417\u0430\u043F\u0440\u043E\u0441\u044B",
    addFriend: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0414\u0440\u0443\u0433\u0430",
    searchUsers: "\u041F\u043E\u0438\u0441\u043A \u0434\u0440\u0443\u0433\u0430 \u043F\u043E \u0438\u043C\u0435\u043D\u0438...",
    noFriends: "\u0414\u0440\u0443\u0437\u044C\u044F \u0435\u0449\u0451 \u043D\u0435 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B",
    noFriendsDesc: "\u041D\u0430\u0439\u0434\u0438\u0442\u0435 \u0434\u0440\u0443\u0437\u0435\u0439 \u0438 \u0434\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0438\u0445 \u0434\u043B\u044F \u0441\u043E\u0440\u0435\u0432\u043D\u043E\u0432\u0430\u043D\u0438\u044F",
    noRequests: "\u041D\u0435\u0442 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u0432 \u0434\u0440\u0443\u0437\u044C\u044F",
    sendRequest: "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0417\u0430\u043F\u0440\u043E\u0441 \u0432 \u0414\u0440\u0443\u0437\u044C\u044F",
    accept: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C",
    reject: "\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C",
    remove: "\u0423\u0434\u0430\u043B\u0438\u0442\u044C",
    pending: "\u041E\u0436\u0438\u0434\u0430\u043D\u0438\u0435",
    sent: "\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E",
    loginPrompt: "\u0412\u043E\u0439\u0434\u0438\u0442\u0435 \u0447\u0435\u0440\u0435\u0437 Google \u0447\u0442\u043E\u0431\u044B \u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0434\u0440\u0443\u0437\u0435\u0439",
    login: "\u041F\u0440\u0438\u0432\u044F\u0437\u0430\u0442\u044C \u0410\u043A\u043A\u0430\u0443\u043D\u0442 Google",
    back: "\u041D\u0430\u0437\u0430\u0434",
    points: "\u043E\u0447\u043A\u0438",
    level: "\u0423\u0440\u043E\u0432\u0435\u043D\u044C",
    quizzes: "\u0432\u0438\u043A\u0442\u043E\u0440\u0438\u043D\u044B",
    quizCompetition: "\u0421\u043E\u0440\u0435\u0432\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u041F\u043E \u0412\u0438\u043A\u0442\u043E\u0440\u0438\u043D\u0430\u043C",
    noQuizzes: "\u041D\u0435\u0442 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D\u043D\u044B\u0445 \u0432\u0438\u043A\u0442\u043E\u0440\u0438\u043D",
    score: "\u0421\u0447\u0451\u0442",
    subject: "\u041F\u0440\u0435\u0434\u043C\u0435\u0442",
    date: "\u0414\u0430\u0442\u0430",
    you: "\u0412\u044B",
    vs: "\u043F\u0440\u043E\u0442\u0438\u0432",
    friendQuizzes: "\u0412\u0438\u043A\u0442\u043E\u0440\u0438\u043D\u044B \u0414\u0440\u0443\u0433\u0430",
    myQuizzes: "\u041C\u043E\u0438 \u0412\u0438\u043A\u0442\u043E\u0440\u0438\u043D\u044B",
    requestSent: "\u0417\u0430\u043F\u0440\u043E\u0441 \u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D",
    requestSentDesc: "\u0417\u0430\u043F\u0440\u043E\u0441 \u0432 \u0434\u0440\u0443\u0437\u044C\u044F \u0443\u0441\u043F\u0435\u0448\u043D\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D",
    requestAccepted: "\u0417\u0430\u043F\u0440\u043E\u0441 \u041F\u0440\u0438\u043D\u044F\u0442",
    requestRejected: "\u0417\u0430\u043F\u0440\u043E\u0441 \u041E\u0442\u043A\u043B\u043E\u043D\u0451\u043D",
    friendRemoved: "\u0414\u0440\u0443\u0433 \u0423\u0434\u0430\u043B\u0451\u043D",
    error: "\u041E\u0448\u0438\u0431\u043A\u0430",
    alreadyFriends: "\u0417\u0430\u043F\u0440\u043E\u0441 \u0432 \u0434\u0440\u0443\u0437\u044C\u044F \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442",
    incomingRequests: "\u0412\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0417\u0430\u043F\u0440\u043E\u0441\u044B",
    sentRequests: "\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0435 \u0417\u0430\u043F\u0440\u043E\u0441\u044B",
    viewQuizzes: "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0412\u0438\u043A\u0442\u043E\u0440\u0438\u043D\u044B",
    compareQuizzes: "\u0421\u0440\u0430\u0432\u043D\u0438\u0442\u044C \u0412\u0438\u043A\u0442\u043E\u0440\u0438\u043D\u044B",
    noResults: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E",
    searchByName: "\u041F\u043E\u0438\u0441\u043A \u0434\u0440\u0443\u0437\u0435\u0439 \u043F\u043E \u0438\u043C\u0435\u043D\u0438",
  },
  ja: {
    title: "\u53CB\u9054",
    subtitle: "\u53CB\u9054\u3092\u8FFD\u52A0\u3057\u3066\u30AF\u30A4\u30BA\u3067\u7AF6\u4E89\u3057\u3088\u3046",
    friends: "\u79C1\u306E\u53CB\u9054",
    requests: "\u30EA\u30AF\u30A8\u30B9\u30C8",
    addFriend: "\u53CB\u9054\u3092\u8FFD\u52A0",
    searchUsers: "\u540D\u524D\u3067\u53CB\u9054\u3092\u691C\u7D22...",
    noFriends: "\u307E\u3060\u53CB\u9054\u304C\u8FFD\u52A0\u3055\u308C\u3066\u3044\u307E\u305B\u3093",
    noFriendsDesc: "\u53CB\u9054\u3092\u691C\u7D22\u3057\u3066\u8FFD\u52A0\u3057\u3066\u7AF6\u4E89\u3057\u307E\u3057\u3087\u3046",
    noRequests: "\u53CB\u9054\u30EA\u30AF\u30A8\u30B9\u30C8\u306F\u3042\u308A\u307E\u305B\u3093",
    sendRequest: "\u53CB\u9054\u30EA\u30AF\u30A8\u30B9\u30C8\u3092\u9001\u4FE1",
    accept: "\u627F\u8AFE",
    reject: "\u62D2\u5426",
    remove: "\u524A\u9664",
    pending: "\u4FDD\u7559\u4E2D",
    sent: "\u9001\u4FE1\u6E08\u307F",
    loginPrompt: "\u53CB\u9054\u3092\u8FFD\u52A0\u3059\u308B\u306B\u306FGoogle\u3067\u30B5\u30A4\u30F3\u30A4\u30F3\u3057\u3066\u304F\u3060\u3055\u3044",
    login: "Google\u30A2\u30AB\u30A6\u30F3\u30C8\u3092\u30EA\u30F3\u30AF",
    back: "\u623B\u308B",
    points: "\u30DD\u30A4\u30F3\u30C8",
    level: "\u30EC\u30D9\u30EB",
    quizzes: "\u30AF\u30A4\u30BA",
    quizCompetition: "\u30AF\u30A4\u30BA\u7AF6\u4E89",
    noQuizzes: "\u5B8C\u4E86\u3057\u305F\u30AF\u30A4\u30BA\u306F\u3042\u308A\u307E\u305B\u3093",
    score: "\u30B9\u30B3\u30A2",
    subject: "\u79D1\u76EE",
    date: "\u65E5\u4ED8",
    you: "\u3042\u306A\u305F",
    vs: "\u5BFE",
    friendQuizzes: "\u53CB\u9054\u306E\u30AF\u30A4\u30BA",
    myQuizzes: "\u79C1\u306E\u30AF\u30A4\u30BA",
    requestSent: "\u30EA\u30AF\u30A8\u30B9\u30C8\u9001\u4FE1\u6E08\u307F",
    requestSentDesc: "\u53CB\u9054\u30EA\u30AF\u30A8\u30B9\u30C8\u304C\u6B63\u5E38\u306B\u9001\u4FE1\u3055\u308C\u307E\u3057\u305F",
    requestAccepted: "\u30EA\u30AF\u30A8\u30B9\u30C8\u627F\u8AFE\u6E08\u307F",
    requestRejected: "\u30EA\u30AF\u30A8\u30B9\u30C8\u62D2\u5426\u6E08\u307F",
    friendRemoved: "\u53CB\u9054\u3092\u524A\u9664\u3057\u307E\u3057\u305F",
    error: "\u30A8\u30E9\u30FC",
    alreadyFriends: "\u53CB\u9054\u30EA\u30AF\u30A8\u30B9\u30C8\u306F\u65E2\u306B\u5B58\u5728\u3057\u307E\u3059",
    incomingRequests: "\u53D7\u4FE1\u30EA\u30AF\u30A8\u30B9\u30C8",
    sentRequests: "\u9001\u4FE1\u30EA\u30AF\u30A8\u30B9\u30C8",
    viewQuizzes: "\u30AF\u30A4\u30BA\u3092\u898B\u308B",
    compareQuizzes: "\u30AF\u30A4\u30BA\u3092\u6BD4\u8F03",
    noResults: "\u7D50\u679C\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
    searchByName: "\u540D\u524D\u3067\u53CB\u9054\u3092\u691C\u7D22",
  },
};

function QuizComparisonView({ friendUserId, friendName, language }: { friendUserId: string; friendName: string; language: Language }) {
  const l = labels[language] || labels.en;
  const deviceId = getDeviceId();

  const { data: friendQuizzes = [] } = useQuery<Quiz[]>({
    queryKey: ["/api/friends", friendUserId, "quizzes"],
    queryFn: async () => {
      const res = await fetch(`/api/friends/${friendUserId}/quizzes`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: myQuizzes = [] } = useQuery<Quiz[]>({
    queryKey: ["/api/quiz/user", deviceId],
  });

  const completedMyQuizzes = myQuizzes.filter((q: any) => q.status === "completed");

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold flex items-center gap-2" data-testid="text-quiz-competition-title">
        <Trophy className="w-5 h-5 text-yellow-500" />
        {l.quizCompetition}
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h4 className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
            <Star className="w-4 h-4" />
            {l.myQuizzes} ({completedMyQuizzes.length})
          </h4>
          <div className="space-y-2">
            {completedMyQuizzes.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">{l.noQuizzes}</p>
            ) : (
              completedMyQuizzes.slice(0, 10).map((quiz: any) => (
                <Card key={quiz.id} data-testid={`my-quiz-${quiz.id}`}>
                  <CardContent className="p-3 flex items-center justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{quiz.title}</p>
                      <p className="text-xs text-muted-foreground">{quiz.subject}</p>
                    </div>
                    <Badge variant={quiz.score >= 80 ? "default" : "secondary"}>
                      {quiz.score}%
                    </Badge>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-1">
            <Users className="w-4 h-4" />
            {friendName} ({friendQuizzes.length})
          </h4>
          <div className="space-y-2">
            {friendQuizzes.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">{l.noQuizzes}</p>
            ) : (
              friendQuizzes.slice(0, 10).map((quiz: any) => (
                <Card key={quiz.id} data-testid={`friend-quiz-${quiz.id}`}>
                  <CardContent className="p-3 flex items-center justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{quiz.title}</p>
                      <p className="text-xs text-muted-foreground">{quiz.subject}</p>
                    </div>
                    <Badge variant={quiz.score >= 80 ? "default" : "secondary"}>
                      {quiz.score}%
                    </Badge>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Friends() {
  const { language } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const l = labels[language] || labels.en;
  const isRTL = language === "ar";
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFriend, setSelectedFriend] = useState<Friendship | null>(null);
  const [activeTab, setActiveTab] = useState("friends");

  const { data: friends = [] } = useQuery<Friendship[]>({
    queryKey: ["/api/friends"],
    queryFn: async () => {
      const res = await fetch("/api/friends", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const { data: incomingRequests = [] } = useQuery<Friendship[]>({
    queryKey: ["/api/friends/requests"],
    queryFn: async () => {
      const res = await fetch("/api/friends/requests", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const { data: sentRequests = [] } = useQuery<Friendship[]>({
    queryKey: ["/api/friends/sent"],
    queryFn: async () => {
      const res = await fetch("/api/friends/sent", { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const { data: searchResults = [], isFetching: isSearching } = useQuery<UserProgress[]>({
    queryKey: ["/api/friends/search", searchQuery],
    queryFn: async () => {
      if (!searchQuery.trim()) return [];
      const res = await fetch(`/api/friends/search?q=${encodeURIComponent(searchQuery)}`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: isAuthenticated && searchQuery.trim().length > 0,
  });

  const sendRequestMutation = useMutation({
    mutationFn: async (addresseeUserId: string) => {
      const res = await apiRequest("POST", "/api/friends/request", { addresseeUserId });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: l.requestSent, description: l.requestSentDesc });
      queryClient.invalidateQueries({ queryKey: ["/api/friends/sent"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friends/search"] });
      setSearchQuery("");
    },
    onError: () => {
      toast({ title: l.error, description: l.alreadyFriends, variant: "destructive" });
    },
  });

  const respondMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const res = await apiRequest("PATCH", `/api/friends/${id}`, { status });
      return res.json();
    },
    onSuccess: (_, variables) => {
      toast({ title: variables.status === "accepted" ? l.requestAccepted : l.requestRejected });
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friends/requests"] });
    },
  });

  const removeMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/friends/${id}`);
    },
    onSuccess: () => {
      toast({ title: l.friendRemoved });
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
      setSelectedFriend(null);
    },
  });

  function getFriendInfo(friendship: Friendship) {
    const userId = user?.id;
    const isRequester = friendship.requesterId === userId;
    return {
      name: isRequester ? friendship.addresseeName : friendship.requesterName,
      image: isRequester ? friendship.addresseeImage : friendship.requesterImage,
      id: isRequester ? friendship.addresseeId : friendship.requesterId,
    };
  }

  const totalRequests = incomingRequests.length;

  return (
    <div className="h-screen w-full flex overflow-hidden bg-background" dir={isRTL ? "rtl" : "ltr"}>
      <aside className="w-full md:w-[280px] lg:w-[300px] shrink-0 h-full">
        <PersonalityList />
      </aside>

      <main className="hidden md:flex flex-1 flex-col overflow-y-auto">
        <div className="max-w-3xl mx-auto w-full p-6 space-y-6">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back-home">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2" data-testid="text-friends-title">
                <Users className="w-7 h-7 text-blue-500" />
                {l.title}
              </h1>
              <p className="text-sm text-muted-foreground">{l.subtitle}</p>
            </div>
          </div>

          {!isAuthenticated && (
            <Card className="border-dashed">
              <CardContent className="p-6 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-blue-500/10 flex items-center justify-center mx-auto">
                  <Users className="w-8 h-8 text-blue-500" />
                </div>
                <p className="text-muted-foreground">{l.loginPrompt}</p>
                <Button
                  onClick={() => { window.location.href = "/api/login"; }}
                  className="gap-2"
                  data-testid="button-login-friends"
                >
                  <LogIn className="w-4 h-4" />
                  {l.login}
                </Button>
              </CardContent>
            </Card>
          )}

          {isAuthenticated && (
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="friends" data-testid="tab-friends">
                  {l.friends} ({friends.length})
                </TabsTrigger>
                <TabsTrigger value="requests" data-testid="tab-requests" className="relative">
                  {l.requests}
                  {totalRequests > 0 && (
                    <Badge variant="destructive" className="ms-1 h-5 min-w-5 flex items-center justify-center text-[10px] p-0 px-1">
                      {totalRequests}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="add" data-testid="tab-add-friend">
                  {l.addFriend}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="friends" className="space-y-4 mt-4">
                {friends.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>{l.noFriends}</p>
                    <p className="text-sm mt-1">{l.noFriendsDesc}</p>
                    <Button variant="outline" className="mt-4 gap-2" onClick={() => setActiveTab("add")} data-testid="button-go-add-friend">
                      <UserPlus className="w-4 h-4" />
                      {l.addFriend}
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {friends.map((f) => {
                      const friend = getFriendInfo(f);
                      const isSelected = selectedFriend?.id === f.id;
                      return (
                        <div key={f.id}>
                          <Card
                            className={`cursor-pointer transition-all ${isSelected ? "border-primary/50 bg-primary/5" : ""}`}
                            onClick={() => setSelectedFriend(isSelected ? null : f)}
                            data-testid={`friend-card-${f.id}`}
                          >
                            <CardContent className="p-3 flex items-center gap-3">
                              <Avatar className="w-10 h-10">
                                <AvatarImage src={friend.image || ""} />
                                <AvatarFallback>{(friend.name || "U")[0]}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1 min-w-0">
                                <p className="font-medium truncate">{friend.name}</p>
                              </div>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="gap-1"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedFriend(isSelected ? null : f);
                                  }}
                                  data-testid={`button-view-quizzes-${f.id}`}
                                >
                                  <Trophy className="w-3 h-3" />
                                  {l.compareQuizzes}
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeMutation.mutate(f.id);
                                  }}
                                  data-testid={`button-remove-friend-${f.id}`}
                                >
                                  <Trash2 className="w-4 h-4 text-muted-foreground" />
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                          {isSelected && (
                            <div className="mt-2 mb-4">
                              <QuizComparisonView
                                friendUserId={friend.id}
                                friendName={friend.name}
                                language={language}
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="requests" className="space-y-4 mt-4">
                {incomingRequests.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-muted-foreground">{l.incomingRequests}</h3>
                    {incomingRequests.map((req) => (
                      <Card key={req.id} data-testid={`incoming-request-${req.id}`}>
                        <CardContent className="p-3 flex items-center gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={req.requesterImage || ""} />
                            <AvatarFallback>{(req.requesterName || "U")[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{req.requesterName}</p>
                            <Badge variant="secondary" className="text-xs">{l.pending}</Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              className="gap-1"
                              onClick={() => respondMutation.mutate({ id: req.id, status: "accepted" })}
                              data-testid={`button-accept-${req.id}`}
                            >
                              <Check className="w-3 h-3" />
                              {l.accept}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="gap-1"
                              onClick={() => respondMutation.mutate({ id: req.id, status: "rejected" })}
                              data-testid={`button-reject-${req.id}`}
                            >
                              <X className="w-3 h-3" />
                              {l.reject}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {sentRequests.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-muted-foreground">{l.sentRequests}</h3>
                    {sentRequests.map((req) => (
                      <Card key={req.id} data-testid={`sent-request-${req.id}`}>
                        <CardContent className="p-3 flex items-center gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={req.addresseeImage || ""} />
                            <AvatarFallback>{(req.addresseeName || "U")[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{req.addresseeName}</p>
                            <Badge variant="outline" className="text-xs">{l.sent}</Badge>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeMutation.mutate(req.id)}
                            data-testid={`button-cancel-request-${req.id}`}
                          >
                            <X className="w-4 h-4 text-muted-foreground" />
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {incomingRequests.length === 0 && sentRequests.length === 0 && (
                  <div className="text-center py-12 text-muted-foreground">
                    <Send className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>{l.noRequests}</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="add" className="space-y-4 mt-4">
                <div className="relative">
                  <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                  <Input
                    type="text"
                    placeholder={l.searchUsers}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="ps-9"
                    data-testid="input-search-friends"
                  />
                </div>

                {isSearching && (
                  <div className="space-y-2">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
                    ))}
                  </div>
                )}

                {searchResults.length > 0 && (
                  <div className="space-y-2">
                    {searchResults.map((u) => (
                      <Card key={u.id} data-testid={`search-result-${u.id}`}>
                        <CardContent className="p-3 flex items-center gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={u.profileImageUrl || ""} />
                            <AvatarFallback>{(u.displayName || "U")[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{u.displayName}</p>
                            <p className="text-xs text-muted-foreground">
                              {l.level} {u.level} - {u.totalPoints} {l.points}
                            </p>
                          </div>
                          <Button
                            size="sm"
                            className="gap-1"
                            onClick={() => u.userId && sendRequestMutation.mutate(u.userId)}
                            disabled={sendRequestMutation.isPending}
                            data-testid={`button-add-friend-${u.id}`}
                          >
                            <UserPlus className="w-3 h-3" />
                            {l.sendRequest}
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {searchQuery.trim() && !isSearching && searchResults.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Search className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">{l.noResults}</p>
                  </div>
                )}

                {!searchQuery.trim() && (
                  <div className="text-center py-12 text-muted-foreground">
                    <UserPlus className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>{l.searchByName}</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}
        </div>
      </main>
    </div>
  );
}
