import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLanguage } from "@/contexts/LanguageContext";
import { getDeviceId } from "@/hooks/use-device-id";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { 
  ChevronLeft, 
  Users, 
  Trophy, 
  Star, 
  Target, 
  Flame, 
  Award, 
  BookOpen,
  UserPlus,
  LogIn,
  Copy,
  Check
} from "lucide-react";
import { motion } from "framer-motion";

interface ParentAccount {
  id: number;
  parentCode: string;
  parentName: string;
  email: string | null;
  linkedStudents: string[];
  notificationsEnabled: boolean;
  weeklyReportEnabled: boolean;
  createdAt: string;
}

interface UserProgress {
  id: number;
  deviceId: string;
  displayName: string | null;
  totalPoints: number | null;
  level: number | null;
  questionsAsked: number | null;
  quizzesCompleted: number | null;
  streakDays: number | null;
  lastActiveDate: string | null;
}

interface Achievement {
  id: number;
  achievementType: string;
  achievementName: string;
  description: string | null;
  iconUrl: string | null;
  earnedAt: string;
}

interface SubjectProgress {
  id: number;
  subject: string;
  points: number | null;
  questionsAsked: number | null;
  masteryLevel: number | null;
}

interface StudentReport {
  studentId: string;
  progress: UserProgress | null;
  achievements: Achievement[];
  subjectProgress: SubjectProgress[];
}

const parentTranslations: Record<string, {
  parentDashboard: string; enterParentCode: string; parentCodePlaceholder: string;
  login: string; register: string; registerNewAccount: string; parentName: string;
  email: string; emailOptional: string; studentDeviceId: string; studentDeviceIdHint: string;
  createAccount: string; creating: string; yourParentCode: string; copyCode: string;
  codeCopied: string; saveCodeWarning: string; linkedStudents: string; noLinkedStudents: string;
  linkStudent: string; enterStudentDeviceId: string; link: string; linking: string;
  studentProgress: string; weeklyReport: string; points: string; level: string;
  questionsAsked: string; quizzesCompleted: string; streakDays: string; achievements: string;
  subjects: string; noAchievements: string; noSubjects: string; student: string;
  lastActive: string; totalProgress: string; overview: string; back: string;
  loginError: string; registerSuccess: string; linkSuccess: string; linkError: string;
  logout: string; useMyDeviceId: string; error: string; errorCreateAccount: string;
  weeklySummary: string; questionUnit: string;
}> = {
  ar: {
    parentDashboard: "لوحة تحكم الوالدين",
    enterParentCode: "أدخل رمز الوالد",
    parentCodePlaceholder: "مثال: P-ABC123",
    login: "تسجيل الدخول",
    register: "تسجيل حساب جديد",
    registerNewAccount: "تسجيل حساب ولي أمر جديد",
    parentName: "اسم ولي الأمر",
    email: "البريد الإلكتروني",
    emailOptional: "البريد الإلكتروني (اختياري)",
    studentDeviceId: "رمز جهاز الطالب",
    studentDeviceIdHint: "يمكنك العثور على هذا الرمز في تطبيق الطالب",
    createAccount: "إنشاء الحساب",
    creating: "جاري الإنشاء...",
    yourParentCode: "رمز الوالد الخاص بك",
    copyCode: "نسخ الرمز",
    codeCopied: "تم النسخ",
    saveCodeWarning: "احفظ هذا الرمز للدخول مستقبلاً",
    linkedStudents: "الطلاب المرتبطين",
    noLinkedStudents: "لا يوجد طلاب مرتبطين",
    linkStudent: "ربط طالب جديد",
    enterStudentDeviceId: "أدخل رمز جهاز الطالب",
    link: "ربط",
    linking: "جاري الربط...",
    studentProgress: "تقدم الطالب",
    weeklyReport: "التقرير الأسبوعي",
    points: "نقاط",
    level: "المستوى",
    questionsAsked: "الأسئلة المطروحة",
    quizzesCompleted: "الاختبارات المكتملة",
    streakDays: "أيام متتالية",
    achievements: "الإنجازات",
    subjects: "المواد",
    noAchievements: "لا توجد إنجازات بعد",
    noSubjects: "لم تتم دراسة أي مادة بعد",
    student: "طالب",
    lastActive: "آخر نشاط",
    totalProgress: "التقدم الكلي",
    overview: "نظرة عامة",
    back: "رجوع",
    loginError: "رمز الوالد غير صحيح",
    registerSuccess: "تم إنشاء الحساب بنجاح",
    linkSuccess: "تم ربط الطالب بنجاح",
    linkError: "فشل في ربط الطالب",
    logout: "تسجيل الخروج",
    useMyDeviceId: "استخدم رمز جهازي الحالي",
    error: "خطأ",
    errorCreateAccount: "فشل في إنشاء الحساب",
    weeklySummary: "ملخص نشاط الطلاب خلال الأسبوع",
    questionUnit: "سؤال",
  },
  en: {
    parentDashboard: "Parent Dashboard",
    enterParentCode: "Enter Parent Code",
    parentCodePlaceholder: "e.g., P-ABC123",
    login: "Login",
    register: "Register New Account",
    registerNewAccount: "Register New Parent Account",
    parentName: "Parent Name",
    email: "Email",
    emailOptional: "Email (optional)",
    studentDeviceId: "Student Device ID",
    studentDeviceIdHint: "You can find this in the student's app",
    createAccount: "Create Account",
    creating: "Creating...",
    yourParentCode: "Your Parent Code",
    copyCode: "Copy Code",
    codeCopied: "Copied",
    saveCodeWarning: "Save this code to login later",
    linkedStudents: "Linked Students",
    noLinkedStudents: "No linked students",
    linkStudent: "Link New Student",
    enterStudentDeviceId: "Enter Student Device ID",
    link: "Link",
    linking: "Linking...",
    studentProgress: "Student Progress",
    weeklyReport: "Weekly Report",
    points: "Points",
    level: "Level",
    questionsAsked: "Questions Asked",
    quizzesCompleted: "Quizzes Completed",
    streakDays: "Day Streak",
    achievements: "Achievements",
    subjects: "Subjects",
    noAchievements: "No achievements yet",
    noSubjects: "No subjects studied yet",
    student: "Student",
    lastActive: "Last Active",
    totalProgress: "Total Progress",
    overview: "Overview",
    back: "Back",
    loginError: "Invalid parent code",
    registerSuccess: "Account created successfully",
    linkSuccess: "Student linked successfully",
    linkError: "Failed to link student",
    logout: "Logout",
    useMyDeviceId: "Use my current device ID",
    error: "Error",
    errorCreateAccount: "Failed to create account",
    weeklySummary: "Summary of student activity this week",
    questionUnit: "questions",
  },
  zh: {
    parentDashboard: "家长仪表板",
    enterParentCode: "输入家长代码",
    parentCodePlaceholder: "例如：P-ABC123",
    login: "登录",
    register: "注册新账号",
    registerNewAccount: "注册新家长账号",
    parentName: "家长姓名",
    email: "电子邮件",
    emailOptional: "电子邮件（可选）",
    studentDeviceId: "学生设备ID",
    studentDeviceIdHint: "您可以在学生的应用中找到此信息",
    createAccount: "创建账号",
    creating: "创建中...",
    yourParentCode: "您的家长代码",
    copyCode: "复制代码",
    codeCopied: "已复制",
    saveCodeWarning: "保存此代码以便日后登录",
    linkedStudents: "关联学生",
    noLinkedStudents: "没有关联的学生",
    linkStudent: "关联新学生",
    enterStudentDeviceId: "输入学生设备ID",
    link: "关联",
    linking: "关联中...",
    studentProgress: "学生进度",
    weeklyReport: "每周报告",
    points: "积分",
    level: "等级",
    questionsAsked: "提问数",
    quizzesCompleted: "测验完成数",
    streakDays: "连续天数",
    achievements: "成就",
    subjects: "科目",
    noAchievements: "暂无成就",
    noSubjects: "暂未学习任何科目",
    student: "学生",
    lastActive: "最后活跃",
    totalProgress: "总进度",
    overview: "概览",
    back: "返回",
    loginError: "家长代码无效",
    registerSuccess: "账号创建成功",
    linkSuccess: "学生关联成功",
    linkError: "学生关联失败",
    logout: "退出登录",
    useMyDeviceId: "使用我当前的设备ID",
    error: "错误",
    errorCreateAccount: "创建账号失败",
    weeklySummary: "本周学生活动摘要",
    questionUnit: "问题",
  },
  hi: {
    parentDashboard: "अभिभावक डैशबोर्ड",
    enterParentCode: "अभिभावक कोड दर्ज करें",
    parentCodePlaceholder: "उदा., P-ABC123",
    login: "लॉगिन",
    register: "नया खाता बनाएं",
    registerNewAccount: "नया अभिभावक खाता बनाएं",
    parentName: "अभिभावक का नाम",
    email: "ईमेल",
    emailOptional: "ईमेल (वैकल्पिक)",
    studentDeviceId: "छात्र डिवाइस ID",
    studentDeviceIdHint: "आप इसे छात्र के ऐप में पा सकते हैं",
    createAccount: "खाता बनाएं",
    creating: "बना रहे हैं...",
    yourParentCode: "आपका अभिभावक कोड",
    copyCode: "कोड कॉपी करें",
    codeCopied: "कॉपी हो गया",
    saveCodeWarning: "बाद में लॉगिन के लिए यह कोड सहेजें",
    linkedStudents: "जुड़े हुए छात्र",
    noLinkedStudents: "कोई जुड़ा हुआ छात्र नहीं",
    linkStudent: "नया छात्र जोड़ें",
    enterStudentDeviceId: "छात्र डिवाइस ID दर्ज करें",
    link: "जोड़ें",
    linking: "जोड़ रहे हैं...",
    studentProgress: "छात्र प्रगति",
    weeklyReport: "साप्ताहिक रिपोर्ट",
    points: "अंक",
    level: "स्तर",
    questionsAsked: "पूछे गए प्रश्न",
    quizzesCompleted: "पूर्ण क्विज़",
    streakDays: "लगातार दिन",
    achievements: "उपलब्धियां",
    subjects: "विषय",
    noAchievements: "अभी तक कोई उपलब्धि नहीं",
    noSubjects: "अभी तक कोई विषय नहीं पढ़ा",
    student: "छात्र",
    lastActive: "अंतिम सक्रियता",
    totalProgress: "कुल प्रगति",
    overview: "अवलोकन",
    back: "वापस",
    loginError: "अमान्य अभिभावक कोड",
    registerSuccess: "खाता सफलतापूर्वक बनाया गया",
    linkSuccess: "छात्र सफलतापूर्वक जोड़ा गया",
    linkError: "छात्र जोड़ने में विफल",
    logout: "लॉगआउट",
    useMyDeviceId: "मेरा वर्तमान डिवाइस ID उपयोग करें",
    error: "त्रुटि",
    errorCreateAccount: "खाता बनाने में विफल",
    weeklySummary: "इस सप्ताह छात्र गतिविधि का सारांश",
    questionUnit: "प्रश्न",
  },
  es: {
    parentDashboard: "Panel de Padres",
    enterParentCode: "Ingrese el código de padre",
    parentCodePlaceholder: "ej., P-ABC123",
    login: "Iniciar sesión",
    register: "Registrar nueva cuenta",
    registerNewAccount: "Registrar nueva cuenta de padre",
    parentName: "Nombre del padre",
    email: "Correo electrónico",
    emailOptional: "Correo electrónico (opcional)",
    studentDeviceId: "ID del dispositivo del estudiante",
    studentDeviceIdHint: "Puede encontrarlo en la app del estudiante",
    createAccount: "Crear cuenta",
    creating: "Creando...",
    yourParentCode: "Su código de padre",
    copyCode: "Copiar código",
    codeCopied: "Copiado",
    saveCodeWarning: "Guarde este código para iniciar sesión después",
    linkedStudents: "Estudiantes vinculados",
    noLinkedStudents: "No hay estudiantes vinculados",
    linkStudent: "Vincular nuevo estudiante",
    enterStudentDeviceId: "Ingrese el ID del dispositivo del estudiante",
    link: "Vincular",
    linking: "Vinculando...",
    studentProgress: "Progreso del estudiante",
    weeklyReport: "Informe semanal",
    points: "Puntos",
    level: "Nivel",
    questionsAsked: "Preguntas realizadas",
    quizzesCompleted: "Cuestionarios completados",
    streakDays: "Días consecutivos",
    achievements: "Logros",
    subjects: "Materias",
    noAchievements: "Sin logros aún",
    noSubjects: "No se han estudiado materias aún",
    student: "Estudiante",
    lastActive: "Última actividad",
    totalProgress: "Progreso total",
    overview: "Resumen",
    back: "Volver",
    loginError: "Código de padre inválido",
    registerSuccess: "Cuenta creada exitosamente",
    linkSuccess: "Estudiante vinculado exitosamente",
    linkError: "Error al vincular estudiante",
    logout: "Cerrar sesión",
    useMyDeviceId: "Usar mi ID de dispositivo actual",
    error: "Error",
    errorCreateAccount: "Error al crear la cuenta",
    weeklySummary: "Resumen de actividad estudiantil esta semana",
    questionUnit: "preguntas",
  },
  fr: {
    parentDashboard: "Tableau de bord parent",
    enterParentCode: "Entrez le code parent",
    parentCodePlaceholder: "ex., P-ABC123",
    login: "Connexion",
    register: "Créer un nouveau compte",
    registerNewAccount: "Créer un nouveau compte parent",
    parentName: "Nom du parent",
    email: "E-mail",
    emailOptional: "E-mail (optionnel)",
    studentDeviceId: "ID de l'appareil de l'élève",
    studentDeviceIdHint: "Vous pouvez le trouver dans l'application de l'élève",
    createAccount: "Créer le compte",
    creating: "Création...",
    yourParentCode: "Votre code parent",
    copyCode: "Copier le code",
    codeCopied: "Copié",
    saveCodeWarning: "Enregistrez ce code pour vous connecter plus tard",
    linkedStudents: "Élèves liés",
    noLinkedStudents: "Aucun élève lié",
    linkStudent: "Lier un nouvel élève",
    enterStudentDeviceId: "Entrez l'ID de l'appareil de l'élève",
    link: "Lier",
    linking: "Liaison...",
    studentProgress: "Progrès de l'élève",
    weeklyReport: "Rapport hebdomadaire",
    points: "Points",
    level: "Niveau",
    questionsAsked: "Questions posées",
    quizzesCompleted: "Quiz terminés",
    streakDays: "Jours consécutifs",
    achievements: "Réalisations",
    subjects: "Matières",
    noAchievements: "Aucune réalisation pour le moment",
    noSubjects: "Aucune matière étudiée pour le moment",
    student: "Élève",
    lastActive: "Dernière activité",
    totalProgress: "Progrès total",
    overview: "Aperçu",
    back: "Retour",
    loginError: "Code parent invalide",
    registerSuccess: "Compte créé avec succès",
    linkSuccess: "Élève lié avec succès",
    linkError: "Échec de la liaison de l'élève",
    logout: "Déconnexion",
    useMyDeviceId: "Utiliser mon ID d'appareil actuel",
    error: "Erreur",
    errorCreateAccount: "Échec de la création du compte",
    weeklySummary: "Résumé de l'activité des élèves cette semaine",
    questionUnit: "questions",
  },
  bn: {
    parentDashboard: "অভিভাবক ড্যাশবোর্ড",
    enterParentCode: "অভিভাবক কোড লিখুন",
    parentCodePlaceholder: "যেমন: P-ABC123",
    login: "লগইন",
    register: "নতুন অ্যাকাউন্ট তৈরি করুন",
    registerNewAccount: "নতুন অভিভাবক অ্যাকাউন্ট তৈরি করুন",
    parentName: "অভিভাবকের নাম",
    email: "ইমেইল",
    emailOptional: "ইমেইল (ঐচ্ছিক)",
    studentDeviceId: "শিক্ষার্থীর ডিভাইস আইডি",
    studentDeviceIdHint: "আপনি শিক্ষার্থীর অ্যাপে এটি খুঁজে পেতে পারেন",
    createAccount: "অ্যাকাউন্ট তৈরি করুন",
    creating: "তৈরি হচ্ছে...",
    yourParentCode: "আপনার অভিভাবক কোড",
    copyCode: "কোড কপি করুন",
    codeCopied: "কপি হয়েছে",
    saveCodeWarning: "পরে লগইনের জন্য এই কোড সংরক্ষণ করুন",
    linkedStudents: "সংযুক্ত শিক্ষার্থী",
    noLinkedStudents: "কোনো সংযুক্ত শিক্ষার্থী নেই",
    linkStudent: "নতুন শিক্ষার্থী সংযুক্ত করুন",
    enterStudentDeviceId: "শিক্ষার্থীর ডিভাইস আইডি লিখুন",
    link: "সংযুক্ত করুন",
    linking: "সংযুক্ত হচ্ছে...",
    studentProgress: "শিক্ষার্থীর অগ্রগতি",
    weeklyReport: "সাপ্তাহিক প্রতিবেদন",
    points: "পয়েন্ট",
    level: "স্তর",
    questionsAsked: "জিজ্ঞাসিত প্রশ্ন",
    quizzesCompleted: "সম্পন্ন কুইজ",
    streakDays: "ধারাবাহিক দিন",
    achievements: "অর্জন",
    subjects: "বিষয়",
    noAchievements: "এখনও কোনো অর্জন নেই",
    noSubjects: "এখনও কোনো বিষয় পড়া হয়নি",
    student: "শিক্ষার্থী",
    lastActive: "সর্বশেষ সক্রিয়",
    totalProgress: "মোট অগ্রগতি",
    overview: "সংক্ষিপ্ত বিবরণ",
    back: "ফিরে যান",
    loginError: "অবৈধ অভিভাবক কোড",
    registerSuccess: "অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে",
    linkSuccess: "শিক্ষার্থী সফলভাবে সংযুক্ত হয়েছে",
    linkError: "শিক্ষার্থী সংযুক্ত করতে ব্যর্থ",
    logout: "লগআউট",
    useMyDeviceId: "আমার বর্তমান ডিভাইস আইডি ব্যবহার করুন",
    error: "ত্রুটি",
    errorCreateAccount: "অ্যাকাউন্ট তৈরি করতে ব্যর্থ",
    weeklySummary: "এই সপ্তাহের শিক্ষার্থী কার্যকলাপের সারাংশ",
    questionUnit: "প্রশ্ন",
  },
  pt: {
    parentDashboard: "Painel dos Pais",
    enterParentCode: "Digite o código do responsável",
    parentCodePlaceholder: "ex., P-ABC123",
    login: "Entrar",
    register: "Registrar nova conta",
    registerNewAccount: "Registrar nova conta de responsável",
    parentName: "Nome do responsável",
    email: "E-mail",
    emailOptional: "E-mail (opcional)",
    studentDeviceId: "ID do dispositivo do aluno",
    studentDeviceIdHint: "Você pode encontrar isso no app do aluno",
    createAccount: "Criar conta",
    creating: "Criando...",
    yourParentCode: "Seu código de responsável",
    copyCode: "Copiar código",
    codeCopied: "Copiado",
    saveCodeWarning: "Salve este código para entrar depois",
    linkedStudents: "Alunos vinculados",
    noLinkedStudents: "Nenhum aluno vinculado",
    linkStudent: "Vincular novo aluno",
    enterStudentDeviceId: "Digite o ID do dispositivo do aluno",
    link: "Vincular",
    linking: "Vinculando...",
    studentProgress: "Progresso do aluno",
    weeklyReport: "Relatório semanal",
    points: "Pontos",
    level: "Nível",
    questionsAsked: "Perguntas feitas",
    quizzesCompleted: "Questionários concluídos",
    streakDays: "Dias consecutivos",
    achievements: "Conquistas",
    subjects: "Disciplinas",
    noAchievements: "Nenhuma conquista ainda",
    noSubjects: "Nenhuma disciplina estudada ainda",
    student: "Aluno",
    lastActive: "Última atividade",
    totalProgress: "Progresso total",
    overview: "Visão geral",
    back: "Voltar",
    loginError: "Código de responsável inválido",
    registerSuccess: "Conta criada com sucesso",
    linkSuccess: "Aluno vinculado com sucesso",
    linkError: "Falha ao vincular aluno",
    logout: "Sair",
    useMyDeviceId: "Usar meu ID de dispositivo atual",
    error: "Erro",
    errorCreateAccount: "Falha ao criar conta",
    weeklySummary: "Resumo da atividade dos alunos esta semana",
    questionUnit: "perguntas",
  },
  ru: {
    parentDashboard: "Панель родителя",
    enterParentCode: "Введите код родителя",
    parentCodePlaceholder: "напр., P-ABC123",
    login: "Войти",
    register: "Зарегистрировать новый аккаунт",
    registerNewAccount: "Зарегистрировать новый аккаунт родителя",
    parentName: "Имя родителя",
    email: "Эл. почта",
    emailOptional: "Эл. почта (необязательно)",
    studentDeviceId: "ID устройства ученика",
    studentDeviceIdHint: "Вы можете найти его в приложении ученика",
    createAccount: "Создать аккаунт",
    creating: "Создание...",
    yourParentCode: "Ваш код родителя",
    copyCode: "Копировать код",
    codeCopied: "Скопировано",
    saveCodeWarning: "Сохраните этот код для входа позже",
    linkedStudents: "Привязанные ученики",
    noLinkedStudents: "Нет привязанных учеников",
    linkStudent: "Привязать нового ученика",
    enterStudentDeviceId: "Введите ID устройства ученика",
    link: "Привязать",
    linking: "Привязка...",
    studentProgress: "Прогресс ученика",
    weeklyReport: "Еженедельный отчёт",
    points: "Очки",
    level: "Уровень",
    questionsAsked: "Заданные вопросы",
    quizzesCompleted: "Пройденные тесты",
    streakDays: "Дней подряд",
    achievements: "Достижения",
    subjects: "Предметы",
    noAchievements: "Пока нет достижений",
    noSubjects: "Пока нет изученных предметов",
    student: "Ученик",
    lastActive: "Последняя активность",
    totalProgress: "Общий прогресс",
    overview: "Обзор",
    back: "Назад",
    loginError: "Неверный код родителя",
    registerSuccess: "Аккаунт успешно создан",
    linkSuccess: "Ученик успешно привязан",
    linkError: "Не удалось привязать ученика",
    logout: "Выйти",
    useMyDeviceId: "Использовать мой текущий ID устройства",
    error: "Ошибка",
    errorCreateAccount: "Не удалось создать аккаунт",
    weeklySummary: "Сводка активности учеников за неделю",
    questionUnit: "вопросов",
  },
  ja: {
    parentDashboard: "保護者ダッシュボード",
    enterParentCode: "保護者コードを入力",
    parentCodePlaceholder: "例：P-ABC123",
    login: "ログイン",
    register: "新規アカウント登録",
    registerNewAccount: "新しい保護者アカウントを登録",
    parentName: "保護者名",
    email: "メールアドレス",
    emailOptional: "メールアドレス（任意）",
    studentDeviceId: "生徒のデバイスID",
    studentDeviceIdHint: "生徒のアプリで確認できます",
    createAccount: "アカウント作成",
    creating: "作成中...",
    yourParentCode: "あなたの保護者コード",
    copyCode: "コードをコピー",
    codeCopied: "コピーしました",
    saveCodeWarning: "後でログインするためにこのコードを保存してください",
    linkedStudents: "リンクされた生徒",
    noLinkedStudents: "リンクされた生徒はいません",
    linkStudent: "新しい生徒をリンク",
    enterStudentDeviceId: "生徒のデバイスIDを入力",
    link: "リンク",
    linking: "リンク中...",
    studentProgress: "生徒の進捗",
    weeklyReport: "週間レポート",
    points: "ポイント",
    level: "レベル",
    questionsAsked: "質問数",
    quizzesCompleted: "完了したクイズ",
    streakDays: "連続日数",
    achievements: "実績",
    subjects: "科目",
    noAchievements: "まだ実績はありません",
    noSubjects: "まだ学習した科目はありません",
    student: "生徒",
    lastActive: "最終アクティブ",
    totalProgress: "総合進捗",
    overview: "概要",
    back: "戻る",
    loginError: "無効な保護者コード",
    registerSuccess: "アカウントが正常に作成されました",
    linkSuccess: "生徒が正常にリンクされました",
    linkError: "生徒のリンクに失敗しました",
    logout: "ログアウト",
    useMyDeviceId: "現在のデバイスIDを使用",
    error: "エラー",
    errorCreateAccount: "アカウントの作成に失敗しました",
    weeklySummary: "今週の生徒活動の概要",
    questionUnit: "問題",
  },
};

export default function ParentDashboard() {
  const { language } = useLanguage();
  const { toast } = useToast();
  const t = parentTranslations[language] || parentTranslations.en;
  const isRTL = language === "ar";
  const currentDeviceId = getDeviceId();
  
  const [parentCode, setParentCode] = useState(() => {
    return localStorage.getItem("parent_code") || "";
  });
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return !!localStorage.getItem("parent_code");
  });
  const [showRegister, setShowRegister] = useState(false);
  const [showLinkStudent, setShowLinkStudent] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  
  const [registerForm, setRegisterForm] = useState({
    parentName: "",
    email: "",
    studentDeviceId: "",
  });
  
  const [newStudentId, setNewStudentId] = useState("");

  const { data: parentAccount, isLoading: loadingParent, refetch: refetchParent } = useQuery<ParentAccount>({
    queryKey: ["/api/parent", parentCode],
    queryFn: async () => {
      const res = await fetch(`/api/parent/${parentCode}`);
      if (!res.ok) throw new Error("Parent not found");
      return res.json();
    },
    enabled: isLoggedIn && !!parentCode,
  });

  const { data: reports = [], isLoading: loadingReports, refetch: refetchReports } = useQuery<StudentReport[]>({
    queryKey: ["/api/parent", parentCode, "report"],
    queryFn: async () => {
      const res = await fetch(`/api/parent/${parentCode}/report`);
      if (!res.ok) throw new Error("Failed to fetch reports");
      return res.json();
    },
    enabled: isLoggedIn && !!parentCode,
  });

  const registerMutation = useMutation({
    mutationFn: async (data: { parentName: string; email: string; studentDeviceId: string }) => {
      const res = await apiRequest("POST", "/api/parent/register", data);
      return res.json();
    },
    onSuccess: (data: ParentAccount) => {
      setParentCode(data.parentCode);
      localStorage.setItem("parent_code", data.parentCode);
      setIsLoggedIn(true);
      setShowRegister(false);
      toast({
        title: t.registerSuccess,
        description: `${t.yourParentCode}: ${data.parentCode}`,
      });
    },
    onError: () => {
      toast({
        title: t.error,
        description: t.errorCreateAccount,
        variant: "destructive",
      });
    },
  });

  const linkStudentMutation = useMutation({
    mutationFn: async (studentDeviceId: string) => {
      const res = await apiRequest("POST", `/api/parent/${parentCode}/link`, { studentDeviceId });
      return res.json();
    },
    onSuccess: () => {
      setNewStudentId("");
      setShowLinkStudent(false);
      refetchParent();
      refetchReports();
      queryClient.invalidateQueries({ queryKey: ["/api/parent", parentCode] });
      toast({
        title: t.linkSuccess,
      });
    },
    onError: () => {
      toast({
        title: t.linkError,
        variant: "destructive",
      });
    },
  });

  const handleLogin = async () => {
    if (!parentCode.trim()) return;
    
    try {
      const res = await fetch(`/api/parent/${parentCode}`);
      if (!res.ok) {
        toast({
          title: t.loginError,
          variant: "destructive",
        });
        return;
      }
      localStorage.setItem("parent_code", parentCode);
      setIsLoggedIn(true);
    } catch {
      toast({
        title: t.loginError,
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("parent_code");
    setParentCode("");
    setIsLoggedIn(false);
  };

  const handleRegister = () => {
    if (!registerForm.parentName.trim() || !registerForm.studentDeviceId.trim()) return;
    registerMutation.mutate(registerForm);
  };

  const copyParentCode = () => {
    navigator.clipboard.writeText(parentCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  if (!isLoggedIn) {
    return (
      <div className={`min-h-screen bg-background p-4 md:p-6 ${isRTL ? "rtl" : "ltr"}`} dir={isRTL ? "rtl" : "ltr"}>
        <div className="max-w-md mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back-home">
                <ChevronLeft className={`w-5 h-5 ${isRTL ? "rotate-180" : ""}`} />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">{t.parentDashboard}</h1>
          </div>

          {!showRegister ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LogIn className="w-5 h-5" />
                  {t.enterParentCode}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Input
                    placeholder={t.parentCodePlaceholder}
                    value={parentCode}
                    onChange={(e) => setParentCode(e.target.value)}
                    data-testid="input-parent-code"
                  />
                </div>
                <Button 
                  className="w-full" 
                  onClick={handleLogin}
                  data-testid="button-login"
                >
                  {t.login}
                </Button>
                <div className="text-center">
                  <Button 
                    variant="ghost" 
                    onClick={() => setShowRegister(true)}
                    data-testid="button-show-register"
                  >
                    {t.register}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="w-5 h-5" />
                  {t.registerNewAccount}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>{t.parentName}</Label>
                  <Input
                    value={registerForm.parentName}
                    onChange={(e) => setRegisterForm(prev => ({ ...prev, parentName: e.target.value }))}
                    data-testid="input-parent-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t.emailOptional}</Label>
                  <Input
                    type="email"
                    value={registerForm.email}
                    onChange={(e) => setRegisterForm(prev => ({ ...prev, email: e.target.value }))}
                    data-testid="input-email"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t.studentDeviceId}</Label>
                  <Input
                    value={registerForm.studentDeviceId}
                    onChange={(e) => setRegisterForm(prev => ({ ...prev, studentDeviceId: e.target.value }))}
                    placeholder={t.studentDeviceIdHint}
                    data-testid="input-student-device-id"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setRegisterForm(prev => ({ ...prev, studentDeviceId: currentDeviceId }))}
                    data-testid="button-use-my-device"
                  >
                    {t.useMyDeviceId}
                  </Button>
                </div>
                <Button 
                  className="w-full" 
                  onClick={handleRegister}
                  disabled={registerMutation.isPending}
                  data-testid="button-create-account"
                >
                  {registerMutation.isPending ? t.creating : t.createAccount}
                </Button>
                <div className="text-center">
                  <Button 
                    variant="ghost" 
                    onClick={() => setShowRegister(false)}
                    data-testid="button-back-to-login"
                  >
                    {t.back}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  if (loadingParent || loadingReports) {
    return (
      <div className={`min-h-screen bg-background p-4 md:p-6 ${isRTL ? "rtl" : "ltr"}`} dir={isRTL ? "rtl" : "ltr"}>
        <div className="max-w-4xl mx-auto space-y-6">
          <Skeleton className="h-10 w-48" />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-background p-4 md:p-6 ${isRTL ? "rtl" : "ltr"}`} dir={isRTL ? "rtl" : "ltr"}>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ChevronLeft className={`w-5 h-5 ${isRTL ? "rotate-180" : ""}`} />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">{t.parentDashboard}</h1>
              <p className="text-sm text-muted-foreground">{parentAccount?.parentName}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="flex items-center gap-2">
              <span className="text-xs">{parentCode}</span>
              <button onClick={copyParentCode} className="p-1" data-testid="button-copy-code">
                {copiedCode ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              </button>
            </Badge>
            <Button variant="outline" size="sm" onClick={handleLogout} data-testid="button-logout">
              {t.logout}
            </Button>
          </div>
        </div>

        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <Users className="w-8 h-8 text-primary" />
                <div>
                  <p className="font-semibold">{t.linkedStudents}</p>
                  <p className="text-2xl font-bold">{parentAccount?.linkedStudents?.length || 0}</p>
                </div>
              </div>
              <Button 
                onClick={() => setShowLinkStudent(!showLinkStudent)}
                data-testid="button-link-student"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                {t.linkStudent}
              </Button>
            </div>
            
            {showLinkStudent && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="mt-4 pt-4 border-t border-primary/20"
              >
                <div className="flex gap-2">
                  <Input
                    placeholder={t.enterStudentDeviceId}
                    value={newStudentId}
                    onChange={(e) => setNewStudentId(e.target.value)}
                    data-testid="input-new-student-id"
                  />
                  <Button 
                    onClick={() => linkStudentMutation.mutate(newStudentId)}
                    disabled={linkStudentMutation.isPending || !newStudentId.trim()}
                    data-testid="button-submit-link"
                  >
                    {linkStudentMutation.isPending ? t.linking : t.link}
                  </Button>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2"
                  onClick={() => setNewStudentId(currentDeviceId)}
                  data-testid="button-use-current-device"
                >
                  {t.useMyDeviceId}
                </Button>
              </motion.div>
            )}
          </CardContent>
        </Card>

        {reports.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>{t.noLinkedStudents}</p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="w-full grid grid-cols-2">
              <TabsTrigger value="overview" data-testid="tab-overview">
                <Trophy className="w-4 h-4 mr-2" />
                {t.overview}
              </TabsTrigger>
              <TabsTrigger value="weekly" data-testid="tab-weekly">
                <BookOpen className="w-4 h-4 mr-2" />
                {t.weeklyReport}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-4 space-y-6">
              {reports.map((report, index) => (
                <motion.div
                  key={report.studentId}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card data-testid={`card-student-${index}`}>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Users className="w-5 h-5" />
                        {report.progress?.displayName || `${t.student} ${index + 1}`}
                      </CardTitle>
                      <CardDescription className="text-xs truncate">
                        ID: {report.studentId}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
                        <div className="bg-yellow-500/10 rounded-lg p-3 text-center">
                          <Star className="w-5 h-5 mx-auto text-yellow-500 mb-1" />
                          <p className="text-lg font-bold">{report.progress?.totalPoints || 0}</p>
                          <p className="text-xs text-muted-foreground">{t.points}</p>
                        </div>
                        <div className="bg-blue-500/10 rounded-lg p-3 text-center">
                          <Trophy className="w-5 h-5 mx-auto text-blue-500 mb-1" />
                          <p className="text-lg font-bold">{report.progress?.level || 1}</p>
                          <p className="text-xs text-muted-foreground">{t.level}</p>
                        </div>
                        <div className="bg-green-500/10 rounded-lg p-3 text-center">
                          <Target className="w-5 h-5 mx-auto text-green-500 mb-1" />
                          <p className="text-lg font-bold">{report.progress?.questionsAsked || 0}</p>
                          <p className="text-xs text-muted-foreground">{t.questionsAsked}</p>
                        </div>
                        <div className="bg-purple-500/10 rounded-lg p-3 text-center">
                          <BookOpen className="w-5 h-5 mx-auto text-purple-500 mb-1" />
                          <p className="text-lg font-bold">{report.progress?.quizzesCompleted || 0}</p>
                          <p className="text-xs text-muted-foreground">{t.quizzesCompleted}</p>
                        </div>
                        <div className="bg-orange-500/10 rounded-lg p-3 text-center">
                          <Flame className="w-5 h-5 mx-auto text-orange-500 mb-1" />
                          <p className="text-lg font-bold">{report.progress?.streakDays || 0}</p>
                          <p className="text-xs text-muted-foreground">{t.streakDays}</p>
                        </div>
                      </div>

                      <div className="mb-4">
                        <div className="flex justify-between text-sm mb-2">
                          <span>{t.level} {report.progress?.level || 1}</span>
                          <span>{(report.progress?.totalPoints || 0) % 100}/100 {t.points}</span>
                        </div>
                        <Progress value={(report.progress?.totalPoints || 0) % 100} className="h-2" />
                      </div>

                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                            <Award className="w-4 h-4" />
                            {t.achievements} ({report.achievements.length})
                          </h4>
                          {report.achievements.length === 0 ? (
                            <p className="text-xs text-muted-foreground">{t.noAchievements}</p>
                          ) : (
                            <div className="flex flex-wrap gap-2">
                              {report.achievements.map((achievement) => (
                                <Badge key={achievement.id} variant="secondary">
                                  {achievement.iconUrl} {achievement.achievementName}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>

                        <div>
                          <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                            <BookOpen className="w-4 h-4" />
                            {t.subjects} ({report.subjectProgress.length})
                          </h4>
                          {report.subjectProgress.length === 0 ? (
                            <p className="text-xs text-muted-foreground">{t.noSubjects}</p>
                          ) : (
                            <div className="flex flex-wrap gap-2">
                              {report.subjectProgress.map((subject) => (
                                <Badge key={subject.id} variant="outline">
                                  {subject.subject}: {subject.points || 0} {t.points}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </TabsContent>

            <TabsContent value="weekly" className="mt-4 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5" />
                    {t.weeklyReport}
                  </CardTitle>
                  <CardDescription>
                    {t.weeklySummary}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {reports.map((report, index) => {
                      const totalQuestions = report.progress?.questionsAsked || 0;
                      const totalQuizzes = report.progress?.quizzesCompleted || 0;
                      const totalPoints = report.progress?.totalPoints || 0;
                      
                      return (
                        <div key={report.studentId} className="border rounded-lg p-4" data-testid={`weekly-student-${index}`}>
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="font-medium">
                              {report.progress?.displayName || `${t.student} ${index + 1}`}
                            </h4>
                            <Badge>{t.level} {report.progress?.level || 1}</Badge>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-4 text-center">
                            <div>
                              <p className="text-2xl font-bold text-green-600">{totalQuestions}</p>
                              <p className="text-xs text-muted-foreground">{t.questionsAsked}</p>
                            </div>
                            <div>
                              <p className="text-2xl font-bold text-blue-600">{totalQuizzes}</p>
                              <p className="text-xs text-muted-foreground">{t.quizzesCompleted}</p>
                            </div>
                            <div>
                              <p className="text-2xl font-bold text-yellow-600">{totalPoints}</p>
                              <p className="text-xs text-muted-foreground">{t.points}</p>
                            </div>
                          </div>

                          {report.subjectProgress.length > 0 && (
                            <div className="mt-3 pt-3 border-t">
                              <p className="text-sm font-medium mb-2">{t.subjects}:</p>
                              <div className="space-y-2">
                                {report.subjectProgress.slice(0, 5).map((subject) => (
                                  <div key={subject.id} className="flex items-center justify-between text-sm">
                                    <span>{subject.subject}</span>
                                    <div className="flex items-center gap-2">
                                      <span className="text-muted-foreground">
                                        {subject.questionsAsked || 0} {t.questionUnit}
                                      </span>
                                      <Badge variant="secondary" className="text-xs">
                                        {subject.points || 0} {t.points}
                                      </Badge>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}
