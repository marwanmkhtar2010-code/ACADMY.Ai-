import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/hooks/use-auth";
import { getDeviceId } from "@/hooks/use-device-id";
import { PersonalityList } from "@/components/PersonalityList";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Crown, Star, LogIn, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import type { UserProgress } from "@shared/schema";

const labels: Record<string, {
  title: string; subtitle: string; rank: string; name: string; points: string;
  level: string; you: string; noData: string; loginPrompt: string; login: string;
  back: string; questionsAsked: string; quizzesCompleted: string; student: string;
}> = {
  ar: {
    title: "قائمة المتصدرين",
    subtitle: "تنافس مع أصدقائك واحصل على أعلى النقاط",
    rank: "المرتبة",
    name: "الاسم",
    points: "النقاط",
    level: "المستوى",
    you: "أنت",
    noData: "لا يوجد لاعبين مسجلين حتى الآن",
    loginPrompt: "سجل دخولك بحساب Google للانضمام إلى المنافسة",
    login: "ربط حساب Google",
    back: "العودة",
    questionsAsked: "سؤال",
    quizzesCompleted: "اختبار",
    student: "طالب",
  },
  en: {
    title: "Leaderboard",
    subtitle: "Compete with your friends for the highest score",
    rank: "Rank",
    name: "Name",
    points: "Points",
    level: "Level",
    you: "You",
    noData: "No players registered yet",
    loginPrompt: "Sign in with Google to join the competition",
    login: "Link Google Account",
    back: "Back",
    questionsAsked: "questions",
    quizzesCompleted: "quizzes",
    student: "Student",
  },
  zh: {
    title: "排行榜",
    subtitle: "与朋友竞争最高分",
    rank: "排名",
    name: "姓名",
    points: "积分",
    level: "等级",
    you: "你",
    noData: "还没有注册的玩家",
    loginPrompt: "使用Google账号登录加入竞赛",
    login: "关联Google账号",
    back: "返回",
    questionsAsked: "问题",
    quizzesCompleted: "测验",
    student: "学生",
  },
  hi: {
    title: "लीडरबोर्ड",
    subtitle: "अपने दोस्तों के साथ सबसे ज़्यादा अंक के लिए प्रतिस्पर्धा करें",
    rank: "रैंक",
    name: "नाम",
    points: "अंक",
    level: "स्तर",
    you: "आप",
    noData: "अभी तक कोई खिलाड़ी पंजीकृत नहीं है",
    loginPrompt: "प्रतियोगिता में शामिल होने के लिए Google से साइन इन करें",
    login: "Google खाता जोड़ें",
    back: "वापस",
    questionsAsked: "प्रश्न",
    quizzesCompleted: "क्विज़",
    student: "छात्र",
  },
  es: {
    title: "Clasificación",
    subtitle: "Compite con tus amigos por la puntuación más alta",
    rank: "Rango",
    name: "Nombre",
    points: "Puntos",
    level: "Nivel",
    you: "Tú",
    noData: "No hay jugadores registrados aún",
    loginPrompt: "Inicia sesión con Google para unirte a la competencia",
    login: "Vincular cuenta de Google",
    back: "Volver",
    questionsAsked: "preguntas",
    quizzesCompleted: "cuestionarios",
    student: "Estudiante",
  },
  fr: {
    title: "Classement",
    subtitle: "Rivalisez avec vos amis pour le meilleur score",
    rank: "Rang",
    name: "Nom",
    points: "Points",
    level: "Niveau",
    you: "Vous",
    noData: "Aucun joueur inscrit pour le moment",
    loginPrompt: "Connectez-vous avec Google pour rejoindre la compétition",
    login: "Lier le compte Google",
    back: "Retour",
    questionsAsked: "questions",
    quizzesCompleted: "quiz",
    student: "Étudiant",
  },
  bn: {
    title: "লিডারবোর্ড",
    subtitle: "সর্বোচ্চ স্কোরের জন্য বন্ধুদের সাথে প্রতিযোগিতা করুন",
    rank: "র‍্যাংক",
    name: "নাম",
    points: "পয়েন্ট",
    level: "স্তর",
    you: "আপনি",
    noData: "এখনও কোনো খেলোয়াড় নিবন্ধিত হয়নি",
    loginPrompt: "প্রতিযোগিতায় যোগ দিতে Google দিয়ে সাইন ইন করুন",
    login: "Google অ্যাকাউন্ট লিংক করুন",
    back: "ফিরে যান",
    questionsAsked: "প্রশ্ন",
    quizzesCompleted: "কুইজ",
    student: "শিক্ষার্থী",
  },
  pt: {
    title: "Classificação",
    subtitle: "Compita com seus amigos pela maior pontuação",
    rank: "Posição",
    name: "Nome",
    points: "Pontos",
    level: "Nível",
    you: "Você",
    noData: "Nenhum jogador registrado ainda",
    loginPrompt: "Entre com o Google para participar da competição",
    login: "Vincular conta Google",
    back: "Voltar",
    questionsAsked: "perguntas",
    quizzesCompleted: "questionários",
    student: "Estudante",
  },
  ru: {
    title: "Таблица лидеров",
    subtitle: "Соревнуйтесь с друзьями за лучший результат",
    rank: "Место",
    name: "Имя",
    points: "Очки",
    level: "Уровень",
    you: "Вы",
    noData: "Пока нет зарегистрированных игроков",
    loginPrompt: "Войдите через Google, чтобы присоединиться к соревнованию",
    login: "Привязать аккаунт Google",
    back: "Назад",
    questionsAsked: "вопросов",
    quizzesCompleted: "тестов",
    student: "Студент",
  },
  ja: {
    title: "リーダーボード",
    subtitle: "友達と最高スコアを競おう",
    rank: "順位",
    name: "名前",
    points: "ポイント",
    level: "レベル",
    you: "あなた",
    noData: "まだプレイヤーが登録されていません",
    loginPrompt: "Googleでサインインして大会に参加しよう",
    login: "Googleアカウントを連携",
    back: "戻る",
    questionsAsked: "問題",
    quizzesCompleted: "クイズ",
    student: "生徒",
  },
};

function getRankIcon(rank: number) {
  if (rank === 1) return <Crown className="w-6 h-6 text-yellow-500" />;
  if (rank === 2) return <Medal className="w-6 h-6 text-gray-400" />;
  if (rank === 3) return <Medal className="w-6 h-6 text-amber-700" />;
  return <span className="w-6 h-6 flex items-center justify-center text-sm font-bold text-muted-foreground">{rank}</span>;
}

function getRankBg(rank: number) {
  if (rank === 1) return "bg-yellow-500/10 border-yellow-500/30";
  if (rank === 2) return "bg-gray-400/10 border-gray-400/30";
  if (rank === 3) return "bg-amber-700/10 border-amber-700/30";
  return "";
}

export default function Leaderboard() {
  const { language } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const l = labels[language] || labels.en;
  const isRTL = language === "ar";
  const deviceId = getDeviceId();

  const { data: leaderboard = [], isLoading } = useQuery<UserProgress[]>({
    queryKey: ["/api/leaderboard/linked"],
  });

  const myRank = leaderboard.findIndex((p) => p.deviceId === deviceId) + 1;

  return (
    <div className="h-screen w-full flex overflow-hidden bg-background" dir={isRTL ? "rtl" : "ltr"}>
      <aside className="w-full md:w-[280px] lg:w-[300px] shrink-0 h-full">
        <PersonalityList />
      </aside>

      <main className="hidden md:flex flex-1 flex-col overflow-y-auto">
        <div className="max-w-2xl mx-auto w-full p-6 space-y-6">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back-home">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2" data-testid="text-leaderboard-title">
                <Trophy className="w-7 h-7 text-yellow-500" />
                {l.title}
              </h1>
              <p className="text-sm text-muted-foreground">{l.subtitle}</p>
            </div>
          </div>

          {!isAuthenticated && (
            <Card className="border-dashed">
              <CardContent className="p-6 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto">
                  <Trophy className="w-8 h-8 text-yellow-500" />
                </div>
                <p className="text-muted-foreground">{l.loginPrompt}</p>
                <Button
                  onClick={() => { window.location.href = "/api/login"; }}
                  className="gap-2"
                  data-testid="button-login-leaderboard"
                >
                  <LogIn className="w-4 h-4" />
                  {l.login}
                </Button>
              </CardContent>
            </Card>
          )}

          {isAuthenticated && myRank > 0 && (
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="flex items-center gap-2">
                  {getRankIcon(myRank)}
                  <span className="text-lg font-bold">#{myRank}</span>
                </div>
                <Avatar className="w-10 h-10">
                  <AvatarImage src={user?.profileImageUrl || ""} />
                  <AvatarFallback>{user?.firstName?.[0] || "U"}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="font-semibold">
                    {user?.firstName} {user?.lastName}
                    <Badge variant="secondary" className="ms-2">{l.you}</Badge>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {leaderboard[myRank - 1]?.totalPoints || 0} {l.points} - {l.level} {leaderboard[myRank - 1]?.level || 1}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-5 h-5 text-yellow-500" />
                  <span className="text-xl font-bold">{leaderboard[myRank - 1]?.totalPoints || 0}</span>
                </div>
              </CardContent>
            </Card>
          )}

          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          ) : leaderboard.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Trophy className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>{l.noData}</p>
            </div>
          ) : (
            <div className="space-y-2">
              {leaderboard.map((entry, index) => {
                const rank = index + 1;
                const isMe = entry.deviceId === deviceId;
                return (
                  <Card
                    key={entry.id}
                    className={`transition-all ${isMe ? "border-primary/50 bg-primary/5" : ""} ${getRankBg(rank)}`}
                    data-testid={`leaderboard-entry-${rank}`}
                  >
                    <CardContent className="p-3 flex items-center gap-3">
                      <div className="w-10 flex items-center justify-center shrink-0">
                        {getRankIcon(rank)}
                      </div>
                      <Avatar className="w-9 h-9 shrink-0">
                        <AvatarImage src={entry.profileImageUrl || ""} />
                        <AvatarFallback className="text-xs">
                          {(entry.displayName || "U")[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate flex items-center gap-2">
                          {entry.displayName || l.student}
                          {isMe && <Badge variant="secondary" className="text-xs">{l.you}</Badge>}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {l.level} {entry.level} - {entry.questionsAsked || 0} {l.questionsAsked} - {entry.quizzesCompleted || 0} {l.quizzesCompleted}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span className="font-bold text-lg">{entry.totalPoints || 0}</span>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
