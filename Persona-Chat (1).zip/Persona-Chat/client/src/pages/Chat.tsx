import { PersonalityList } from "@/components/PersonalityList";
import { ChatInterface } from "@/components/ChatInterface";
import { useRoute } from "wouter";

export default function Chat() {
  const [match, params] = useRoute("/chat/:id");
  const id = match ? parseInt(params.id) : 0;

  return (
    <div className="h-screen w-full flex overflow-hidden bg-background">
      <aside className="hidden md:block w-[280px] lg:w-[300px] shrink-0 h-full">
        <PersonalityList />
      </aside>

      <main className="flex-1 h-full relative w-full">
        <ChatInterface personalityId={id} />
      </main>
    </div>
  );
}
