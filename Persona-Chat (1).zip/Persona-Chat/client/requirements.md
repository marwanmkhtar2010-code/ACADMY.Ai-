## Packages
framer-motion | Smooth layout transitions and message bubble entry animations
date-fns | Formatting message timestamps (e.g., "Just now", "10:42 AM")
clsx | Utility for conditional class names (usually paired with tailwind-merge)
tailwind-merge | Utility for merging tailwind classes intelligently

## Notes
The backend provides a REST API for Chat.
We will use standard React Query mutations for sending messages.
Chat interface will be responsive:
- Mobile: Full screen list OR full screen chat.
- Desktop: Split view (Sidebar + Chat Area).
