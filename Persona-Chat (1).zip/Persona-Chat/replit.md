# ACADMY.AI - منصة التعلم الذكي

## Overview

This is a full-stack AI educational chat application (ACADMY.AI) built with a React frontend and Express backend. The platform features 17 specialized AI teachers covering the complete Arab/Yemeni curriculum. Each teacher is strictly specialized in one subject and automatically redirects students to appropriate specialists for out-of-scope questions.

### Key Features
- **22 Specialized Teachers**: Math, Physics, Chemistry, Biology, Science, Arabic, English, French, History, Geography, Civics, Islamic Studies, Quran, Programming, AI, Engineering, Medicine, Philosophy, Economics, Psychology, Art, and University Guidance
- **Full 10-Language Support**: Complete i18n system with language dropdown selector (Arabic, English, Chinese, Hindi, Spanish, French, Bengali, Portuguese, Russian, Japanese). RTL/LTR layout automatically switches based on selected language. Preference saved in localStorage. Translations in `client/src/lib/translations.ts` and separate files (`translations-es.ts`, `translations-fr.ts`, etc.).
- **Image & File Upload with GPT-4o Vision**: Students can upload images (photos of homework, problems, diagrams) and get AI analysis using GPT-4o multimodal vision. Server-side validation for file size (100MB max) and type (JPEG, PNG, GIF, WebP).
- **Voice Input**: Speech-to-text transcription using gpt-4o-mini-transcribe model
- **Text-to-Speech (TTS)**: Read AI responses aloud using gpt-audio model with Nova voice
- **Device-Specific Sessions**: Each browser/device maintains separate chat history using localStorage-based device IDs
- **Markdown Formatting**: AI responses are formatted with headings, lists, emojis, and code blocks
- **Chat Actions**: Regenerate responses, copy messages, thumbs up/down feedback, export and clear chat
- **Message Search**: Filter messages within conversations using the search bar
- **Message Editing**: Edit user messages with save/cancel functionality
- **Message Pinning**: Pin important messages for quick reference
- **Conversation Sharing**: Generate shareable links for conversations
- **Keyboard Shortcuts**: Ctrl+Enter to send messages
- **Dark/Light Theme**: Theme toggle with preference persistence

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Animations**: Framer Motion for smooth transitions
- **Build Tool**: Vite with hot module replacement

The frontend follows a component-based architecture with:
- Pages in `client/src/pages/` (Home, Chat, NotFound)
- Reusable components in `client/src/components/`
- Custom hooks in `client/src/hooks/` for data fetching
- UI primitives from shadcn/ui in `client/src/components/ui/`

### Backend Architecture
- **Framework**: Express 5 on Node.js
- **Database ORM**: Drizzle ORM with PostgreSQL
- **API Design**: REST API with typed contracts defined in `shared/routes.ts`
- **Schema Validation**: Zod for request/response validation

The backend uses a storage pattern (`server/storage.ts`) to abstract database operations, making it easy to swap implementations. Routes are registered in `server/routes.ts` and integrate with OpenAI for chat completions.

### Shared Code
The `shared/` directory contains code used by both frontend and backend:
- `schema.ts`: Drizzle database schema and Zod validation schemas
- `routes.ts`: API contract definitions with paths, methods, and response types

### Data Model
Two main entities:
1. **Personalities**: AI characters with name, description, system instructions, and avatar
2. **Messages**: Chat messages linked to personalities with role (user/assistant) and content

### AI Integration
The application uses Replit's AI integrations which provide OpenAI-compatible endpoints. Configuration is done via environment variables:
- `AI_INTEGRATIONS_OPENAI_API_KEY`
- `AI_INTEGRATIONS_OPENAI_BASE_URL`

Additional integration modules exist in `server/replit_integrations/` for:
- Audio/voice chat capabilities
- Image generation
- Batch processing utilities

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connected via `DATABASE_URL` environment variable
- **Drizzle Kit**: Database migrations stored in `./migrations`

### AI Services
- **OpenAI API** (via Replit integrations): Chat completions, text-to-speech, speech-to-text, image generation
- Environment variables required:
  - `AI_INTEGRATIONS_OPENAI_API_KEY`
  - `AI_INTEGRATIONS_OPENAI_BASE_URL`

### Key NPM Packages
- `drizzle-orm` / `drizzle-zod`: Database ORM and schema validation
- `@tanstack/react-query`: Async state management
- `framer-motion`: Animation library
- `openai`: OpenAI SDK for API calls
- Radix UI primitives: Accessible UI components (via shadcn/ui)